"use strict";{const n={async MainMenu_Event25(n,s){},async Settings_Event73(n,s){}};self.C3.ScriptsInEvents=n}
