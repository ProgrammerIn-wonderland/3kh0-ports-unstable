version="7";
libs=["js/phaser/phaser-cachebuster.min.js","js/phaser/phaser-input.min.js","js/phaser/phaser-nineslice.min.js","js/phaser/phaser-spine.min.js","js/phaser/phaser-super-storage.min.js"];