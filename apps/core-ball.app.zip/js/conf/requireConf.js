requirejs.config({
	baseUrl : "http://dev.me/h5/core-ball/js"
});