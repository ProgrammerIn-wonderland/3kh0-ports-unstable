(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"factoryballsforever_atlas_", frames: [[382,1881,282,84],[2266,966,172,298],[2306,2607,178,67],[3279,2626,178,67],[1912,2627,178,67],[1068,1618,320,88],[2029,1621,320,88],[722,1628,320,88],[0,1640,320,88],[2351,1641,320,88],[3230,1666,320,88],[711,1807,84,44],[2429,2107,84,44],[1664,2167,84,44],[227,2182,84,44],[2322,2199,84,44],[2730,2361,84,44],[3272,1277,173,51],[0,1730,173,51],[2587,1787,173,51],[1251,1854,173,51],[981,2918,173,51],[3354,2919,173,51],[1988,1806,347,72],[362,1807,347,72],[3228,1831,347,72],[1430,1838,347,72],[2587,1842,347,72],[711,1854,347,72],[385,2986,77,40],[3729,3318,77,40],[2674,3320,77,40],[2753,3320,77,40],[2832,3320,77,40],[2911,3320,77,40],[216,3016,167,49],[2090,3024,167,49],[3768,3025,167,49],[2879,3028,167,49],[385,3029,167,49],[3286,3038,167,49],[3476,2250,70,53],[3388,2364,70,53],[1697,2573,70,53],[4016,2688,70,53],[1238,3295,70,53],[982,3297,70,53],[2107,1193,157,62],[3241,2763,157,62],[1809,2764,157,62],[1644,2767,157,62],[855,2785,157,62],[109,2790,157,62],[1430,1606,191,144],[322,1640,191,144],[2673,1641,191,144],[3851,1684,191,144],[1044,1708,191,144],[1237,1708,191,144],[3622,1011,331,132],[360,1059,331,132],[693,1059,331,132],[1398,702,360,181],[2959,1060,331,132],[1398,1061,331,132],[2440,1065,331,132],[3096,2827,162,59],[1803,2828,162,59],[1588,2831,162,59],[2234,2843,162,59],[3260,2844,162,59],[1967,2845,162,59],[1691,1507,360,80],[1760,811,360,181],[2958,1511,360,80],[1068,1536,360,80],[191,1558,360,80],[2530,1559,360,80],[3320,1584,360,80],[2416,1280,357,89],[1896,1330,357,89],[3136,1334,357,89],[3495,1334,357,89],[1420,1356,357,89],[3654,828,360,181],[2255,1371,357,89],[1088,913,111,146],[3776,2321,111,146],[300,2333,111,146],[675,2358,111,146],[788,2358,111,146],[901,2358,111,146],[2029,1731,360,73],[515,1732,360,73],[3230,1756,360,73],[2959,877,360,181],[1430,1763,360,73],[2866,1767,360,73],[0,1786,360,73],[1054,3297,73,50],[3352,3301,73,50],[702,3303,73,50],[403,3304,73,50],[478,3304,73,50],[2422,3304,73,50],[1896,994,196,200],[3717,224,360,220],[3052,253,360,220],[2369,362,360,220],[3414,446,360,220],[2530,1462,67,95],[0,1066,196,200],[1026,1083,196,200],[3776,446,196,380],[3095,475,196,380],[2369,584,196,380],[2567,684,194,379],[2763,684,194,379],[1202,702,194,379],[105,3159,67,95],[3292,1088,194,187],[2731,0,319,336],[3488,1145,194,187],[2959,684,125,176],[732,2574,144,84],[3610,2577,144,84],[2553,2581,144,84],[2160,2584,144,84],[260,2590,144,84],[2134,3151,103,67],[3229,3152,103,67],[1317,3154,103,67],[0,3159,103,67],[3684,1145,194,187],[1080,3161,103,67],[658,3144,90,77],[750,3147,90,77],[842,3149,90,77],[1225,3149,90,77],[1828,3151,90,77],[0,2668,152,74],[2092,2670,152,74],[2829,2671,152,74],[406,2672,152,74],[560,2672,152,74],[3055,1375,75,47],[2883,2149,75,47],[0,3305,75,47],[777,3305,75,47],[3844,3305,75,47],[1185,3228,93,65],[1035,3230,93,65],[1794,3230,93,65],[251,3234,93,65],[3402,3234,93,65],[3886,2660,128,89],[1058,2661,128,89],[1188,2661,128,89],[3589,2663,128,89],[2486,2667,128,89],[947,1983,187,114],[0,1990,187,114],[2335,1991,187,114],[2965,1991,187,114],[3154,1991,187,114],[2912,2408,93,79],[3756,2577,93,79],[3942,3133,93,79],[2604,3139,93,79],[3683,3139,93,79],[1458,3140,97,75],[1557,3140,97,75],[3130,3140,97,75],[981,3142,97,75],[1932,3142,97,75],[1886,2043,82,76],[2751,2065,82,76],[3155,2393,82,76],[2604,3220,82,76],[3214,3221,82,76],[3118,2640,128,93],[3459,2650,128,93],[732,2660,128,93],[2699,2660,128,93],[3756,2660,128,93],[2730,2408,180,85],[3889,2408,180,85],[1304,2409,180,85],[3388,2420,180,85],[2018,2449,180,85],[1068,1469,72,65],[2411,2676,72,65],[2200,3284,72,65],[2274,3284,72,65],[2348,3284,72,65],[3654,668,114,150],[423,2235,114,150],[1398,2257,114,150],[2188,2297,114,150],[1664,2313,114,150],[2927,338,117,133],[413,2387,117,133],[0,2399,117,133],[1780,2404,117,133],[1899,2404,117,133],[3610,302,91,120],[3595,1991,91,120],[154,2668,91,120],[1551,2671,91,120],[2983,2671,91,120],[2981,2924,85,102],[3681,2935,85,102],[2374,2938,85,102],[2461,2938,85,102],[129,2958,85,102],[658,3223,83,75],[1317,3223,83,75],[743,3226,83,75],[0,3228,83,75],[828,3228,83,75],[2179,1880,154,147],[1819,1894,154,147],[2528,1916,154,147],[2684,1916,154,147],[666,1928,154,147],[3414,302,194,129],[2731,338,194,129],[2391,1731,194,129],[3592,1758,194,129],[1792,1763,194,129],[899,3050,80,97],[1143,3062,80,97],[3048,3063,80,97],[300,3067,80,97],[1746,3075,80,97],[2369,0,360,360],[3715,2137,236,84],[2148,1421,82,25],[2200,2474,375,40],[3044,3162,67,95],[1725,3174,67,95],[3522,3184,67,95],[3591,3184,67,95],[1398,885,352,174],[1779,1421,367,84],[3052,0,361,251],[2958,1425,361,84],[3321,1425,358,84],[3955,1011,134,127],[3136,1194,134,127],[3640,2321,134,127],[1514,2327,134,127],[164,2333,134,127],[2304,2345,134,127],[539,2358,134,127],[3788,1830,189,127],[2936,1842,189,127],[1060,1854,189,127],[0,1861,189,127],[2337,1862,189,127],[1988,1880,189,127],[191,1881,189,127],[3741,3076,124,61],[981,3079,124,61],[2755,3079,124,61],[2881,3079,124,61],[382,3080,124,61],[3244,3089,124,61],[1332,3091,124,61],[1896,1196,209,66],[1154,1376,209,66],[2926,2505,209,66],[532,2506,209,66],[743,2506,209,66],[2200,2516,209,66],[261,2522,209,66],[954,2556,137,90],[3471,2558,137,90],[1428,2564,137,90],[2719,2568,137,90],[3854,2568,137,90],[1093,2569,137,90],[1232,2569,137,90],[1975,2029,225,90],[2524,2065,225,90],[0,2106,225,90],[632,2106,225,90],[859,2106,225,90],[2202,2107,225,90],[2965,2107,225,90],[3455,3065,122,64],[554,3066,122,64],[2507,3066,122,64],[176,3067,122,64],[2631,3073,122,64],[1498,3074,122,64],[1622,3074,122,64],[2497,3326,73,42],[142,3327,73,42],[1788,3343,73,42],[2572,3344,73,42],[3205,3345,73,42],[553,3346,73,42],[1310,3346,73,42],[855,2849,163,58],[0,2854,163,58],[351,2854,163,58],[3819,2857,163,58],[1020,2858,163,58],[3424,2859,163,58],[516,2861,163,58],[1691,1447,83,46],[175,1730,83,46],[2587,1731,83,46],[2762,1787,83,46],[3127,1842,83,46],[2840,1916,83,46],[947,1928,83,46],[2647,1199,122,67],[853,2981,122,67],[0,2986,122,67],[1374,3022,122,67],[3617,3039,122,67],[2259,3042,122,67],[2383,3042,122,67],[797,1807,73,44],[1805,2963,73,44],[3921,3311,73,44],[3996,3311,73,44],[2017,3313,73,44],[1395,3314,73,44],[1559,3318,73,44],[2246,2676,163,66],[3248,2695,163,66],[1877,2696,163,66],[1644,2699,163,66],[862,2717,163,66],[1318,2725,163,66],[3076,2735,163,66],[3471,2507,83,44],[1788,3297,83,44],[2589,3298,83,44],[3205,3299,83,44],[617,3300,83,44],[1310,3300,83,44],[236,3301,83,44],[2567,584,140,89],[2775,1280,140,89],[191,1463,140,89],[2411,2516,140,89],[2018,2536,140,89],[1770,2539,140,89],[3137,2549,140,89],[347,2145,225,88],[2429,2157,225,88],[2656,2157,225,88],[3312,2160,225,88],[1086,2167,225,88],[1313,2167,225,88],[0,2198,225,88],[722,1558,128,64],[3354,2972,128,64],[3156,2977,128,64],[1960,2978,128,64],[723,2981,128,64],[1244,2986,128,64],[1805,3009,128,64],[2440,1199,205,71],[3320,1511,205,71],[3155,2476,205,71],[1014,2483,205,71],[2719,2495,205,71],[3854,2495,205,71],[1221,2496,205,71],[0,2570,128,96],[130,2570,128,96],[1567,2573,128,96],[2858,2573,128,96],[2988,2573,128,96],[472,2574,128,96],[602,2574,128,96],[0,1268,194,96],[2126,2199,194,96],[2883,2199,194,96],[1664,2215,194,96],[3715,2223,194,96],[227,2235,194,96],[2322,2247,194,96],[2239,3187,67,95],[2440,966,107,97],[247,2676,107,97],[0,2744,107,97],[2246,2744,107,97],[2355,2744,107,97],[3413,2745,107,97],[2042,2746,107,97],[3293,475,118,170],[227,2010,118,170],[1766,2043,118,170],[3192,2107,118,170],[1886,2121,118,170],[2006,2121,118,170],[3595,2137,118,170],[3880,1145,194,179],[198,1193,194,179],[394,1193,194,179],[590,1193,194,179],[786,1193,194,179],[2940,1194,194,179],[1224,1195,194,179],[2308,3187,66,95],[2376,3187,66,95],[3334,3190,66,95],[3942,3214,66,95],[4010,3214,66,95],[2031,3216,66,95],[1422,3217,66,95],[3447,3131,73,101],[508,3132,73,101],[583,3132,73,101],[2454,3132,73,101],[2529,3132,73,101],[176,3133,73,101],[3867,3133,73,101],[2053,1507,90,102],[165,2854,90,102],[3984,2857,90,102],[3589,2860,90,102],[681,2861,90,102],[2562,2861,90,102],[2654,2861,90,102],[198,1066,143,110],[2440,2361,143,110],[2585,2361,143,110],[3243,2364,143,110],[1014,2371,143,110],[1159,2371,143,110],[3010,2393,143,110],[1656,3140,67,107],[2699,3142,67,107],[2768,3142,67,107],[2837,3142,67,107],[2906,3142,67,107],[2975,3142,67,107],[382,3143,67,107],[1156,2961,86,99],[3980,2961,86,99],[3068,2962,86,99],[1717,2963,86,99],[3529,2964,86,99],[635,2965,86,99],[2548,2965,86,99],[3156,3043,86,95],[1935,3044,86,95],[723,3047,86,95],[811,3050,86,95],[1244,3052,86,95],[0,3055,86,95],[88,3062,86,95],[1760,702,140,106],[3570,2450,140,106],[1486,2456,140,106],[119,2462,140,106],[1628,2465,140,106],[3712,2469,140,106],[2577,2473,140,106],[1611,1195,122,158],[3953,2137,122,158],[1540,2167,122,158],[574,2198,122,158],[698,2198,122,158],[822,2198,122,158],[946,2198,122,158],[1420,1195,189,157],[3681,1425,189,157],[1500,1447,189,157],[2148,1462,189,157],[2339,1462,189,157],[0,1463,189,157],[877,1469,189,157],[2126,2121,67,75],[3243,2279,67,75],[1968,2764,67,75],[1490,3282,67,75],[3077,3282,67,75],[913,3284,67,75],[1889,3284,67,75],[877,1374,102,74],[1912,2539,102,74],[1828,3075,102,74],[2142,3075,102,74],[3579,3108,102,74],[2246,3111,102,74],[2350,3111,102,74],[3717,0,379,222],[0,913,358,151],[2122,811,142,380],[2268,602,98,362],[3974,446,104,361],[1752,994,142,360],[3343,1991,124,167],[3469,1991,124,167],[1136,1998,124,167],[1262,1998,124,167],[1388,1998,124,167],[1514,1998,124,167],[1640,1998,124,167],[4016,809,77,118],[4016,2568,77,118],[773,2861,77,118],[2131,2867,77,118],[1881,2889,77,118],[257,2896,77,118],[2210,2904,77,118],[2151,2746,81,119],[268,2775,81,119],[1339,2793,81,119],[1422,2793,81,119],[1505,2793,81,119],[2930,2793,81,119],[3013,2803,81,119],[3872,1510,167,172],[553,1558,167,172],[3682,1584,167,172],[1691,1589,167,172],[1860,1589,167,172],[2892,1593,167,172],[3061,1593,167,172],[2829,2747,99,104],[356,2748,99,104],[457,2748,99,104],[558,2748,99,104],[3886,2751,99,104],[3987,2751,99,104],[1027,2752,99,104],[346,3252,55,96],[85,3256,55,96],[3020,3259,55,96],[1674,3271,55,96],[1731,3271,55,96],[3497,3281,55,96],[3554,3281,55,96],[1154,1285,60,89],[3010,2297,60,89],[1780,2313,60,89],[3819,2755,60,89],[2746,2861,60,89],[2527,3235,60,89],[174,3236,60,89],[1224,1083,162,109],[0,2288,162,109],[1860,2293,162,109],[2024,2297,162,109],[2846,2297,162,109],[3911,2297,162,109],[3476,2309,162,109],[3230,1593,81,67],[3695,1889,81,67],[3279,2549,81,67],[2616,2667,81,67],[451,3235,81,67],[534,3235,81,67],[2444,3235,81,67],[2202,2029,127,72],[3681,2861,127,72],[2398,2864,127,72],[1185,2887,127,72],[3096,2888,127,72],[1752,2889,127,72],[1588,2892,127,72],[3623,2754,96,104],[659,2755,96,104],[757,2755,96,104],[2616,2755,96,104],[2714,2755,96,104],[3721,2755,96,104],[2464,2758,96,104],[3539,2160,52,79],[1371,2569,52,79],[2562,2758,52,79],[451,3143,52,79],[1130,3230,52,79],[3298,3287,52,79],[1184,3295,52,79],[3847,3236,81,67],[1591,3249,81,67],[3761,3249,81,67],[2688,3251,81,67],[2771,3251,81,67],[2854,3251,81,67],[2937,3251,81,67],[406,2590,57,76],[4037,3133,57,76],[3146,3282,57,76],[1958,3284,57,76],[2099,3285,57,76],[3611,3285,57,76],[3670,3285,57,76],[877,1718,162,112],[2518,2247,162,112],[2682,2247,162,112],[3312,2250,162,112],[1070,2257,162,112],[1234,2257,162,112],[3079,2279,162,112],[3527,1511,127,70],[3225,2905,127,70],[1960,2906,127,70],[852,2909,127,70],[0,2914,127,70],[336,2914,127,70],[1314,2914,127,70],[822,1928,123,176],[3695,1959,123,176],[3820,1959,123,176],[3945,1959,123,176],[382,1967,123,176],[507,1967,123,176],[2840,1971,123,176],[2636,2965,79,106],[2717,2965,79,106],[1528,2966,79,106],[1609,2966,79,106],[2798,2970,79,106],[981,2971,79,106],[1062,2971,79,106],[2289,2904,83,106],[1443,2914,83,106],[2896,2914,83,106],[3810,2917,83,106],[3895,2917,83,106],[465,2921,83,106],[550,2921,83,106],[982,1285,170,182],[3880,1326,170,182],[2614,1371,170,182],[361,1374,170,182],[533,1374,170,182],[705,1374,170,182],[2786,1375,170,182],[2773,1065,165,213],[0,1374,359,87],[360,913,362,144],[1154,1447,344,87],[2731,475,362,207],[4016,929,80,78],[2958,1375,95,48],[4044,1726,48,95],[251,3166,101,66],[1623,1606,66,101],[2812,2853,82,115],[878,2574,68,72],[1904,602,362,207],[2031,3142,101,72],[3370,3089,75,99],[4052,1326,40,39],[1232,2793,105,92],[724,913,362,144],[982,1193,41,41],[3979,1830,107,117],[3447,1277,38,38],[982,1236,41,41],[3293,668,359,207],[3362,2507,107,117],[2370,1330,38,38],[3079,2199,104,74],[3778,3139,67,108],[4041,1510,55,106],[3552,1666,111,83],[1490,3217,99,63],[3937,3062,115,69],[1779,1356,108,58],[3522,2754,99,103],[1128,2752,102,100],[2023,3075,117,65],[3488,1088,113,44],[2255,1330,113,37],[4044,1618,45,106],[3113,3217,99,63],[934,3219,99,63],[1920,3219,99,63],[2099,3220,99,63],[3660,3220,99,63],[1697,2630,178,67],[878,2648,178,67],[1371,2656,178,67],[3415,0,300,300],[0,0,1200,911],[3127,1905,282,84],[3321,877,299,209],[3411,1905,282,84],[1251,1912,282,84],[1904,0,463,600],[1896,1266,518,62],[1202,0,700,700],[1535,1912,282,84]]}
];


// symbols:



(lib.applebadge2 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.bin = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap100 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap101 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap102 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap103 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap104 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap105 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap106 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap107 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap108 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap109 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap110 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap111 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap112 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap113 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap114 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap115 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap116 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap117 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap118 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap119 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap120 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap121 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap122 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap123 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap124 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap125 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap126 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap127 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap128 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap129 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap130 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap131 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap132 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap133 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap134 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap135 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap136 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap137 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap138 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap139 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap140 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap141 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap142 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap143 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap144 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap145 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap146 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap147 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap148 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap149 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap150 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap151 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap152 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap153 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap154 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap155 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap156 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap157 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap158 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap159 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap160 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap161 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap162 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap163 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap164 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap165 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap166 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap167 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap168 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap169 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap170 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap171 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap172 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap173 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap174 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap175 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap176 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap177 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap178 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap179 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap180 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap181 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap182 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap183 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap184 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap185 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap186 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap187 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap188 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap189 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap190 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap191 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap192 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap193 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap194 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap195 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap196 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap197 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap198 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap199 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap240 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap241 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap242 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap243 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap244 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap245 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap246 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap247 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap248 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap259 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap260 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap261 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(124);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap262 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(125);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap263 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(126);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap264 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(127);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap265 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(128);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap266 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(129);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap267 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(130);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap268 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(131);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap269 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(132);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(133);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap270 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(134);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap271 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(135);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap272 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(136);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap273 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(137);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap274 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(138);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap275 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(139);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap276 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(140);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap277 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(141);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap278 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(142);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap279 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(143);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap280 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(144);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap281 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(145);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap282 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(146);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap283 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(147);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap284 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(148);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap285 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(149);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap286 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(150);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap287 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(151);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap288 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(152);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap289 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(153);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap290 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(154);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap291 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(155);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap292 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(156);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap293 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(157);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap294 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(158);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap295 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(159);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap296 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(160);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap297 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(161);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap298 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(162);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap299 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(163);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap300 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(164);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap301 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(165);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap302 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(166);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap303 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(167);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap304 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(168);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap305 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(169);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap306 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(170);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap307 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(171);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap308 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(172);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap309 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(173);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap310 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(174);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap311 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(175);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap312 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(176);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap313 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(177);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap314 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(178);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap315 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(179);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap316 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(180);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap317 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(181);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap318 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(182);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap319 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(183);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap320 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(184);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap321 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(185);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap322 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(186);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap323 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(187);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap324 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(188);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap325 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(189);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap326 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(190);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap327 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(191);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap328 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(192);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap329 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(193);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap330 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(194);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap331 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(195);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap332 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(196);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap333 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(197);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap334 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(198);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap335 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(199);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap336 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(200);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap337 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(201);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap338 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(202);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap339 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(203);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap340 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(204);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap341 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(205);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap342 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(206);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap343 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(207);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap344 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(208);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap345 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(209);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap346 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(210);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap347 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(211);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap348 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(212);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap349 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(213);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap350 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(214);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap351 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(215);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap352 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(216);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap353 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(217);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap354 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(218);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap355 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(219);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap356 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(220);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap357 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(221);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap358 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(222);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap359 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(223);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap360 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(224);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap361 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(225);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap362 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(226);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap363 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(227);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap364 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(228);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap365 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(229);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap366 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(230);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap367 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(231);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap368 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(232);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap369 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(233);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap370 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(234);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap371 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(235);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap447 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(236);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap448 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(237);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap449 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(238);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap450 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(239);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap451 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(240);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap452 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(241);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap453 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(242);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap454 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(243);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap455 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(244);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap456 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(245);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap457 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(246);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap458 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(247);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap459 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(248);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap460 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(249);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap461 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(250);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap462 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(251);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap463 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(252);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap464 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(253);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap465 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(254);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap466 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(255);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap467 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(256);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap468 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(257);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap469 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(258);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap470 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(259);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap471 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(260);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap472 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(261);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap473 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(262);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap474 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(263);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap475 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(264);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap476 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(265);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap477 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(266);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap478 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(267);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap479 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(268);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap480 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(269);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap481 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(270);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap482 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(271);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap483 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(272);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap484 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(273);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap485 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(274);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap486 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(275);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap487 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(276);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap488 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(277);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap489 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(278);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap490 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(279);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap491 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(280);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap492 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(281);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap493 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(282);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap494 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(283);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap495 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(284);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap496 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(285);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap497 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(286);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap498 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(287);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap499 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(288);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap500 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(289);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap501 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(290);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap502 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(291);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap503 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(292);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap504 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(293);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap505 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(294);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap506 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(295);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap507 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(296);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap508 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(297);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap509 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(298);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap510 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(299);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap511 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(300);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap512 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(301);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap513 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(302);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap514 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(303);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap515 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(304);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap516 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(305);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap517 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(306);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap518 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(307);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap519 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(308);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap520 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(309);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap521 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(310);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap522 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(311);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap523 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(312);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap524 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(313);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap525 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(314);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap526 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(315);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap527 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(316);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap528 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(317);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap529 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(318);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap530 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(319);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap531 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(320);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap532 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(321);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap533 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(322);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap534 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(323);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap535 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(324);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap536 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(325);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap537 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(326);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap538 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(327);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap539 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(328);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap540 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(329);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap541 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(330);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap542 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(331);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap543 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(332);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap544 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(333);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap545 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(334);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap546 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(335);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap547 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(336);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap548 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(337);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap549 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(338);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap550 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(339);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap551 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(340);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap552 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(341);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap553 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(342);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap554 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(343);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap555 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(344);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap556 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(345);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap557 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(346);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap558 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(347);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap559 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(348);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap560 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(349);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap561 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(350);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap562 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(351);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap563 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(352);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap564 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(353);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap565 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(354);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap566 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(355);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap567 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(356);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap568 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(357);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap569 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(358);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap570 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(359);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap571 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(360);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap572 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(361);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap573 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(362);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap574 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(363);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap575 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(364);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap576 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(365);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap577 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(366);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap578 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(367);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap579 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(368);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap580 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(369);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap581 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(370);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap582 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(371);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap583 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(372);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap584 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(373);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap585 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(374);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap586 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(375);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap587 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(376);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap588 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(377);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap589 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(378);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap590 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(379);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap591 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(380);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap592 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(381);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap593 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(382);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap594 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(383);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap595 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(384);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap596 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(385);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap597 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(386);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap598 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(387);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap599 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(388);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap600 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(389);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap601 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(390);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap602 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(391);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap603 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(392);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap604 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(393);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap605 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(394);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap606 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(395);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap607 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(396);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap608 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(397);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap609 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(398);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap610 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(399);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap611 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(400);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap612 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(401);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap613 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(402);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap614 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(403);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap615 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(404);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap616 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(405);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap617 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(406);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap618 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(407);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap619 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(408);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap620 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(409);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap621 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(410);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap622 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(411);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap623 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(412);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap624 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(413);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap625 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(414);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap626 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(415);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap627 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(416);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap628 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(417);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap629 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(418);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap630 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(419);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap631 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(420);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap632 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(421);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap633 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(422);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap634 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(423);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap635 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(424);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap636 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(425);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap637 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(426);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap638 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(427);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap639 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(428);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap640 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(429);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap641 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(430);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap642 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(431);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap643 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(432);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap644 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(433);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap645 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(434);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap646 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(435);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap647 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(436);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap648 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(437);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap649 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(438);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap650 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(439);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap651 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(440);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap652 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(441);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap653 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(442);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap654 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(443);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap655 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(444);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap656 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(445);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap657 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(446);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap658 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(447);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap659 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(448);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap660 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(449);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap661 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(450);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap662 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(451);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap663 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(452);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap664 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(453);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap665 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(454);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap666 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(455);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap667 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(456);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap668 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(457);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap669 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(458);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap670 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(459);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap671 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(460);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap672 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(461);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap673 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(462);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap674 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(463);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap675 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(464);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap676 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(465);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap677 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(466);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap678 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(467);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap679 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(468);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap680 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(469);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap681 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(470);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap682 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(471);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap683 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(472);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap684 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(473);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap685 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(474);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap686 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(475);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap687 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(476);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap688 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(477);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap689 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(478);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap690 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(479);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap691 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(480);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap692 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(481);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap693 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(482);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap694 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(483);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap695 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(484);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap696 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(485);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap697 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(486);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap698 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(487);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap699 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(488);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap700 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(489);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap701 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(490);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap702 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(491);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap703 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(492);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap704 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(493);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap705 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(494);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap706 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(495);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap707 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(496);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap708 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(497);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap709 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(498);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap710 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(499);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap711 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(500);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap712 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(501);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap713 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(502);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap714 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(503);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap715 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(504);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap716 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(505);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap717 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(506);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap718 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(507);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap719 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(508);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap720 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(509);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap721 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(510);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap722 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(511);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap723 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(512);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap724 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(513);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap725 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(514);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap726 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(515);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap727 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(516);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap728 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(517);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap729 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(518);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap730 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(519);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap731 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(520);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap732 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(521);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap733 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(522);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap734 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(523);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap735 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(524);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap736 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(525);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap737 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(526);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap738 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(527);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap739 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(528);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap740 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(529);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap741 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(530);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap742 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(531);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap743 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(532);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap744 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(533);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap745 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(534);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap746 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(535);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap747 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(536);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap748 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(537);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap749 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(538);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap750 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(539);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap751 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(540);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap752 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(541);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap753 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(542);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap754 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(543);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap755 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(544);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap756 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(545);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap757 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(546);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap758 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(547);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap759 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(548);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap760 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(549);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap761 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(550);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap762 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(551);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap763 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(552);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap764 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(553);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap765 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(554);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap766 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(555);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap767 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(556);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap768 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(557);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap769 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(558);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap770 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(559);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap771 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(560);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap772 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(561);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap773 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(562);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap774 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(563);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap775 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(564);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap776 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(565);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap777 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(566);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap778 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(567);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap779 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(568);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap780 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(569);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap781 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(570);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap782 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(571);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap783 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(572);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap784 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(573);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap785 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(574);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap786 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(575);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap787 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(576);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap788 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(577);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap789 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(578);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap790 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(579);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap791 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(580);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap792 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(581);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap793 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(582);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap794 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(583);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap795 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(584);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap796 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(585);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap797 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(586);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap798 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(587);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap799 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(588);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap800 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(589);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap801 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(590);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap802 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(591);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap803 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(592);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap804 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(593);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap805 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(594);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap806 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(595);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap807 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(596);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap808 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(597);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap809 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(598);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap810 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(599);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap811 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(600);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap812 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(601);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap813 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(602);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap814 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(603);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap815 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(604);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap816 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(605);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap817 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(606);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap818 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(607);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap819 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(608);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap820 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(609);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap821 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(610);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap822 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(611);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap823 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(612);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap824 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(613);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap825 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(614);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap826 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(615);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap827 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(616);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap828 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(617);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap829 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(618);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap830 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(619);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap831 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(620);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap832 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(621);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap833 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(622);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap834 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(623);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap835 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(624);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap836 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(625);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap837 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(626);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap838 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(627);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap839 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(628);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap840 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(629);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap841 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(630);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap842 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(631);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap843 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(632);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap844 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(633);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap845 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(634);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap846 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(635);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap847 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(636);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap848 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(637);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap849 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(638);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap850 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(639);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap851 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(640);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap861 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(641);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap862 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(642);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap865 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(643);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap866 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(644);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap869 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(645);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap874 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(646);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap875 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(647);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap876 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(648);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap877 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(649);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap878 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(650);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap879 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(651);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap88 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(652);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap884 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(653);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap885 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(654);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap886 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(655);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap887 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(656);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap89 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(657);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap896 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(658);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap897 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(659);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap898 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(660);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap899 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(661);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap90 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(662);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap900 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(663);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap901 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(664);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap902 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(665);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap905 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(666);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap906 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(667);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap907 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(668);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap91 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(669);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap910 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(670);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap911 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(671);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap912 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(672);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap913 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(673);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap914 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(674);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap915 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(675);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap916 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(676);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap917 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(677);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap92 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(678);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap93 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(679);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap94 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(680);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap95 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(681);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap96 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(682);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap97 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(683);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap98 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(684);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap99 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(685);
}).prototype = p = new cjs.Sprite();



(lib.box19 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(686);
}).prototype = p = new cjs.Sprite();



(lib.boxesvast = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(687);
}).prototype = p = new cjs.Sprite();



(lib.googlebadge2 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(688);
}).prototype = p = new cjs.Sprite();



(lib.helm1pngcopy = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(689);
}).prototype = p = new cjs.Sprite();



(lib.itchbadge2 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(690);
}).prototype = p = new cjs.Sprite();



(lib.kartridgebadge2 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(691);
}).prototype = p = new cjs.Sprite();



(lib.partialendl = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(692);
}).prototype = p = new cjs.Sprite();



(lib.smallBlackonWhiteLogoRectangle = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(693);
}).prototype = p = new cjs.Sprite();



(lib.smallSquareLogoBlackonWhite = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(694);
}).prototype = p = new cjs.Sprite();



(lib.steambadge2 = function() {
	this.initialize(ss["factoryballsforever_atlas_"]);
	this.gotoAndStop(695);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.zaadzak = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap885();
	this.instance.setTransform(-37,-50);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.zaadzak, new cjs.Rectangle(-37,-50,75,99), null);


(lib.verfpot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{groen:0,oranje:1,blauw:2,rood:3,zwart:4,geel:5,wit:6,magenta:7,roze:8,groen2:9});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_7 = function() {
		this.stop();
	}
	this.frame_8 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1).call(this.frame_8).wait(1).call(this.frame_9).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape.setTransform(-1.425,-65.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF9900").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_1.setTransform(-1.425,-65.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3399FF").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_2.setTransform(-1.425,-65.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_3.setTransform(-1.425,-65.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_4.setTransform(-1.425,-65.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF00").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_5.setTransform(-1.425,-65.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_6.setTransform(-1.425,-65.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF00FF").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_7.setTransform(-1.425,-65.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF66CD").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_8.setTransform(-1.425,-65.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00FFCB").s().p("AkEEqQiAgRhggpQhkgsg+hFQg9hCAAg+QAAg9A9g7QA7g6BngtQDMhYEdAAQEeAADMBYQBlAsA4A7QA4A5AAA/QAAA+g4A+Qg5A/hkAsQjABTkqAAQicAAhtgPg");
	this.shape_9.setTransform(-1.425,-65.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(1));

	// Layer_6
	this.instance = new lib.Bitmap851();
	this.instance.setTransform(-84,-111);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84,-111,165,213);


(lib.trash = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Bitmap869();
	this.instance.setTransform(-46,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.instance_1 = new lib.bin();
	this.instance_1.setTransform(-77.1,-148.85,0.9552,0.9552);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.trash, new cjs.Rectangle(-77.1,-148.8,164.3,284.6), null);


(lib.toolbalsymbyellow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("Am5G6Qi3i3AAkDQAAkCC3i3QC3i3ECAAQEDAAC3C3QC3C3AAECQAAEDi3C3Qi3C3kDAAQkCAAi3i3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.toolbalsymbyellow, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.toolbalsymb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#16627A").s().p("Am5G6Qi3i3AAkDQAAkCC3i3QC3i3ECAAQEDAAC3C3QC3C3AAECQAAEDi3C3Qi3C3kDAAQkCAAi3i3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.toolbalsymb, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.toolbalmovieyellowemo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#220044").s().p("Am5G6Qi3i3AAkDQAAkCC3i3QC3i3ECAAQEDAAC3C3QC3C3AAECQAAEDi3C3Qi3C3kDAAQkCAAi3i3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.toolbalmovieyellowemo, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.symbzorro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap456();
	this.instance.setTransform(-181,-114);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbzorro, new cjs.Rectangle(-181,-114,361,251), null);


(lib.symbtheplaybutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AsfMgIAA4/IY/AAIAAY/g");
	this.shape.setTransform(80,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbtheplaybutton, new cjs.Rectangle(0,-80,160,160), null);


(lib.symbstreep = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,1,1).p("AlnF3ILPrt");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbstreep, new cjs.Rectangle(-41,-42.5,82,85), null);


(lib.symbsound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ACqE0QhhhMhihIIAAgFIjSgDIgOgOIAAkgQAGACAFgCQAGgDAAgEIDWgDIAAgEQCsiOAngbQAXgSANAAQAdAAgLAJIABAMIAAKXQgBAGADAHQgCAGgRAAQgGAAg3gsg");
	this.shape.setTransform(-0.0367,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbsound, new cjs.Rectangle(-25,-35.1,50,70.30000000000001), null);


(lib.symbskibrilklein22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Bitmap455();
	this.instance.setTransform(-62,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilklein22, new cjs.Rectangle(-62,-32,367,84), null);


(lib.symbskibrilklein21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap447();
	this.instance.setTransform(-35,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Bitmap448();
	this.instance_1.setTransform(37,-2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_4
	this.instance_2 = new lib.Bitmap449();
	this.instance_2.setTransform(-65,-13);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilklein21, new cjs.Rectangle(-65,-32,375,84), null);


(lib.symbskibrilklein3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Bitmap458();
	this.instance.setTransform(-58,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilklein3, new cjs.Rectangle(-58,-32,358,84), null);


(lib.symbskibrilklein2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Bitmap457();
	this.instance.setTransform(-59,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilklein2, new cjs.Rectangle(-59,-32,361,84), null);


(lib.symbskibrilklein = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Bitmap706();
	this.instance.setTransform(-56,-76);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilklein, new cjs.Rectangle(-56,-76,358,151), null);


(lib.symbskibril = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap705();
	this.instance.setTransform(-189,-111);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibril, new cjs.Rectangle(-189,-111,379,222), null);


(lib.symbplaytitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,1,1).p("Aj5D6IAAnzIHzD5g");
	this.shape.setTransform(25,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Aj5j5IHzD5InzD6g");
	this.shape_1.setTransform(25,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbplaytitle, new cjs.Rectangle(-5,-30,60,60), null);


(lib.symbmuz = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Aj0EnQgjgjAAgyQAAgxAjgkQAkgjAxAAQAVAAATAHIAAkoIAAgEQgCgOAIgMQAIgOAQgEIE1hQQAIgDAIACIAEgBQAQAAAMAMQAMAMAAAQIAAGZIAAAEIAAAGQAAAygjAjQgkAjgxAAQgyAAgjgjQgjgjAAgyQAAgxAjgkQAjgjAyAAQAVAAATAHIAAjPIjvA+IAAFUQAAAwgkAjQgiAjgyAAQgxAAgkgjg");
	this.shape.setTransform(0,-0.0031);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbmuz, new cjs.Rectangle(-28,-33,56,66), null);


(lib.symbinsta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiNErQg5gBgTgHIgcgLQgOgHgHgMIgRgWQgHgJgCgLQgEgOgCgiIgBhnIAAkAIACAAQAAgVALgWQAIgSAQgPQAPgPATgHQASgJAUgBIAAgBIEBgBIA+AAIA8ACQAaABAdAQQAaAPAJAUIALAWQAGAQgBALQAFApAABWIgBCeQAABQgIAnQgJAqgYATQgWASg0AHQglAEhfAAIjBAAgAjvCeQAAAbABAIIADAMIAFAJQAGAJALAGQANAJAPABIF0AAQAtgFAHgtIAAj5IhYAAQAAAGAHARQAFASAAAKQAAAkgNAfQgKAfgVAXQgVAWgeAOQgfAMglAAQhTAAgrg4QgSgWgKghQgIgeAAggIABgJQABgKADgJIADgHQADgGAAgGIhZAAQAACkABA2gAhFhNQgjAZAAAqQgBAxAbAhQAbAfArAAQAuAAAfgaQAigbAAgtQABgsgYgdQgagigtAAQgtAAghAZgACAiAIBkAAIAAhjIhkAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbinsta, new cjs.Rectangle(-30,-29.9,60,59.8), null);


(lib.symbglobe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(7,1,1).p("AFPkrQgCgDgCgCQgGgHgHgGQhkhliEgYQgDAAgDgBQglgGgpAAQgBAAgBAAQgpAAgmAGQgDABgDAAQgKAJgJAJQhSBTgsBiQBqAsB8AAQABAAABAAIAAjdIAAgCIAAgbABWm6QAJAJAJAJQBTBTAsBiQA2gWAygiAACmkQgBgBgBAAQABgBABAAAACjHQB7AABqgsQAxBwAACDQAAACAAABQAACDgyBuQgrBihTBSQgJAKgKAJQCFgYBkhlQAHgGAGgHQACgCACgCQByh9ABitQAAgBAAgCQAAithzh+AACDIQgBAAgBAAQh7AAhqAsQgyhuAAiDQAAgBAAgCQAAiDAxhwQg2gWgygiQhzB+AACtQAAACAAABICqAAAACDIIAAjFIAAjKAACGmQgBAAgBAAQABABABAAgAACGnIAAASAhVG7QADAAADABQAmAGApAAQAqAAAmgGQADgBACAAADmD0Qhpgrh7gBIAADeADmD0QA3AXAyAiAEYADIkWAAIkZAAAHCADIiqAAAhVm6QiEAYhkBlQgHAGgGAHQgCACgCADAlOEtQACACACACQAGAHAHAGQBkBlCEAYQgKgJgJgKQhShSgrhiQg3AXgyAigAnBADQABCtByB9");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbglobe, new cjs.Rectangle(-48.5,-48.5,97,97), null);


(lib.symbback2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhK/A4QMAAAhwfMCV/AAAMAAABwfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbback2, new cjs.Rectangle(-480,-360,960,720), null);


(lib.symbab = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.smallBlackonWhiteLogoRectangle();
	this.instance.setTransform(-120,66,0.4633,0.4629);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AHRBrQgNgMgEgNIgBgFIAzAAQACAGADADQAHAEAJAAQAPAAAJgLQAFgHAAgNIAAgMQgIAIgFADQgMAGgPAAQgUAAgPgKQgQgKgGgSQgFgMAAgOQAAgeATgUQATgSAaAAQAOAAALAFQAGAEAHAIIAAgOIAtAAIAAB2QAAAQgDAKQgDARgQANQgTAQghAAQghAAgVgSgAH0gVQgIAIAAALQAAAMAJAIQAIAJAMAAQAMAAAJgJQAIgIAAgMQAAgMgIgJQgJgIgMAAQgNAAgIAKgAP+ArQgPgSAAgZQAAgeASgTQATgTAiAAQApAAASAeQAKARAAAVIAAAGIheAAQAAAdAcAAQANAAAIgMIArAAQgFARgKAJQgTARgeAAQgoAAgTgXgAQlghQgGAFgBAKIAzAAQgFgWgVAAQgLAAgHAHgADzArQgOgSAAgZQAAgeASgTQASgTAiAAQApAAASAeQAKARAAAVIAAAGIheAAQAAAdAbAAQAOAAAHgMIAsAAQgFARgKAJQgSARgfAAQgoAAgTgXgAEaghQgFAFgCAKIAzAAQgFgWgUAAQgMAAgHAHgAiaArQgRgTAAgaQABgZARgTQAVgXAnAAQAkAAAVAXQASATAAAaQAAAZgSATQgUAXgmAAQgmAAgWgXgAh1gUQgHAIAAALQAAAKAHAIQAJAKAOAAQAMAAAIgIQAJgJAAgLQAAgMgJgJQgIgJgMAAQgOAAgJALgAJ3AxQgXgTAAgfQAAghAXgTQARgQAYAAQAOAAAMAGQAGADAIAIIAAgNIAtAAIAAB+IgtAAIAAgOQgHAIgHAEQgLAGgPAAQgYAAgRgQgAKWgUQgHAIAAALQAAAJAHAIQAIALAOAAQAMAAAJgJQAHgIABgLQAAgMgJgJQgIgIgMAAQgOAAgIAKgAraAxQgWgTAAgfQAAghAWgTQASgQAYAAQANAAAMAGQAHADAHAIIAAgNIAtAAIAAB+IgtAAIAAgOQgHAIgGAEQgMAGgOAAQgYAAgSgQgAq6gUQgIAIAAALQAAAJAIAIQAIALANAAQAMAAAJgJQAIgIAAgLQAAgMgJgJQgHgIgNAAQgNAAgIAKgAxkAxQgWgTAAgfQAAghAXgTQARgQAXAAQAOAAAMAGQAGADAIAIIAAgNIAtAAIAAB+IgtAAIAAgOQgGAIgHAEQgMAGgPAAQgXAAgSgQgAxFgUQgHAIAAALQAAAJAHAIQAJALANAAQANAAAIgJQAIgIAAgLQAAgMgIgJQgJgIgMAAQgNAAgJAKgAOzA9IAAg9QAAgRgEgGQgFgJgJAAQgMAAgGAKQgEAHAAAPIAAA9IgtAAIAAg9QAAgRgDgFQgFgKgMAAQgKAAgGAJQgCADgBAFIgBAPIAAA9IgtAAIAAh+IAtAAIAAAQQAIgIAGgDQAMgHAPAAQASAAANAKQAGAFAGAJQAGgIAGgFQANgLASAAQAOAAALAHQAMAIADAMQADAIAAAMIAABRgACcA9IAAhZIgPAAIAAglIAPAAIAAgmIAtAAIAAAmIAaAAIAAAlIgaAAIAABZgABVA9IAAg/QAAgRgDgFQgHgIgKAAQgLAAgGAHQgHAGAAANIAABDIgsAAIAAh+IAsAAIAAAQQAIgJAHgDQAKgGARAAQATAAANALQAPAMAAAZIAABQgAlFA9IAAi5IBIAAQA1AAAAAwQAAAPgFAKQgGAIgJAGQAWAFAIANQAHAMAAAPQABAVgMANQgRATgkAAgAkUAYIALAAQASAAAIgEQAIgFAAgKQAAgPgQgDIgTgBIgKAAgAkUgzIAJAAQANAAAFgGQAFgFgBgHQAAgNgLgEIgLgBIgJAAgAnZA9IAAhZIgQAAIAAAFQgJgFgKAAQgWAAgGASQgCAHAAAKIAAA2IgtAAIAAh+IAtAAIAAAVQAHgLAHgFQAMgGAOAAIAJAAIAAABIAQAAIAAgmIAtAAIAAAmIAZAAIAAAlIgZAAIAABZgAuKA9IAAi5IBIAAQA1AAAAAwQAAAPgGAKQgFAIgKAGQAWAFAJANQAHAMAAAPQAAAVgMANQgRATgkAAgAtaAYIALAAQATAAAHgEQAIgFAAgKQAAgPgQgDIgTgBIgKAAgAtagzIAJAAQANAAAFgGQAFgFAAgHQAAgNgMgEIgLgBIgJAAg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbab, new cjs.Rectangle(-120,-12.5,240,107.2), null);


(lib.symb_muis = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.8,1,1).p("AATAdIAABmIgkAAIAAhmIg8AKIBLipIBQCpg");
	this.shape.setTransform(0,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgQCDIAAhmIg8AKIBKipIBPCpIg6gKIAABmg");
	this.shape_1.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symb_muis, new cjs.Rectangle(-8.7,-14.1,17.5,28.299999999999997), null);


(lib.steekmessymb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap884();
	this.instance.setTransform(-50,-36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.steekmessymb, new cjs.Rectangle(-50,-36,101,72), null);


(lib.ssetam2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.steambadge2();
	this.instance.setTransform(-83.9,-25,0.5952,0.5952);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ssetam2, new cjs.Rectangle(-83.9,-25,167.9,50), null);


(lib.snklik2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACDAoQgIgJAAgMQAAgPAKgIQAJgKARAAQAUAAAJAOQAFAJAAALIAAADIgvAAQAAAOAOAAQAHgBAEgFIAVAAQgCAJgFAEQgJAJgQgBQgTAAgKgMgACWADQgCACgBAFIAZAAQgCgKgKAAQgGAAgEADgAnYApQgJgKAAgOQAAgLAJgJQALgMATAAQASAAALAMQAJAIAAAOQAAANgJAJQgKALgTAAQgTAAgLgLgAnGAIQgDAFAAAGQAAAFADAEQAFAFAHAAQAGAAAEgEQAEgEAAgGQAAgHgEgEQgEgEgGAAQgHAAgFAEgAFcAsQgLgKAAgPQAAgRAMgIQAJgJALABQAHAAAGACQADACAEAEIAAgHIAWAAIAAA/IgWAAIAAgHQgDAEgEACQgFADgIAAQgLAAgKgIgAFsAJQgDAEAAAGQAAAEADAFQAEAEAHAAQAGAAAEgDQAFgFAAgFQAAgHgFgEQgEgEgGAAQgHAAgEAFgAEcAxQgDgCgDgEIAAAHIgXAAIAAhlIAXAAIAAAtIAHgGQAGgCAHAAQALgBAJAJQALAIAAARQAAAPgLAKQgJAIgMAAQgHAAgGgDgAEZAIQgEAEAAAHQAAAFAEAFQAFAEAGAAQAGAAAFgFQADgFAAgEQAAgGgDgEQgFgFgGAAQgGAAgFAEgAipAoQgIgJAAgMQAAgNAIgJQAKgMASABQAHgBAHAEIAAASQgGgEgFAAQgHAAgEAEQgFAFAAAHQAAAGAFAFQAEADAHAAQAFAAAGgDIAAATQgHADgHAAQgSAAgKgMgAkpAoQgIgJAAgMQAAgNAIgJQAKgMASABQAHgBAHAEIAAASQgGgEgFAAQgHAAgEAEQgFAFAAAHQAAAGAFAFQAEADAHAAQAFAAAGgDIAAATQgHADgHAAQgSAAgKgMgAHLAyIAAhlIAXAAIAABlgAGoAyIAAhlIAXAAIAABlgABbAyIAAggQAAgJgCgDQgDgDgFAAQgGgBgDAEQgDADAAAHIAAAiIgXAAIAAhlIAXAAIAAAvQAEgFADgCQAFgDAIAAQAKAAAHAFQAHAHAAAMIAAAogAAGAyIAAgtIgHAAIAAgSIAHAAIAAgSIAWAAIAAASIANAAIAAASIgNAAIAAAtgAhFAyIgZgaIAAAaIgXAAIAAhlIAXAAIAAA9IAXgXIAfAAIggAdIAiAigAjSAyIAAg/IAXAAIAAA/gAj1AyIAAhlIAXAAIAABlgAmKAyIAAg/IAWAAIAAALQAEgGAEgCQAGgDAHAAIAEAAIAAAUQgEgCgFAAQgLAAgDAJQgCADAAAGIAAAbgAjPgcQgEgDAAgGQAAgFAEgEQADgDAGAAQAFAAAEADQADAEAAAFQAAAGgDADQgEAEgFAAQgGAAgDgEg");
	this.shape.setTransform(-3.875,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snklik2, new cjs.Rectangle(-52,-5.2,96.3,10.5), null);


(lib.sncli = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AADApQgIgKAAgMQAAgNAIgIQAKgMARAAQAIAAAHADIAAASQgGgEgGAAQgGAAgFAFQgEAEAAAHQAAAGAEAFQAFAEAGAAQAGAAAGgEIAAATQgHADgIAAQgRAAgKgLgAh8ApQgJgKAAgMQAAgNAJgIQAKgMARAAQAIAAAHADIAAASQgGgEgGAAQgGAAgFAFQgEAEAAAHQAAAGAEAFQAFAEAGAAQAGAAAGgEIAAATQgHADgIAAQgRAAgKgLgABmAyIgZgaIAAAaIgWAAIAAhlIAWAAIAAA9IAYgWIAfAAIggAcIAiAigAglAyIAAg+IAWAAIAAA+gAhIAyIAAhlIAWAAIAABlgAgjgcQgDgDAAgGQAAgFADgDQAEgEAFAAQAFAAAEAEQAEADAAAFQAAAGgEADQgEAEgFAAQgFAAgEgEg");
	this.shape.setTransform(-0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sncli, new cjs.Rectangle(-13.4,-5.2,26.8,10.4), null);


(lib.snbr9grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AhtC6IBehzQgxgGgfgbQglgfAAg1QAAhBAngmQAmgkA4AAQA4AAAlAkQAnAnAAA/QAAAjgQAgQgOAdgjAsIhLBdgAgghWQgPAOAAATQAAATAPAOQAOAOASAAQATAAAOgOQAOgOAAgTQAAgTgOgOQgOgOgTAAQgSAAgOAOg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr9grey, new cjs.Rectangle(-13.3,-18.6,26.6,37.3), null);


(lib.snbr9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhtC6IBehzQgxgGgfgbQglgfAAg1QAAhBAngmQAmgkA4AAQA4AAAlAkQAnAnAAA/QAAAjgQAgQgOAdgjAsIhLBdgAgghWQgPAOAAATQAAATAPAOQAOAOASAAQATAAAOgOQAOgOAAgTQAAgTgOgOQgOgOgTAAQgSAAgOAOg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr9, new cjs.Rectangle(-13.3,-18.6,26.6,37.3), null);


(lib.snbr8grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AhdCdQglgjAAg1QAAgzAoghQgdgYAAgoQAAgwAiggQAjggAyAAQAyAAAjAgQAjAgAAAwQgBAsgdAUQApAgAAA0QAAA1gmAjQgmAjg3AAQg2AAgngjgAggAkQgOAPAAASQAAATAOAOQAOANASAAQASAAAOgNQAPgOAAgTQAAgSgPgPQgOgOgSAAQgSAAgOAOgAgbhnQgLAMAAAPQAAAPALAMQAMALAPAAQAPAAAMgLQAMgMAAgPQAAgPgMgMQgMgLgPAAQgPAAgMALg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr8grey, new cjs.Rectangle(-13.1,-19.1,26.2,38.3), null);


(lib.snbr8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhdCdQglgjAAg1QAAgzAoghQgdgYAAgoQAAgwAiggQAjggAyAAQAyAAAjAgQAjAgAAAwQgBAsgdAUQApAgAAA0QAAA1gmAjQgmAjg3AAQg2AAgngjgAggAkQgOAPAAASQAAATAOAOQAOANASAAQASAAAOgNQAPgOAAgTQAAgSgPgPQgOgOgSAAQgSAAgOAOgAgbhnQgLAMAAAPQAAAPALAMQAMALAPAAQAPAAAMgLQAMgMAAgPQAAgPgMgMQgMgLgPAAQgPAAgMALg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr8, new cjs.Rectangle(-13.1,-19.1,26.2,38.3), null);


(lib.snbr7grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AhzC3IB4knIiBAAIAehGIDbAAIiXFtg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr7grey, new cjs.Rectangle(-12.4,-18.2,24.9,36.5), null);


(lib.snbr7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhzC3IB4knIiBAAIAehGIDbAAIiXFtg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr7, new cjs.Rectangle(-12.4,-18.2,24.9,36.5), null);


(lib.snbr6grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AhdCVQgngmAAg/QAAgjAQghQAOgcAjgsIBMhdIBlAAIheBzQAxAGAfAaQAlAhAAA0QAABAgnAnQgmAlg4gBQg4ABglgmgAggAVQgOANAAAVQAAATAOANQAOAOATAAQATAAAOgOQAOgNAAgTQAAgVgOgNQgOgOgTgBQgTABgOAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr6grey, new cjs.Rectangle(-13.3,-18.6,26.6,37.3), null);


(lib.snbr6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhdCVQgngmAAg/QAAgjAQghQAOgcAjgsIBMhdIBlAAIheBzQAxAGAfAaQAlAhAAA0QAABAgnAnQgmAlg4gBQg4ABglgmgAggAVQgOANAAAVQAAATAOANQAOAOATAAQATAAAOgOQAOgNAAgTQAAgVgOgNQgOgOgTgBQgTABgOAOg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr6, new cjs.Rectangle(-13.3,-18.6,26.6,37.3), null);


(lib.snbr5grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AhyCvIAAhQQAbAMAfAAQBPAAAAg6QgBgzhVgHQgKAAgOACIgYABIAvizICzAAIgRBBIhhAAIgOAzQA4gBAhAfQAhAeAAA3QAABDgxAnQgrAig/AAQgcABgogMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr5grey, new cjs.Rectangle(-11.5,-18.6,23,37.3), null);


(lib.snbr5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhyCvIAAhQQAbAMAfAAQBPAAAAg6QgBgzhVgHQgKAAgOACIgYABIAvizICzAAIgRBBIhhAAIgOAzQA4gBAhAfQAhAeAAA3QAABDgxAnQgrAig/AAQgcABgogMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr5, new cjs.Rectangle(-11.5,-18.6,23,37.3), null);


(lib.snbr4grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AAPC3IAAg2IiWAAIAAg/ICWj4IBPAAIAADxIAqAAIgdBGIgNAAIAAA2gAg3A7IBGAAIAAhug");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr4grey, new cjs.Rectangle(-13.5,-18.2,27.1,36.5), null);


(lib.snbr4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAPC3IAAg2IiWAAIAAg/ICWj4IBPAAIAADxIAqAAIgdBGIgNAAIAAA2gAg3A7IBGAAIAAhug");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr4, new cjs.Rectangle(-13.5,-18.2,27.1,36.5), null);


(lib.snbr3grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ah7CpIAXhLQA2ARAZAAQAYAAAQgKQATgMAAgUQAAgWgVgOQgRgMgbAAQgPAAgHACIAAg5QBHAAAAgrQAAgRgSgKQgPgKgWAAQghAAgdASIAAhPQAkgQArAAQAwAAAiAXQAqAbAAAyQAAAygpAVQAaALAQAYQAPAZAAAdQAAA2gsAjQgqAig+AAQg4AAgrgXg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr3grey, new cjs.Rectangle(-12.4,-19.1,24.9,38.3), null);


(lib.snbr3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah7CpIAXhLQA2ARAZAAQAYAAAQgKQATgMAAgUQAAgWgVgOQgRgMgbAAQgPAAgHACIAAg5QBHAAAAgrQAAgRgSgKQgPgKgWAAQghAAgdASIAAhPQAkgQArAAQAwAAAiAXQAqAbAAAyQAAAygpAVQAaALAQAYQAPAZAAAdQAAA2gsAjQgqAig+AAQg4AAgrgXg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr3, new cjs.Rectangle(-12.4,-19.1,24.9,38.3), null);


(lib.snbr2grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AiGC8IAAgFIB/imQAagiAAgfQAAgegWgQQgVgQgiAAQgVAAgeALIAAhPQAkgJAmAAQA+AAApAiQAnAhAAA0QAAAwgfAtIg1BOIBwAAIglBVg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr2grey, new cjs.Rectangle(-13.5,-18.7,27.1,37.5), null);


(lib.snbr2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiGC8IAAgFIB/imQAagiAAgfQAAgegWgQQgVgQgiAAQgVAAgeALIAAhPQAkgJAmAAQA+AAApAiQAnAhAAA0QAAAwgfAtIg1BOIBwAAIglBVg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr2, new cjs.Rectangle(-13.5,-18.7,27.1,37.5), null);


(lib.snbr1grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgIC3IAAjgIgeASQgSAKgOACIAAhTQA3ggAVg4IBBAAIAAFtg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr1grey, new cjs.Rectangle(-7.1,-18.2,14.2,36.5), null);


(lib.snbr1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgIC3IAAjgIgeASQgSAKgOACIAAhTQA3ggAVg4IBBAAIAAFtg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr1, new cjs.Rectangle(-7.1,-18.2,14.2,36.5), null);


(lib.snbr0grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AhiCHQgig1AAhVQAAhPAig0QAlg5A9AAQA+AAAlA5QAiA0AABPQAABVgiA1QgkA5g/AAQg+AAgkg5gAgihNQgMAeAAAtQAABtAuAAQAvAAAAhtQAAgtgMgeQgNgfgWAAQgVAAgNAfg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr0grey, new cjs.Rectangle(-13.3,-19.1,26.700000000000003,38.3), null);


(lib.snbr0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhiCHQgig1AAhVQAAhPAig0QAlg5A9AAQA+AAAlA5QAiA0AABPQAABVgiA1QgkA5g/AAQg+AAgkg5gAgihNQgMAeAAAtQAABtAuAAQAvAAAAhtQAAgtgMgeQgNgfgWAAQgVAAgNAfg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snbr0, new cjs.Rectangle(-13.3,-19.1,26.700000000000003,38.3), null);


(lib.skaert = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.kartridgebadge2();
	this.instance.setTransform(-83.9,-25,0.5952,0.5952);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skaert, new cjs.Rectangle(-83.9,-25,167.9,50), null);


(lib.simlinktw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiREnQiBgFhTg0IAAgGQBZAAA+gbIAAgEQAegHASgUQAAAAABgBQAAAAABAAQAAAAABgBQAAAAABAAQAGgGgZAAIgEAAQgNgCgKgEQAAAAAAgBQAAgBAAAAQgBAAAAgBQgBAAAAAAQhAgWgShEIAEAAIAFAAQAYADANgGIAFgCQgSgPgdgIIAAgDQgyghgJhEIAAgFQAAgFABgBQANgGAXAMIAJAAIAFAAQg1gvAChrQAJgUAMgTIACAEQBBBGBdAqQA/AbBQAJQAEgJgCgUQgBghAMgYQAbhEBFgdQBngHAtAxIAGACQAwgFAjgWIADgBQgMAtgjAWQAAABAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAQAOAGAWgIIAmgNQgdAugrAfIgCACQAFBbgaA5QgDAEgBAEQghBnhEBCQgcAbggAVQg2AghBAUQgwAQg7AAIgRgBg");
	this.shape.setTransform(0,0.0215);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.simlinktw, new cjs.Rectangle(-35.8,-29.5,71.69999999999999,59.1), null);


(lib.simlinkface = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAsFOIhwAAIAAguQAAhoAChnQAAgdgFgTIAAgBIhlgBIAAgFIAAhyIBhAAIAEAAQgChCAHg7QAGgrAYgeQAug5BwALIAEABQAZgBAQAGQAGAUAAAeQAAAegGAWQgWAHgegDQgfgDgTAKQgWAbAFA6IABAoIByAAIAEAAQgIA4gHA6IAAAFIhjAAIgEAAIAADMIAABjIgFAAg");
	this.shape.setTransform(0.025,0.011);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.simlinkface, new cjs.Rectangle(-17.3,-33.4,34.7,66.9), null);


(lib.sgogle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.googlebadge2();
	this.instance.setTransform(-83.9,-25,0.5952,0.5952);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sgogle, new cjs.Rectangle(-83.9,-25,167.9,50), null);


(lib.Sengie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.smallSquareLogoBlackonWhite();
	this.instance.setTransform(-250,-250,0.7143,0.7143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Sengie, new cjs.Rectangle(-250,-250,500,500), null);


(lib.sendtxt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AH+VuQgQgTAAgcQAAggAUgVQAUgUAkAAQAsAAATAgQALATAAAYIAAAGIhlAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgKAKQgUASghAAQgqAAgVgZgAIoUcQgGAGgCAJIA3AAQgFgXgWAAQgNAAgHAIgABSVuQgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgAB5UpQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgAobV1QgXgVAAgiQAAgjAYgVQATgQAZAAQAOAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgMAHgQAAQgZAAgUgRgAn5UqQgHAJAAALQAAALAHAJQAJALAPAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgPAAgJALgAGgWCIAAhhIgQAAIAAgnIAQAAIAAgpIAwAAIAAApIAcAAIAAAnIgcAAIAABhgAFUWCIAAhFQAAgSgEgGQgGgIgMAAQgLAAgHAHQgHAHAAAOIAABJIgwAAIAAiIIAwAAIAAARQAIgKAHgEQAMgGARAAQAWAAANAMQAQANAAAbIAABXgAhlWCIAAjIIBOAAQA3AAAAA0QAAAQgGAKQgFAJgLAGQAYAFAIAPQAIANAAARQAAAWgMAOQgTAVglAAgAgxVaIAMAAQAUAAAHgEQAJgGAAgLQAAgRgSgDIgTgBIgLAAgAgxUIIAKAAQANAAAGgGQAFgFAAgIQAAgOgNgEQgEgCgHAAIgKAAgAkGWCIAAhhIgQAAIAAgnIAQAAIAAgpIAwAAIAAApIAcAAIAAAnIgcAAIAABhgAl9WCIAAiIIAwAAIAAAWQAIgMAJgFQALgHARAAIAJAAIAAAuQgKgFgKAAQgYAAgHAUQgDAHAAAMIAAA6gArYWCIAAjIIBOAAQA4AAAAA0QAAAQgGAKQgFAJgLAGQAYAFAIAPQAIANAAARQAAAWgMAOQgTAVgmAAgAqkVaIAMAAQAUAAAHgEQAJgGAAgLQAAgRgSgDIgTgBIgLAAgAqkUIIAKAAQANAAAGgGQAFgFAAgIQAAgOgNgEQgEgCgHAAIgKAAgAILOcQgOgNgEgOIgBgGIA2AAQACAHAEADQAGAFAKAAQARAAAJgMQAGgIAAgNIAAgNQgJAIgGADQgMAHgRAAQgUAAgRgLQgQgLgIgTQgFgNAAgPQAAgiAVgVQAUgTAcAAQAPAAALAGQAHAEAIAIIAAgOIAwAAIAAB+QAAASgDALQgEASgQAOQgVARgjAAQgkAAgWgTgAIwMSQgIAJAAALQAAANAJAKQAJAJANAAQANAAAJgJQAJgKAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgApWOvIAuhXIhCh1IA4AAIAkBGIAkhGIA3AAIhtDMgA3JOvIAAjMIAwAAIAAAPQAGgIAIgFQAMgGAQAAQAZAAAUARQAXAVAAAiQAAAjgYAVQgTAQgZAAQgOAAgNgGQgHgEgIgIIAABSgA2SMRQgJAJAAANQAAANAJAJQAJAJANAAQAPAAAJgLQAHgJAAgLQAAgMgHgIQgJgLgPAAQgNAAgJAJgA55OvIAAjMIAwAAIAAAPQAGgIAIgFQAMgGAQAAQAZAAAUARQAXAVAAAiQAAAjgYAVQgTAQgZAAQgOAAgNgGQgHgEgIgIIAABSgA5CMRQgJAJAAANQAAANAJAJQAJAJANAAQAPAAAJgLQAHgJAAgLQAAgMgHgIQgJgLgPAAQgNAAgJAJgAV3OIIAThJIAwAAIgfBJgAAENcQgKgNAAgWIAAhWIAvAAIAABNQAAANAGAGQAGAGAMAAQAMAAAGgGQAGgGAAgNIAAhNIAxAAIAABWQAAAmgkAMQgPAGgWAAQgqAAgTgVgAj7NcQgLgNAAgWIAAhWIAwAAIAABNQAAANAGAGQAGAGAMAAQAMAAAGgGQAGgGAAgNIAAhNIAxAAIAABWQAAAmgkAMQgPAGgWAAQgqAAgTgVgA8VNcQgLgNAAgWIAAhWIAwAAIAABNQAAANAGAGQAGAGAMAAQAMAAAGgGQAGgGAAgNIAAhNIAxAAIAABWQAAAmgkAMQgPAGgWAAQgqAAgTgVgEAgRANXQgQgTAAgcQAAggAUgVQAUgUAkAAQAsAAATAgQALATAAAYIAAAGIhlAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgKAKQgUASghAAQgqAAgVgZgEAg7AMFQgGAGgCAJIA3AAQgFgXgWAAQgNAAgHAIgAdwNXQgQgTAAgcQAAggAUgVQATgUAkAAQAtAAATAgQAKATAAAYIAAAGIhkAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgLAKQgTASghAAQgqAAgVgZgAeZMFQgGAGgBAJIA2AAQgFgXgWAAQgMAAgIAIgARiNXQgQgTAAgcQAAggAUgVQAUgUAkAAQAsAAATAgQALATAAAYIAAAGIhlAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgKAKQgUASghAAQgqAAgVgZgASMMFQgGAGgCAJIA3AAQgFgXgWAAQgNAAgHAIgAEcNXQgQgTAAgcQAAggAUgVQATgUAkAAQAtAAATAgQAKATAAAYIAAAGIhkAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgLAKQgTASghAAQgqAAgVgZgAFFMFQgGAGgBAJIA2AAQgFgXgWAAQgMAAgIAIgEAkRANgIASgiQAUAOASAAQAPAAAAgLQAAgFgFgDIgPgFIgSgEQgOgGgGgMQgCgHAAgJQAAgSAMgNQAQgRAgAAQAXAAAVAJIgQAfQgNgHgNAAQgOAAAAAKQAAAEAGADQACACANACQATAEAJAJQALALAAARQAAAWgPANQgSAQgfAAQgcAAgbgQgATxNgIARgiQAVAOARAAQAQAAAAgLQAAgFgGgDIgPgFIgRgEQgPgGgFgMQgDgHAAgJQAAgSAMgNQAQgRAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAEAGADQADACANACQATAEAIAJQAMALAAARQAAAWgQANQgRAQggAAQgcAAgagQgA0MNXQgTgUAAgdQAAgbATgUQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAcgTAUQgWAZgpAAQgpAAgWgZgAzlMSQgIAJAAAMQAAALAIAJQAJAMAPAAQANAAAKgKQAJgJAAgNQAAgNgJgKQgKgJgNAAQgPAAgJALgA+mNgIASgiQAUAOASAAQAPAAAAgLQAAgFgFgDIgPgFIgSgEQgOgGgGgMQgCgHAAgJQAAgSAMgNQAQgRAgAAQAXAAAVAJIgQAfQgNgHgNAAQgOAAAAAKQAAAEAGADQACACANACQATAEAJAJQALALAAARQAAAWgPANQgSAQgfAAQgcAAgbgQgAZTNWQgRgUAAgbQAAgbARgUQAWgZAlAAQARAAAPAHIAAApQgNgJgMAAQgOAAgKAJQgJAKAAAOQAAAOAJAKQAKAJAOAAQAMAAANgJIAAApQgPAHgRAAQglAAgWgZgAK9NeQgYgVAAgiQAAgjAYgVQAUgQAYAAQAPAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgNAHgPAAQgZAAgUgRgALfMTQgIAJAAALQAAALAIAJQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgEgiEANeQgYgVAAgiQAAgjAYgVQAUgQAYAAQAPAAANAGQAHADAIAIIAAhhIAwAAIAADcIgwAAIAAgPQgHAIgHAEQgNAHgPAAQgZAAgUgRgEghiAMTQgIAJAAALQAAALAIAJQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgEgnaANeQgYgVAAgiQAAgjAYgVQAUgQAYAAQAPAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgNAHgPAAQgZAAgUgRgEgm4AMTQgIAJAAALQAAALAIAJQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgEAmpANjQgIgIAAgLQAAgMAIgIQAIgJALAAQAMAAAIAJQAIAIAAAMQAAALgIAIQgIAIgMAAQgLAAgIgIgEAioANrIAAiIIAwAAIAAAWQAIgMAJgFQALgHARAAIAJAAIAAAuQgKgFgKAAQgYAAgHAUQgDAHAAAMIAAA6gAceNrIAAhFQAAgSgEgGQgGgJgMAAQgLAAgHAIQgHAHAAAOIAABJIgwAAIAAjcIAwAAIAABlQAJgKAHgEQALgGARAAQAWAAAOAMQAQANAAAbIAABXgAQRNrIAAhDQAAgSgEgGQgFgKgLAAQgMAAgGALQgFAHAAAQIAABDIgwAAIAAhDQAAgSgDgFQgGgLgMAAQgLAAgHAJQgCAEgBAFIgBAQIAABDIgwAAIAAiIIAwAAIAAARQAIgJAHgDQANgHAQAAQAUAAANAKQAHAFAGAKQAGgJAHgFQAOgMATAAQAPAAAMAIQANAIAEAOQACAIAAAMIAABZgACgNrIAAiIIAwAAIAAAWQAHgMAJgFQAMgHAQAAIAKAAIAAAuQgKgFgLAAQgXAAgIAUQgCAHAAAMIAAA6gAhaNrIAAhhIgQAAIAAgnIAQAAIAAgpIAwAAIAAApIAcAAIAAAnIgcAAIAABhgAlgNrIAAhhIgRAAIAAgnIARAAIAAgSQAAgeAPgQQATgVAbAAQAKAAALAFIAAAqQgKgFgHAAQgKAAgEAHQgDAEAAARIAAAPIAiAAIAAAnIgiAAIAABhgAqgNrIAAhDQAAgSgEgGQgFgKgLAAQgMAAgGALQgFAHAAAQIAABDIgwAAIAAhDQAAgSgDgFQgGgLgMAAQgLAAgHAJQgCAEgBAFIgBAQIAABDIgwAAIAAiIIAwAAIAAARQAIgJAHgDQANgHAQAAQAUAAANAKQAHAFAGAKQAGgJAHgFQAOgMATAAQAPAAAMAIQANAIAEAOQACAIAAAMIAABZgAvzNrIAAhhIgQAAIAAgnIAQAAIAAgpIAwAAIAAApIAcAAIAAAnIgcAAIAABhgAxqNrIAAiIIAwAAIAAAWQAIgMAJgFQALgHARAAIAJAAIAAAuQgKgFgKAAQgYAAgHAUQgDAHAAAMIAAA6gEgjdANrIAAhFQAAgSgEgGQgGgIgMAAQgLAAgHAHQgHAHAAAOIAABJIgwAAIAAiIIAwAAIAAARQAIgKAHgEQAMgGARAAQAWAAANAMQAQANAAAbIAABXgEAmjAMrIAAibIAxAAIAACbgAPDJNIAuhXIg8hsIAAAjQgKgFgLAAQgXAAgIAUQgCAHAAAMIAAA6IgwAAIAAiIIAwAAIAAAWQAHgMAJgFQAMgHAQAAIAKAAIAAACIAzAAIAkBGIAjhGIA3AAIhtDMgAr/JNIAuhXIhCh1IA4AAIAkBGIAkhGIA3AAIhtDMgEgmzAJNIAuhXIhCh1IA4AAIAkBGIAkhGIA3AAIhtDMgEghPAH6QgLgNAAgWIAAhWIAwAAIAABNQAAANAGAGQAGAGAMAAQAMAAAGgGQAGgGAAgNIAAhNIAxAAIAABWQAAAmgkAMQgPAGgWAAQgqAAgTgVgEAo3AH1QgQgTAAgcQAAggAUgVQATgUAkAAQAtAAATAgQAKATAAAYIAAAGIhkAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgLAKQgTASghAAQgqAAgVgZgEApgAGjQgGAGgBAJIA2AAQgFgXgWAAQgMAAgIAIgEAjyAH1QgQgTAAgcQAAggAUgVQAUgUAkAAQAsAAATAgQALATAAAYIAAAGIhlAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgKAKQgUASghAAQgqAAgVgZgEAkcAGjQgGAGgCAJIA3AAQgFgXgWAAQgNAAgHAIgAzXH1QgQgTAAgcQAAggAUgVQATgUAkAAQAtAAATAgQAKATAAAYIAAAGIhkAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgLAKQgTASghAAQgqAAgVgZgAyuGjQgGAGgBAJIA2AAQgFgXgWAAQgMAAgIAIgAfUH1QgTgUAAgdQAAgbATgUQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAcgTAUQgWAZgpAAQgpAAgWgZgAf7GwQgIAJAAAMQAAALAIAJQAJAMAPAAQANAAAKgKQAJgJAAgNQAAgNgJgKQgKgJgNAAQgPAAgJALgAabH+IARgiQAVAOARAAQAQAAAAgLQAAgFgGgDIgPgFIgRgEQgPgGgFgMQgDgHAAgJQAAgSAMgNQAQgRAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAEAGADQADACANACQATAEAIAJQAMALAAARQAAAWgQANQgRAQggAAQgcAAgagQgAKsH1QgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgALTGwQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgAoAH1QgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgAnZGwQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgEgj9AH1QgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgEgjWAGwQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgEgqiAH1QgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgEgp7AGwQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgEgs0AH+IARgiQAVAOARAAQAQAAAAgLQAAgFgGgDIgPgFIgRgEQgPgGgFgMQgDgHAAgJQAAgSAMgNQAQgRAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAEAGADQADACANACQATAEAIAJQAMALAAARQAAAWgQANQgRAQggAAQgcAAgagQgAV3H8QgXgVAAgiQAAgjAYgVQATgQAZAAQAOAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgMAHgQAAQgZAAgUgRgAWZGxQgHAJAAALQAAALAHAJQAJALAPAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgPAAgJALgAHaH0QgRgUAAgbQAAgbARgUQAWgZAlAAQARAAAPAHIAAApQgNgJgMAAQgOAAgKAJQgJAKAAAOQAAAOAJAKQAKAJAOAAQAMAAANgJIAAApQgPAHgRAAQglAAgWgZgAEwH8QgXgVAAgiQAAgjAYgVQATgQAZAAQAOAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgMAHgQAAQgZAAgUgRgAFSGxQgHAJAAALQAAALAHAJQAJALAPAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgPAAgJALgAwuH8QgYgVAAgiQAAgjAYgVQAUgQAYAAQAPAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgNAHgPAAQgZAAgUgRgAwMGxQgIAJAAALQAAALAIAJQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgA7gH8QgYgVAAgiQAAgjAYgVQAUgQAYAAQAPAAANAGQAHADAIAIIAAgNIAwAAIAACIIgwAAIAAgPQgHAIgHAEQgNAHgPAAQgZAAgUgRgA6+GxQgIAJAAALQAAALAIAJQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgA9eH0QgSgUAAgbQAAgbASgUQAWgZAlAAQARAAAOAHIAAApQgNgJgMAAQgOAAgJAJQgKAKAAAOQAAAOAKAKQAJAJAOAAQAMAAANgJIAAApQgPAHgQAAQglAAgWgZgEArOAIJIAAiIIAwAAIAAAWQAHgMAJgFQAMgHAQAAIAKAAIAAAuQgKgFgLAAQgXAAgIAUQgCAHAAAMIAAA6gEAm/AIJIhGiIIA2AAIAgBGIAhhGIA2AAIhHCIgEAh2AIJIAAiIIAwAAIAAAWQAIgMAJgFQALgHARAAIAJAAIAAAuQgKgFgKAAQgYAAgHAUQgDAHAAAMIAAA6gAdtIJIAAhhIgRAAIAAgnIARAAIAAgSQAAgeAPgQQATgVAbAAQAKAAALAFIAAAqQgKgFgHAAQgKAAgEAHQgDAEAAARIAAAPIAiAAIAAAnIgiAAIAABhgAZcIJIAAjcIAwAAIAADcgAYVIJIAAjcIAwAAIAADcgAS6IJIAAjIIBOAAQA4AAAAA0QAAAQgGAKQgFAJgLAGQAYAFAIAPQAIANAAARQAAAWgMAOQgTAVgmAAgATuHhIAMAAQAUAAAHgEQAJgGAAgLQAAgRgSgDIgTgBIgLAAgATuGPIAKAAQANAAAGgGQAFgFAAgIQAAgOgNgEQgEgCgHAAIgKAAgAJMIJIAAhhIgQAAIAAgnIAQAAIAAgpIAwAAIAAApIAbAAIAAAnIgbAAIAABhgACbIJIAAjIIBzAAIAAArIg/AAIAAAiIA5AAIAAAsIg5AAIAABPgAAHIJIAAhFQAAgSgEgGQgFgIgMAAQgLAAgHAHQgHAHAAAOIAABJIgwAAIAAiIIAwAAIAAARQAIgKAHgEQAMgGAQAAQAWAAANAMQAQANAAAbIAABXgAjFIJIgihLIghBLIggAAIhGiIIA2AAIAgBHIAjhHIAeAAIAiBJIAihJIA1AAIhHCIgAtJIJIAAjcIAwAAIAADcgAuQIJIAAjcIAwAAIAADcgA1TIJIAAiIIAwAAIAAAWQAHgMAJgFQAMgHAQAAIAKAAIAAAuQgKgFgLAAQgXAAgIAUQgCAHAAAMIAAA6gA3jIJIAAhFQAAgSgEgGQgGgIgMAAQgLAAgHAHQgHAHAAAOIAABJIgwAAIAAiIIAwAAIAAARQAIgKAHgEQAMgGARAAQAWAAANAMQAQANAAAbIAABXgAAgmKIAuhWIhBh2IA4AAIAkBGIAjhGIA3AAIhtDMgA5MmKIAuhWIg9htIAAAkQgKgFgKAAQgYAAgHATQgDAHAAAMIAAA6IgwAAIAAiIIAwAAIAAAXQAIgMAJgGQALgHARAAIAJABIAAABIAzAAIAkBGIAkhGIA3AAIhtDMgAVGndQgLgNAAgVIAAhXIAwAAIAABNQAAANAGAGQAGAHAMAAQAMAAAGgHQAGgGAAgNIAAhNIAxAAIAABXQAAAmgkAMQgPAFgWAAQgqAAgTgVgAGFndQgMgNAAgVIAAhXIAwAAIAABNQAAANAHAGQAGAHAMAAQALAAAHgHQAGgGAAgNIAAhNIAwAAIAABXQAAAmgkAMQgPAFgVAAQgrAAgSgVgEAnfgHiQgQgTAAgbQAAghAUgUQAUgUAkAAQAsAAATAgQALASAAAYIAAAGIhlAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgKAKQgUATghAAQgqAAgVgagEAoJgI0QgGAGgCAKIA3AAQgFgXgWAAQgNAAgHAHgAb+niQgQgTAAgbQAAghAUgUQATgUAkAAQAtAAATAgQAKASAAAYIAAAGIhkAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgLAKQgTATghAAQgqAAgVgagAcno0QgGAGgBAKIA2AAQgFgXgWAAQgMAAgIAHgEAjBgHhQgTgUAAgeQAAgaATgVQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAdgTAUQgWAYgpAAQgpAAgWgYgEAjogImQgIAJAAALQAAAMAIAJQAJALAPAAQANAAAKgJQAJgJAAgOQAAgNgJgJQgKgJgNAAQgPAAgJALgAfVnYIASgiQAUANASAAQAPAAAAgKQAAgGgFgDIgPgEIgSgFQgOgFgGgNQgCgGAAgJQAAgSAMgNQAQgSAgAAQAXAAAVAJIgQAfQgNgHgNAAQgOAAAAAKQAAAFAGADQACABANADQATAEAJAIQALALAAARQAAAWgPAOQgSAPgfAAQgcAAgbgPgASYnhQgSgUAAgeQAAgaASgVQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAdgSAUQgXAYgoAAQgpAAgXgYgAS/omQgHAJAAALQAAAMAHAJQAKALAPAAQANAAAJgJQAJgJAAgOQAAgNgJgJQgJgJgNAAQgPAAgKALgADXnhQgTgUAAgeQAAgaATgVQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAdgTAUQgWAYgpAAQgpAAgWgYgAD+omQgIAJAAALQAAAMAIAJQAJALAPAAQANAAAKgJQAJgJAAgOQAAgNgJgJQgKgJgNAAQgPAAgJALgAnKnhQgTgUAAgeQAAgaATgVQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAdgTAUQgWAYgpAAQgpAAgWgYgAmjomQgIAJAAALQAAAMAIAJQAJALAPAAQANAAAKgJQAJgJAAgOQAAgNgJgJQgKgJgNAAQgPAAgJALgAt1nYIASgiQAUANASAAQAPAAAAgKQAAgGgFgDIgPgEIgSgFQgOgFgGgNQgCgGAAgJQAAgSAMgNQAQgSAgAAQAXAAAVAJIgQAfQgNgHgNAAQgOAAAAAKQAAAFAGADQACABANADQATAEAJAIQALALAAARQAAAWgPAOQgSAPgfAAQgcAAgbgPgA9jnhQgTgUAAgeQAAgaATgVQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAdgTAUQgWAYgpAAQgpAAgWgYgA88omQgIAJAAALQAAAMAIAJQAJALAPAAQANAAAKgJQAJgJAAgOQAAgNgJgJQgKgJgNAAQgPAAgJALgEgrCgHhQgSgUAAgeQAAgaASgVQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAdgSAUQgXAYgoAAQgpAAgXgYgEgqbgImQgHAJAAALQAAAMAHAJQAKALAPAAQANAAAJgJQAJgJAAgOQAAgNgJgJQgJgJgNAAQgPAAgKALgEAqCgHRQgIgIAAgLQAAgMAIgIQAIgIALAAQAMAAAIAIQAIAIAAAMQAAALgIAIQgIAIgMAAQgLAAgIgIgANKnbQgXgVAAgiQAAgjAYgUQATgRAZAAQAOAAANAGQAHAEAIAIIAAgOIAwAAIAACIIgwAAIAAgPQgHAJgHAEQgMAHgQAAQgZAAgUgSgANsomQgHAJAAALQAAAMAHAIQAJALAPAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgIgNAAQgPAAgJAKgAyYnbQgYgVAAgiQAAgjAYgUQAUgRAYAAQAPAAANAGQAHAEAIAIIAAgOIAwAAIAACIIgwAAIAAgPQgHAJgHAEQgNAHgPAAQgZAAgUgSgAx2omQgIAJAAALQAAAMAIAIQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgIgNAAQgOAAgJAKgEgg1gHiQgSgVAAgbQAAgbASgUQAWgZAlAAQARAAAOAIIAAApQgNgJgMAAQgOAAgJAJQgKAJAAAOQAAAPAKAJQAJAJAOAAQAMAAANgJIAAApQgPAIgQAAQglAAgWgZgEgjfgHbQgYgVAAgiQAAgjAYgUQAUgRAYAAQAPAAANAGQAHAEAIAIIAAgOIAwAAIAACIIgwAAIAAgPQgHAJgHAEQgNAHgPAAQgZAAgUgSgEgi9gImQgIAJAAALQAAAMAIAIQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgIgNAAQgOAAgJAKgEAljgHOIAAiIIAwAAIAAAXQAIgMAJgGQALgHARAAIAJABIAAAuQgKgFgKAAQgYAAgHATQgDAHAAAMIAAA6gEAhggHOIAAhgIgQAAIAAgoIAQAAIAAgpIAwAAIAAApIAcAAIAAAoIgcAAIAABggAagnOIAAhgIgQAAIAAgoIAQAAIAAgpIAwAAIAAApIAbAAIAAAoIgbAAIAABggAZTnOIAAiIIAwAAIAACIgAXinOIAAiIIAwAAIAAAXQAHgMAJgGQAMgHAQAAIAKABIAAAuQgKgFgLAAQgXAAgIATQgCAHAAAMIAAA6gAQenOIhGiIIA2AAIAgBGIAhhGIA2AAIhHCIgALfnOIAAhgIgSAAIAAgoIASAAIAAgSQAAgeAPgQQATgUAaAAQALAAAKAFIAAAqQgJgGgHAAQgKAAgFAIQgCAEAAARIAAAOIAhAAIAAAoIghAAIAABggAIgnOIAAiIIAwAAIAAAXQAIgMAJgGQALgHARAAIAJABIAAAuQgKgFgKAAQgYAAgHATQgDAHAAAMIAAA6gAhynOIAAhDQAAgRgDgHQgGgJgLAAQgMAAgGAKQgFAHAAAQIAABDIgwAAIAAhDQAAgRgDgGQgGgKgMAAQgLAAgGAJQgDADgBAGIgBAPIAABDIgwAAIAAiIIAwAAIAAARQAJgIAHgEQANgHAPAAQAVAAANALQAHAFAGAJQAFgJAHgFQAPgLASAAQAQAAAMAHQAMAIAEAOQADAIAAANIAABYgApJnOIAAiIIAwAAIAAAXQAIgMAJgGQALgHARAAIAJABIAAAuQgKgFgKAAQgYAAgHATQgDAHAAAMIAAA6gAqinOIAAhgIgSAAIAAgoIASAAIAAgSQAAgeAPgQQATgUAaAAQALAAAKAFIAAAqQgJgGgHAAQgKAAgFAIQgCAEAAARIAAAOIAhAAIAAAoIghAAIAABggAuznOIAAjcIAwAAIAADcgAv6nOIAAjcIAwAAIAADcgA1VnOIAAjIIBNAAQA4AAAAA0QAAAQgGALQgFAJgLAGQAYAFAJAOQAIANAAARQAAAXgNAOQgSAUgmAAgA0hn1IALAAQAUAAAIgFQAJgFAAgLQAAgSgSgDIgUAAIgKAAgA0hpHIAJAAQAOAAAFgHQAFgFAAgIQAAgNgMgFQgEgBgIAAIgJAAgA/EnOIAAhgIgQAAIAAgoIAQAAIAAgpIAwAAIAAApIAcAAIAAAoIgcAAIAABggEgl0gHOIAAjIIByAAIAAAsIg+AAIAAAiIA5AAIAAArIg5AAIAABPgEgobgHOIAAhgIgSAAIAAgoIASAAIAAgSQAAgeAPgQQATgUAaAAQALAAAKAFIAAAqQgJgGgHAAQgKAAgFAIQgCAEAAARIAAAOIAhAAIAAAoIghAAIAABggEAqCgJFQgIgHAAgMQAAgLAIgIQAIgJALAAQAMAAAIAJQAIAIAAALQAAAMgIAHQgIAIgMAAQgLAAgIgIgAZYp3QgIgIAAgLQAAgLAIgIQAIgIALAAQALAAAIAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIgAJNqnIAFgBIAGABgAimsaQgOgNgEgOIgBgGIA2AAQACAHAEACQAGAFAKAAQARAAAJgMQAGgHAAgOIAAgNQgJAIgGADQgMAHgRAAQgUAAgRgLQgQgLgIgTQgFgNAAgPQAAghAVgVQAUgTAcAAQAPAAALAGQAHADAIAJIAAgPIAwAAIAAB/QAAASgDALQgEARgQAOQgVASgjAAQgkAAgWgTgAiBulQgIAJAAAMQAAANAJAJQAJAJANAAQANAAAJgJQAJgJAAgNQAAgNgJgKQgJgJgNAAQgOAAgJALgAuVsaQgPgNgDgOIgCgGIA2AAQADAHAEACQAGAFAKAAQARAAAJgMQAFgHAAgOIAAgNQgIAIgGADQgMAHgRAAQgVAAgQgLQgRgLgHgTQgFgNAAgPQAAghAVgVQAUgTAbAAQAPAAAMAGQAHADAHAJIAAgPIAwAAIAAB/QAAASgCALQgEARgRAOQgVASgiAAQglAAgVgTgAtxulQgHAJAAAMQAAANAJAJQAJAJANAAQANAAAJgJQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgJALgAREtFIAAg/Ig9AAIAAgSIA9AAIAAhAIASAAIAABAIA9AAIAAASIg9AAIAAA/gEAjdgNgQgQgTAAgbQAAghAUgUQATgUAkAAQAtAAATAgQAKASAAAYIAAAGIhkAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgLAKQgTATghAAQgqAAgVgagEAkGgOyQgGAGgBAKIA2AAQgFgXgWAAQgMAAgIAHgAaLtgQgQgTAAgbQAAghAUgUQAUgUAkAAQAsAAATAgQALASAAAYIAAAGIhlAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgKAKQgUATghAAQgqAAgVgagAa1uyQgGAGgCAKIA3AAQgFgXgWAAQgNAAgHAHgAVHtgQgQgTAAgbQAAghAUgUQATgUAkAAQAtAAATAgQAKASAAAYIAAAGIhkAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgLAKQgTATghAAQgqAAgVgagAVwuyQgGAGgBAKIA2AAQgFgXgWAAQgMAAgIAHgAFLtgQgQgTAAgbQAAghAUgUQAUgUAkAAQAsAAATAgQALASAAAYIAAAGIhlAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgKAKQgUATghAAQgqAAgVgagAF1uyQgGAGgCAKIA3AAQgFgXgWAAQgNAAgHAHgArrtgQgQgTAAgbQAAghAUgUQATgUAkAAQAtAAATAgQAKASAAAYIAAAGIhkAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgLAKQgTATghAAQgqAAgVgagArCuyQgGAGgBAKIA2AAQgFgXgWAAQgMAAgIAHgAz2tgQgQgTAAgbQAAghAUgUQATgUAkAAQAtAAATAgQAKASAAAYIAAAGIhkAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgLAKQgTATghAAQgqAAgVgagAzNuyQgGAGgBAKIA2AAQgFgXgWAAQgMAAgIAHgEgkigNgQgQgTAAgbQAAghAUgUQATgUAkAAQAtAAATAgQAKASAAAYIAAAGIhkAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgLAKQgTATghAAQgqAAgVgagEgj5gOyQgGAGgBAKIA2AAQgFgXgWAAQgMAAgIAHgEgrxgNgQgQgTAAgbQAAghAUgUQAUgUAkAAQAsAAATAgQALASAAAYIAAAGIhlAAQAAAfAdAAQAPAAAIgNIAvAAQgGASgKAKQgUATghAAQgqAAgVgagEgrHgOyQgGAGgCAKIA3AAQgFgXgWAAQgNAAgHAHgEAq2gNfQgSgUAAgeQAAgaASgVQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAdgSAUQgXAYgoAAQgpAAgXgYgEArdgOkQgHAJAAALQAAAMAHAJQAKALAPAAQANAAAJgJQAJgJAAgOQAAgNgJgJQgJgJgNAAQgPAAgKALgEAndgNWIARgiQAVANARAAQAQAAAAgKQAAgGgGgDIgPgEIgRgFQgPgFgFgNQgDgGAAgJQAAgSAMgNQAQgSAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAFAGADQADABANADQATAEAIAIQAMALAAARQAAAWgQAOQgRAPggAAQgcAAgagPgAdhtWIARgiQAVANARAAQAQAAAAgKQAAgGgGgDIgPgEIgRgFQgPgFgFgNQgDgGAAgJQAAgSAMgNQAQgSAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAFAGADQADABANADQATAEAIAIQAMALAAARQAAAWgQAOQgRAPggAAQgcAAgagPgA59tWIARgiQAVANARAAQAQAAAAgKQAAgGgGgDIgPgEIgRgFQgPgFgFgNQgDgGAAgJQAAgSAMgNQAQgSAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAFAGADQADABANADQATAEAIAIQAMALAAARQAAAWgQAOQgRAPggAAQgcAAgagPgA+9tfQgTgUAAgeQAAgaATgVQAXgZAqAAQAmAAAXAZQATAUAAAcQAAAdgTAUQgWAYgpAAQgpAAgWgYgA+WukQgIAJAAALQAAAMAIAJQAJALAPAAQANAAAKgJQAJgJAAgOQAAgNgJgJQgKgJgNAAQgPAAgJALgEgmygNWIARgiQAVANARAAQAQAAAAgKQAAgGgGgDIgPgEIgRgFQgPgFgFgNQgDgGAAgJQAAgSAMgNQAQgSAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAFAGADQADABANADQATAEAIAIQAMALAAARQAAAWgQAOQgRAPggAAQgcAAgagPgA2ftZQgXgVAAgiQAAgjAYgUQATgRAZAAQAOAAANAGQAHAEAIAIIAAhiIAwAAIAADcIgwAAIAAgPQgHAJgHAEQgMAHgQAAQgZAAgUgSgA19ukQgHAJAAALQAAAMAHAIQAJALAPAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgPAAgJALgEgg2gNgQgSgVAAgbQAAgbASgUQAWgZAlAAQARAAAOAIIAAApQgNgJgMAAQgOAAgJAJQgKAJAAAOQAAAPAKAJQAJAJAOAAQAMAAANgJIAAApQgPAIgQAAQglAAgWgZgEgpIgNZQgXgVAAgiQAAgjAYgUQATgRAZAAQAOAAANAGQAHAEAIAIIAAgOIAwAAIAACIIgwAAIAAgPQgHAJgHAEQgMAHgQAAQgZAAgUgSgEgomgOkQgHAJAAALQAAAMAHAIQAJALAPAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgIgNAAQgPAAgJAKgAN0tkQgRgbAAgrQAAgnARgaQATgcAfAAQAfAAASAcQASAaAAAnQAAArgSAbQgSAcgfAAQgfAAgTgcgAOUvOQgGAOAAAXQAAA3AYAAQAYAAAAg3QAAgXgGgOQgHgQgLAAQgLAAgHAQgALYtkQgRgbAAgrQAAgnARgaQATgcAfAAQAfAAASAcQASAaAAAnQAAArgSAbQgSAcgfAAQgfAAgTgcgAL4vOQgGAOAAAXQAAA3AYAAQAYAAAAg3QAAgXgGgOQgHgQgLAAQgLAAgHAQgEAu4gNMIAAhEQAAgSgEgGQgGgJgMAAQgLAAgHAIQgHAGAAAOIAABJIgwAAIAAiIIAwAAIAAARQAIgJAHgEQAMgHARAAQAWAAANAMQAQAOAAAbIAABWgEApigNMIAAiIIAwAAIAACIgEAl0gNMIAAiIIAwAAIAAAXQAHgMAJgGQAMgHAQAAIAKABIAAAuQgKgFgLAAQgXAAgIATQgCAHAAAMIAAA6gEAhlgNMIhGiIIA2AAIAgBGIAhhGIA2AAIhHCIgAcitMIAAjcIAwAAIAADcgAYTtMIhGiIIA2AAIAhBGIAghGIA2AAIhHCIgAT1tMIAAjcIAwAAIAADcgAIstMIAAgCIBAhTQANgSAAgPQAAgPgLgIQgKgIgRAAQgLAAgPAGIAAgoQASgEATAAQAgAAAUAQQAUARAAAaQAAAYgQAXIgbAnIA4AAIgSAqgAD6tMIAAhEQAAgTgEgFQgGgJgMAAQgLAAgHAHQgHAHAAAOIAABJIgwAAIAAjcIAwAAIAABlQAIgJAHgEQAMgHARAAQAVAAAOAMQAQAOAAAbIAABWgABHtMIAAhgIgQAAIAAgoIAQAAIAAgpIAwAAIAAApIAcAAIAAAoIgcAAIAABggAj8tMIAAhEQAAgSgEgGQgGgJgMAAQgLAAgHAIQgHAGAAAOIAABJIgwAAIAAiIIAwAAIAAARQAIgJAHgEQAMgHARAAQAWAAANAMQAQAOAAAbIAABWgAmitMIAAiIIAwAAIAACIgAn2tMIAAhgIgpAAIAABgIgwAAIAAhgIgQAAIAAgoIAQAAIAAgpIAwAAIAAApIApAAIAAgpIAwAAIAAApIAcAAIAAAoIgcAAIAABggAxftMIAAiIIAwAAIAAAXQAHgMAJgGQAMgHAQAAIAKABIAAAuQgKgFgLAAQgXAAgIATQgCAHAAAMIAAA6gA34tMIAAiIIAwAAIAACIgA68tMIAAhEQAAgSgEgGQgGgJgMAAQgLAAgHAIQgHAGAAAOIAABJIgwAAIAAiIIAwAAIAAARQAJgJAHgEQALgHARAAQAWAAAOAMQAQAOAAAbIAABWgEgtCgNMIAAjcIAwAAIAADcgEgvngNMIAAjIIBSAAQAkAAASAVQAQASAAAbQAAAbgNASQgQAXgnAAIggAAIAABCgEguzgO4IARAAQARAAAGgHQAGgHAAgLQAAgLgHgHQgGgHgQAAIgRAAgEApngP1QgIgIAAgLQAAgLAIgIQAIgIALAAQALAAAIAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIgAmev1QgHgIAAgLQAAgLAHgIQAIgIAMAAQALAAAIAIQAIAIAAALQAAALgIAIQgIAIgLAAQgMAAgIgIgA3zv1QgIgIAAgLQAAgLAIgIQAIgIALAAQALAAAIAIQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIgAGRxmIAuhXIhCh1IA4AAIAkBGIAkhGIA3AAIhtDMgACXxmIAAjMIAwAAIAADMgAr4xmIAuhXIhCh1IA4AAIAkBGIAkhGIA3AAIhtDMgAmUy5QgLgNAAgWIAAhWIAwAAIAABNQAAANAGAGQAGAGAMAAQAMAAAGgGQAGgGAAgNIAAhNIAxAAIAABWQAAAmgkAMQgPAGgWAAQgqAAgTgVgAily+QgQgTAAgcQAAggAUgVQAUgUAkAAQAsAAATAgQALATAAAYIAAAGIhlAAQAAAeAdAAQAPAAAIgNIAvAAQgGATgKAKQgUASghAAQgqAAgVgZgAh70QQgGAGgCAJIA3AAQgFgXgWAAQgNAAgHAIgAPBy1IARgiQAVAOARAAQAQAAAAgLQAAgFgGgDIgPgFIgRgEQgPgGgFgMQgDgHAAgJQAAgSAMgNQAQgRAhAAQAWAAAWAJIgQAfQgOgHgMAAQgPAAAAAKQAAAEAGADQADACANACQATAEAIAJQAMALAAARQAAAWgQANQgRAQggAAQgcAAgagQgADry+QgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgAES0DQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgApCy+QgSgUAAgdQAAgbASgUQAXgZAqAAQAnAAAXAZQASAUAAAcQAAAcgSAUQgXAZgoAAQgpAAgXgZgAob0DQgHAJAAAMQAAALAHAJQAKAMAPAAQANAAAJgKQAJgJAAgNQAAgNgJgKQgJgJgNAAQgPAAgKALgASIytQgIgIAAgLQAAgLAIgIQAHgIAMAAQALAAAHAIQAIAIAAALQAAALgIAIQgHAHgLAAQgMAAgHgHgAviy3QgYgVAAgiQAAgjAYgVQAUgQAYAAQAPAAANAGQAHADAIAIIAAhhIAwAAIAADcIgwAAIAAgPQgHAIgHAEQgNAHgPAAQgZAAgUgRgAvA0CQgIAJAAALQAAALAIAJQAJALAOAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgJgJgNAAQgOAAgJALgAOCyqIAAiIIAwAAIAACIgAM7yqIAAhFQAAgSgEgGQgGgJgMAAQgLAAgHAIQgHAHAAAOIAABJIgwAAIAAjcIAwAAIAABlQAJgKAHgEQALgGARAAQAWAAAOAMQAQANAAAbIAABXgAKJyqIAAhhIgQAAIAAgnIAQAAIAAgpIAwAAIAAApIAbAAIAAAnIgbAAIAABhgABQyqIAAhFQAAgSgEgGQgGgIgMAAQgLAAgHAHQgHAHAAAOIAABJIgvAAIAAiIIAvAAIAAARQAJgKAHgEQALgGARAAQAWAAAOAMQAQANAAAbIAABXgAw7yqIAAiIIAwAAIAACIgAz9yqIAAjIIBMAAQAdAAAYAPQAXAQANAZQAKAVAAAXQAAAfgTAbQgTAagdAKQgPAGgRAAgAzJzWIAMAAQAeAAAQgUQALgQAAgUQAAgVgLgPQgQgVgeAAIgMAAgASEzlIAAg3QAMAFAHAAQANAAAJgJQAJgJAAgNQAAgNgJgJQgKgKgMAAQgLAAgKAJQgJAIgCALIgugGQAFgcAUgTQAWgUAfAAQAjAAAWAWQAWAVAAAiQAAAjgVATQgQAPgQAAIAAAMgAOH1TQgIgIAAgLQAAgMAIgIQAIgHALAAQALAAAIAHQAIAIAAAMQAAALgIAIQgIAIgLAAQgLAAgIgIgACc1TQgIgIAAgLQAAgMAIgIQAIgHALAAQALAAAIAHQAIAIAAAMQAAALgIAIQgIAIgLAAQgLAAgIgIgAw31TQgHgIAAgLQAAgMAHgIQAIgHAMAAQALAAAIAHQAIAIAAAMQAAALgIAIQgIAIgLAAQgMAAgIgIg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sendtxt, new cjs.Rectangle(-304.8,-141.5,609.7,283.1), null);


(lib.sendseethrough = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhK/A4QMAAAhwfMCV/AAAMAAABwfgEgQjgpkQm4G4AAJtQAAJtG4G3QG3G4JsAAQJuAAG2m4QG4m3AAptQAAptm4m4Qm2m3puAAQpsAAm3G3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sendseethrough, new cjs.Rectangle(-480,-360,960,720), null);


(lib.sendbl = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A+YIDIAAwFMA8xAAAIAAQFg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sendbl, new cjs.Rectangle(-194.5,-51.4,389,102.9), null);


(lib.sbravo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhubgQgOgPAAgaIAAhoIA6AAIAABdQAAAPAIAHQAHAIAOAAQAOAAAIgIQAHgHAAgPIAAhdIA5AAIAABoQAAAtgrAPQgRAGgaAAQgyAAgXgZgAt+bgQgPgPAAgaIAAhoIA7AAIAABdQAAAPAHAHQAIAIANAAQAOAAAJgIQAGgHAAgPIAAhdIA7AAIAABoQgBAtgrAPQgRAGgbAAQgyAAgWgZgADkbaQgTgXAAghQAAgnAYgYQAYgYArAAQA1AAAXAmQANAWAAAdIAAAHIh6AAQAAAlAkAAQASAAAJgPIA4AAQgGAWgNAMQgXAWgoAAQgzAAgZgfgAEWZ4QgHAHgCAMIBCAAQgGgcgbAAQgPAAgJAJgAJ5buQgKgJAAgOQAAgOAKgKQAKgKAOAAQAOAAAJAKQALAKgBAOQABAOgLAJQgJAKgOAAQgOAAgKgKgAlsbZQgVgYAAggQAAggAVgZQAbgeAsAAQAUAAARAJIAAAxQgPgLgOAAQgRAAgLAMQgMALAAARQAAARAMALQALALARAAQAOAAAPgKIAAAxQgRAJgUAAQgsAAgbgfgAo6bjQgcgZAAgpQAAgqAdgZQAXgUAeAAQASAAAPAHQAIAEAKAKIAAgQIA5AAIAACjIg5AAIAAgSQgJALgIAEQgOAJgUAAQgeAAgYgVgAoQaJQgJAKAAAOQAAANAJALQAKANASAAQAPAAALgLQALgLAAgPQgBgQgKgLQgLgKgPAAQgSAAgKANgA0UbjQgdgZAAgpQAAgqAdgZQAXgUAeAAQASAAAOAHQAKAEAIAKIAAgQIA7AAIAACjIg7AAIAAgSQgHALgJAEQgPAJgSAAQgfAAgXgVgAzsaJQgIAKgBAOQABANAIALQALANASAAQAPAAALgLQALgLAAgPQAAgQgMgLQgKgKgPAAQgSAAgLANgAGbbyIAAijIA7AAIAAAbQAJgOAKgHQAPgIATAAIALAAIAAA3QgMgGgNAAQgcAAgIAYQgDAIAAAOIAABGgABNbyIAAijIA7AAIAAAbQAIgOALgHQAPgIATAAIALAAIAAA3QgMgGgNAAQgcAAgIAYQgDAIAAAOIAABGgAjibyIAAh0IgTAAIAAgvIATAAIAAgxIA6AAIAAAxIAhAAIAAAvIghAAIAAB0gAq9byIAAhzIgVAAIAAgwIAVAAIAAgVQAAglASgTQAXgYAgAAQANAAAMAGIAAAyQgMgHgIAAQgMAAgFAJQgDAFAAAVIAAARIAoAAIAAAwIgoAAIAABzgAvjbyIAAhSQAAgWgFgHQgHgKgOAAQgNAAgKAJQgHAIAAARIAABXIg7AAIAAijIA7AAIAAAVQAJgMAJgFQAOgHAUAAQAaAAARAOQATAQAAAgIAABogA2BbyIAAhQQAAgVgFgIQgGgMgNAAQgOAAgIANQgFAJgBATIAABQIg5AAIAAhQQAAgVgEgHQgHgMgOAAQgOAAgHALQgEADgBAHQgBAHAAAMIAABQIg6AAIAAijIA6AAIAAAUQAKgKAIgEQAQgJATAAQAYAAAQANQAIAGAHAMQAHgLAJgGQARgOAWAAQASAAAPAJQAPAKAFAQQADAKgBAPIAABqgAJ0aoIAAhFQAPAGAJAAQARAAALgLQALgMAAgQQAAgQgLgMQgMgMgPAAQgOAAgNALQgMALgBAOIg7gIQAHgkAZgXQAbgZAoAAQAsAAAbAbQAcAbAAAqQABAsgbAZQgUASgUAAIAAAPgAqzXBIA3hoIhLiGIAAAuQgMgGgMAAQgdAAgIAYQgEAIAAAOIAABGIg5AAIAAijIA5AAIAAAbQAKgOAKgHQAOgIAUAAIALAAIAAACIA/AAIArBUIArhUIBCAAIiDD1gADAVjIAVgpQAZAQAVAAQASAAAAgMQAAgHgGgEQgFgCgNgDIgWgFQgRgHgGgPQgDgIgBgLQAAgVAPgQQATgVAnAAQAcAAAZALIgUAlQgPgIgPAAQgRAAAAAMQAAAFAGAEIATAEQAXAFAKAKQAOANAAAVQAAAagSARQgWASgmAAQghAAgggSgAwGVYQgWgYgBgkQABggAWgYQAbgeAzAAQAuAAAcAeQAWAYAAAiQAAAigWAYQgcAdgwAAQgxAAgbgdgAvXUFQgJALAAAOQAAAOAJAKQALAOASAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgSAAgLANgAiiVgQgcgZgBgpQAAgqAdgZQAXgUAeAAQASAAAPAHQAJAEAJAKIAAgQIA6AAIAACjIg6AAIAAgSQgIALgJAEQgOAJgTAAQgeAAgYgVgAh5UGQgJAKAAAOQAAANAJALQAKANASAAQAPAAALgLQALgLAAgPQAAgQgLgLQgKgKgQAAQgSAAgKANgAlCVsQgJgFgIgKIAAASIg6AAIAAkIIA6AAIAAB1QAKgJAIgFQAQgHARAAQAeAAAWAUQAdAZAAAqQAAApgcAZQgXAVgfAAQgSAAgPgJgAlKUDQgLALABAQQgBAPALALQALALAQAAQARAAALgNQAIgLABgNQgBgOgIgKQgMgNgQAAQgQAAgLAKgA0FVWQgWgYAAggQAAggAWgZQAZgeAtAAQAUAAASAJIAAAxQgQgLgOAAQgRAAgMAMQgLALABARQgBARALALQAMALARAAQAOAAAQgKIAAAxQgSAJgUAAQgtAAgZgfgA3TVgQgdgZAAgpQAAgqAdgZQAXgUAeAAQARAAAPAHQAKAEAIAKIAAgQIA7AAIAACjIg7AAIAAgSQgHALgJAEQgPAJgSAAQgfAAgXgVgA2rUGQgIAKgBAOQABANAIALQALANARAAQAQAAALgLQALgLgBgPQAAgQgLgLQgKgKgQAAQgRAAgLANgABzVvIAAkIIA6AAIAAEIgAAcVvIAAkIIA6AAIAAEIgAx7VvIAAh0IgTAAIAAgvIATAAIAAgxIA5AAIAAAxIAhAAIAAAvIghAAIAAB0gA5XVvIAAhzIgUAAIAAgwIAUAAIAAgVQAAglASgTQAXgYAfAAQAOAAAMAGIAAAyQgLgHgJAAQgLAAgGAJQgDAFAAAVIAAARIAoAAIAAAwIgoAAIAABzgAqxRJIAAj0IA6AAIAAASQAIgKAIgFQAPgIAUAAQAdAAAZAUQAbAZAAAqQAAApgcAZQgXAUgeAAQgSAAgPgHQgJgFgJgJIAABhgApuOMQgLALAAAPQAAAQALALQALAKAPAAQASAAAKgNQAJgKAAgOQAAgOgJgKQgKgNgSAAQgPAAgLALgAABPgQgTgXAAghQAAgnAXgZQAYgYAsAAQA0AAAXAnQANAWAAAdIAAAHIh5AAQAAAlAkAAQASAAAJgQIA4AAQgHAWgNAMQgXAWgnAAQgzAAgZgegAAzN9QgIAHgBAMIBBAAQgGgcgaAAQgPAAgJAJgAzwPgQgUgXABghQAAgnAXgZQAYgYAsAAQA1AAAWAnQANAWABAdIAAAHIh6AAQAAAlAjAAQATAAAJgQIA4AAQgGAWgOAMQgXAWgoAAQgyAAgZgegAy+N9QgIAHgBAMIBCAAQgHgcgbAAQgOAAgJAJgAJPPgQgWgYAAgjQAAggAWgZQAcgdAyAAQAuAAAcAdQAWAZAAAhQAAAigWAYQgbAegxAAQgxAAgbgegAJ+OOQgJAKAAAOQAAAOAJALQALANASAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgSAAgLAOgAFGPrIAVgpQAZAQAVAAQASAAAAgMQAAgGgHgEQgEgCgOgDIgVgGQgRgHgGgOQgDgIgBgLQAAgWAPgQQATgUAnAAQAcAAAZAKIgTAmQgQgJgPAAQgRAAAAAMQAAAGAGADQAEACAPADQAXAFAKAKQAOANAAAVQAAAagSAQQgVATgnAAQghAAgggTgACuPrIAVgpQAZAQAVAAQASAAAAgMQAAgGgGgEQgFgCgNgDIgWgGQgRgHgGgOQgDgIgBgLQAAgWAPgQQATgUAnAAQAcAAAZAKIgTAmQgQgJgPAAQgRAAAAAMQAAAGAGADQAEACAPADQAXAFAKAKQAOANAAAVQAAAagSAQQgWATgmAAQghAAgggTgAlCPgQgXgYAAgjQAAggAXgZQAcgdAxAAQAvAAAbAdQAXAZAAAhQAAAigXAYQgbAegwAAQgxAAgbgegAkTOOQgJAKAAAOQAAAOAJALQALANASAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgSAAgLAOgAPzPoQgdgZAAgpQAAgqAdgZQAXgTAeAAQASAAAOAHQAKAEAIAKIAAgQIA7AAIAACjIg7AAIAAgSQgHAKgJAFQgPAIgSAAQgfAAgXgVgAQbOOQgIALgBANQABAOAIAKQALANARAAQAQAAALgLQALgKAAgQQAAgPgMgLQgKgLgQAAQgRAAgLANgAvJPoQgdgZAAgpQAAgqAdgZQAXgTAeAAQARAAAPAHQAKAEAIAKIAAgQIA7AAIAACjIg7AAIAAgSQgHAKgJAFQgPAIgSAAQgfAAgXgVgAuhOOQgIALgBANQABAOAIAKQALANARAAQAQAAALgLQALgKgBgQQAAgPgLgLQgKgLgQAAQgRAAgLANgA5GPoQgdgZABgpQAAgqAcgZQAYgTAeAAQARAAAPAHQAJAEAJAKIAAgQIA6AAIAACjIg6AAIAAgSQgIAKgIAFQgPAIgTAAQgfAAgXgVgA4dOOQgJALAAANQAAAOAJAKQALANARAAQAPAAAMgLQAKgKAAgQQAAgPgLgLQgLgLgPAAQgRAAgLANgASyP4IAAkIIA5AAIAAEIgAOGP4IAAhTQAAgVgFgHQgHgLgOAAQgNAAgKAJQgHAIgBARIAABYIg5AAIAAijIA5AAIAAAUQAKgLAJgFQAOgIAUAAQAaAAARAOQATARAAAgIAABogAHoP4IAAijIA6AAIAACjgAh5P4IAAh0IgUAAIAAgvIAUAAIAAgWQABgkARgUQAXgYAgAAQANAAANAGIAAAyQgMgGgIAAQgMAAgFAJQgDAFgBAUIAAASIApAAIAAAvIgpAAIAAB0gAncP4IAAijIA6AAIAAAaQAJgOAKgGQAPgJAUAAIAKABIAAA3QgMgGgMAAQgdAAgIAXQgDAJAAAOIAABGgA2HP4IAAijIA6AAIAAAaQAJgOALgGQAOgJAUAAIALABIAAA3QgNgGgMAAQgdAAgIAXQgDAJAAAOIAABGgAHuMtQgKgKAAgNQAAgNAKgKQAKgJANAAQANAAAKAJQAKAKAAANQAAAOgKAJQgKAJgNAAQgNAAgKgJgAN2LSIA3hoIhPiNIBEAAIArBUIAqhUIBDAAIiED1gAUmJuQgPgPAAgaIAAhoIA7AAIAABdQAAAPAHAHQAIAIAOAAQAOAAAHgIQAIgHgBgPIAAhdIA7AAIAABoQAAAtgrAPQgSAGgaAAQgzAAgWgZgAyvJuQgOgPAAgaIAAhoIA6AAIAABdQAAAPAIAHQAHAIAOAAQAOAAAIgIQAHgHAAgPIAAhdIA6AAIAABoQAAAtgrAPQgSAGgaAAQgyAAgXgZgAhvJoQgSgXgBghQAAgnAZgYQAXgYArAAQA0AAAYAmQANAWgBAdIAAAHIh4AAQAAAlAjAAQATAAAJgPIA3AAQgGAWgNAMQgYAWgmAAQgzAAgagfgAg8IGQgHAHgCAMIBBAAQgGgcgbAAQgOAAgJAJgA40JqQgtglAAg8QAAg8AtglQAlgdAtAAQAaAAAeAMIAABLQgIgLgKgFQgQgKgUAAQgYAAgRAOQgYATAAAgQAAAgAYATQARAOAYAAQAUAAAQgKQAKgFAIgLIAABLQgeAMgaAAQguAAgkgdgARTJpQgXgYAAgkQAAggAXgYQAbgeAyAAQAvAAAbAeQAXAYAAAiQAAAigXAYQgbAdgwAAQgxAAgbgdgASCIWQgJALAAAOQAAAOAJAKQALAOASAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgSAAgLANgA2BJpQgXgYAAgkQAAggAXgYQAbgeAyAAQAuAAAcAeQAXAYgBAiQABAigXAYQgbAdgxAAQgwAAgbgdgA1TIWQgJALAAAOQAAAOAJAKQAMAOARAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgRAAgMANgAHtJxQgcgZgBgpQAAgqAdgZQAYgUAdAAQASAAAPAHQAJAEAJAKIAAgQIA6AAIAACjIg6AAIAAgSQgIALgJAEQgOAJgTAAQgeAAgYgVgAIWIXQgJAKAAAOQAAANAJALQAKANASAAQAQAAALgLQAKgLAAgPQAAgQgLgLQgKgKgQAAQgSAAgKANgAkGJ9QgIgFgIgKIAAASIg6AAIAAkIIA6AAIAAB1QAJgJAJgFQAPgHASAAQAdAAAXAUQAdAZAAAqQAAApgcAZQgYAVgeAAQgTAAgPgJgAkNIUQgLALAAAQQAAAPALALQALALAPAAQASAAALgNQAIgLABgNQgBgOgIgKQgLgNgSAAQgPAAgLAKgAuGJxQgcgZAAgpQAAgqAdgZQAXgUAeAAQASAAAPAHQAIAFAKAJIAAh1IA5AAIAAEIIg5AAIAAgSQgJALgIAEQgOAJgUAAQgeAAgYgVgAtcIXQgKAKABAOQgBANAKALQAKANASAAQAPAAALgLQAKgKAAgQQABgQgLgLQgLgKgPAAQgSAAgKANgAKzKAIAAh0IgTAAIAAgvIATAAIAAgxIA6AAIAAAxIAgAAIAAAvIggAAIAAB0gAGAKAIAAhSQAAgWgEgHQgIgKgOAAQgNAAgJAJQgIAIAAARIAABXIg6AAIAAkIIA6AAIAAB6QAKgMAIgFQAPgIAUAAQAZAAASAPQATAQAAAgIAABogACoKAIAAh0IgTAAIAAgvIATAAIAAgxIA6AAIAAAxIAhAAIAAAvIghAAIAAB0gAoPKAIAAh0IgTAAIAAgvIATAAIAAgxIA5AAIAAAxIAiAAIAAAvIgiAAIAAB0gAptKAIAAijIA6AAIAACjgAvzKAIAAkIIA7AAIAAEIgApnG1QgKgJAAgNQAAgOAKgJQAJgKAOAAQANAAAKAKQAJAJAAAOQAAANgJAKQgKAJgNAAQgOAAgJgKgAIllnIAAj1IA6AAIAAASQAIgKAJgFQAOgIAUAAQAeAAAYAVQAcAZAAApQAAAqgeAZQgWAUgeAAQgRAAgQgIQgIgEgKgKIAABigAJoolQgKALAAAQQAAAPAKALQALALAQAAQARAAAKgNQAKgLgBgNQABgOgKgKQgKgNgRAAQgQAAgLAKgASOnRQgTgXAAghQAAgnAYgYQAXgYAsAAQA1AAAXAmQANAWAAAdIAAAHIh6AAQAAAlAkAAQASAAAJgPIA5AAQgHAWgNAMQgYAWgnAAQgzAAgZgfgATBozQgIAHgBAMIBBAAQgGgcgbAAQgPAAgIAJgANdnRQgSgXgBghQAAgnAZgYQAXgYArAAQA1AAAYAmQANAWgBAdIAAAHIh5AAQAAAlAkAAQARAAAKgPIA4AAQgGAWgNAMQgYAWgnAAQgzAAgagfgAOQozQgIAHgBAMIBBAAQgGgcgbAAQgOAAgJAJgApynRQgTgXAAghQAAgnAYgYQAYgYArAAQA1AAAXAmQANAWAAAdIAAAHIh6AAQAAAlAkAAQASAAAJgPIA4AAQgGAWgNAMQgXAWgoAAQgzAAgZgfgApAozQgHAHgCAMIBCAAQgGgcgbAAQgPAAgJAJgAv8nRQgSgXgBghQAAgnAZgYQAXgYArAAQA1AAAYAmQANAWgBAdIAAAHIh5AAQAAAlAjAAQATAAAJgPIA4AAQgGAWgNAMQgYAWgnAAQgzAAgagfgAvJozQgHAHgCAMIBBAAQgGgcgbAAQgOAAgJAJgAAvnQQgWgYgBgkQABggAWgYQAcgeAxAAQAvAAAcAeQAWAYAAAiQAAAigWAYQgcAdgwAAQgxAAgbgdgABeojQgJALAAAOQAAAOAJAKQALAOASAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgSAAgLANgAltnFIAUgpQAaAQAUAAQATAAgBgMQAAgHgGgEQgEgCgOgDIgVgFQgSgHgFgPQgEgIAAgLQAAgVAPgQQASgVAnAAQAcAAAZALIgTAlQgQgIgOAAQgSAAAAAMQAAAFAHAEQADABAPADQAXAFALAKQAOANAAAVQgBAagSARQgVASgmAAQgiAAgfgSgAVcnIQgdgZAAgpQAAgqAdgZQAXgUAeAAQASAAAOAHQAKAFAIAJIAAh1IA7AAIAAEIIg7AAIAAgSQgHALgJAEQgPAJgSAAQgfAAgXgVgAWEoiQgIAKgBAOQABANAIALQALANASAAQAPAAALgLQALgKAAgQQAAgQgMgLQgKgKgPAAQgSAAgLANgAhjnSQgWgYAAggQAAggAWgZQAageAsAAQAVAAAQAJIAAAxQgOgLgPAAQgQAAgMAMQgLALAAARQAAARALALQAMALAQAAQAPAAAOgKIAAAxQgQAJgVAAQgsAAgagfgAYznCQgKgLAAgNQAAgPAKgLQAJgLAQAAQANAAAKALQALALAAAPQAAANgLALQgKAKgNAAQgPAAgKgKgAQcm5IAAh0IgTAAIAAgvIATAAIAAgxIA6AAIAAAxIAgAAIAAAvIggAAIAAB0gAL6m5IAAkIIA6AAIAAEIgAHPm5IAAhQQgBgVgEgIQgHgMgNAAQgOAAgHANQgGAJAAATIAABQIg6AAIAAhQQAAgVgEgHQgGgMgPAAQgNAAgIALQgDADgBAHQgBAHgBAMIAABQIg5AAIAAijIA5AAIAAAUQALgKAIgEQAPgJAUAAQAYAAAPANQAJAGAHAMQAHgLAIgGQASgOAWAAQASAAAPAJQAPAKAFAQQACAKAAAPIAABqgAm7m5IAAkIIA7AAIAAEIgAsDm5IhVijIBCAAIAnBUIAmhUIBBAAIhVCjgAxfm5IAAkIIA6AAIAAEIgA0Qm5IAAkIIA7AAIAAEIgA1mm5IAAkIIA5AAIAAEIgA21m5IgQgqIhVAAIgRAqIhCAAIBcjwIBEAAIBaDwgA4JoSIAzAAIgZhNgAYroKIAAjCIA+AAIAADCgAtT38QgWgYgBgkQABggAWgYQAcgeAxAAQAvAAAcAeQAWAYAAAiQAAAigWAYQgcAdgwAAQgxAAgbgdgAsk5PQgJALAAAOQAAAOAJAKQALAOASAAQAQAAALgLQALgLAAgQQAAgQgLgLQgLgLgQAAQgSAAgLANgAzn30QgdgZAAgpQAAgqAdgZQAXgUAeAAQASAAAOAHQAKAEAIAKIAAgQIA7AAIAACjIg7AAIAAgSQgHALgJAEQgPAJgSAAQgfAAgXgVgAy/5OQgIAKgBAOQABANAIALQALANASAAQAPAAALgLQALgLAAgPQAAgQgMgLQgKgKgPAAQgSAAgLANgAp23uQgLgLAAgNQABgPAJgLQALgLAOAAQAOAAALALQAKALAAAPQAAANgKALQgLAKgOAAQgOAAgKgKgAvo3lIhUijIBBAAIAnBUIAnhUIBAAAIhUCjgA2I3lIAAijIA7AAIAAAbQAIgOALgHQAPgIATAAIALAAIAAA3QgMgGgNAAQgcAAgIAYQgDAIAAAOIAABGgA5X3lIAAjwIBdAAQBEAAAAA/QAAATgIAMQgFALgOAIQAdAGALARQAKAPgBAVQAAAbgPARQgWAYguAAgA4Y4UIAOAAQAYAAAJgGQALgGAAgNQAAgVgWgEIgXgBIgNAAgA4Y52IALAAQARAAAHgIQAFgHAAgJQAAgQgOgFQgFgCgKAAIgLAAgAp942IAAjCIA8AAIAADCg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sbravo, new cjs.Rectangle(-164.6,-178.5,329.2,357.1), null);


(lib.sapple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.applebadge2();
	this.instance.setTransform(-83.9,-25,0.5952,0.5952);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sapple, new cjs.Rectangle(-83.9,-25,167.9,50), null);


(lib.riemvoor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap862();
	this.instance.setTransform(-182,-72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riemvoor, new cjs.Rectangle(-182,-72,362,144), null);


(lib.riembreedvoor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap866();
	this.instance.setTransform(-182,-104);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riembreedvoor, new cjs.Rectangle(-182,-104,362,207), null);


(lib.riembreedachter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap865();
	this.instance.setTransform(-175,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riembreedachter, new cjs.Rectangle(-175,-45,344,87), null);


(lib.riembreed2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap90();
	this.instance.setTransform(-181,-80);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riembreed2, new cjs.Rectangle(-181,-80,359,207), null);


(lib.riembreed = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap88();
	this.instance.setTransform(-182,-80);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riembreed, new cjs.Rectangle(-182,-80,362,207), null);


(lib.riemball11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Bitmap454();
	this.instance.setTransform(-185,-48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riemball11, new cjs.Rectangle(-185,-48,352,174), null);


(lib.riemachter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap861();
	this.instance.setTransform(-182,-44);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riemachter, new cjs.Rectangle(-182,-44,359,87), null);


(lib.riem13onder3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap708();
	this.instance.setTransform(-71,-180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem13onder3, new cjs.Rectangle(-71,-180,98,362), null);


(lib.riem13onder2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap709();
	this.instance.setTransform(-33,-180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem13onder2, new cjs.Rectangle(-33,-180,104,361), null);


(lib.riem13onder = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap710();
	this.instance.setTransform(-71,-180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem13onder, new cjs.Rectangle(-71,-180,142,360), null);


(lib.riem13bovenn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap707();
	this.instance.setTransform(-71,-190);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem13bovenn, new cjs.Rectangle(-71,-190,142,380), null);


(lib.riem = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap89();
	this.instance.setTransform(-182,-48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem, new cjs.Rectangle(-182,-48,362,144), null);


(lib.ppijlplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ai2DkQgHgCgEgFQgFgGgBgHIAAmfQAAgHAFgFQAFgGAGgBQAIgCAGAEIFnDQQAHADACAHQACAGgCAHQgCAGgHAEIlmDQQgGADgFAAIgDAAg");
	this.shape.setTransform(0,0.0407);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ppijlplay, new cjs.Rectangle(-20,-22.7,40,45.5), null);


(lib.phonerechtsmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"groen":1,"oranje":2,"blauw":3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap16();
	this.instance.setTransform(-180,-90);

	this.instance_1 = new lib.Bitmap17();
	this.instance_1.setTransform(-180,-90);

	this.instance_2 = new lib.Bitmap18();
	this.instance_2.setTransform(-180,-90);

	this.instance_3 = new lib.Bitmap19();
	this.instance_3.setTransform(-180,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-180,-90,360,181);


(lib.mutsrandgras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#000000"],[0,0.173,0.741,0.898],-4.8,-12.9,0,-4.8,-12.9,28.9).s().p("AAAC8IgCghQgCgXABgiIgBhTQgCg8ACgmQABgogCglIgBgaQADgCADABQAAAAABAAQAAAAABABQABAAAAAAQAAABABAAQABACABBpIABBNIAACvQgBAEABAJQAAABgFAAIgCAAg");
	this.shape.setTransform(4.7188,18.6363);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsrandgras, new cjs.Rectangle(4,-0.2,1.5,37.7), null);


(lib.mutsrand13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#000000"],[0,0.173,0.741,0.898],-3.3,-12.5,0,-3.3,-12.5,28.9).s().p("AAYC5IgEgCQgzhcAAhJQgBhmAsheQACgEAGgBIABAAQACgBADADQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQgqBoABBZQAAApAOAsQAKAeAWAvIABABIAAABIgBABQAAABAAAAQgBAAAAABQgBAAAAAAQgBABgBAAIgBABg");
	this.shape.setTransform(1.2489,18.4458);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsrand13, new cjs.Rectangle(-2,0,6.5,36.9), null);


(lib.mutsrand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#000000"],[0,0.173,0.741,0.898],-3.1,-12.5,0,-3.1,-12.5,28.9).s().p("AAVC4IgEgDQhcigBVjJIADgDQADAAAEAAQAAAAABAAQAAAAABABQAAAAABAAQABABAAAAIABAEQhTDGBaCcQAAABAAAAQAAABAAAAQgBABAAAAQAAAAAAABIgEADIgCAAIgEAAg");
	this.shape.setTransform(1.0471,18.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsrand, new cjs.Rectangle(-2.1,0.1,6.300000000000001,36.8), null);


(lib.mutsonder = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap260();
	this.instance.setTransform(-187,-289,3,3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsonder, new cjs.Rectangle(-187,-289,375,528), null);


(lib.mutsboven = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap259();
	this.instance.setTransform(-168,-289);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsboven, new cjs.Rectangle(-168,-289,319,336), null);


(lib.levelbalsymb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap371();
	this.instance.setTransform(-180,-180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.levelbalsymb, new cjs.Rectangle(-180,-180,360,360), null);


(lib.headphonemovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.gras04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AKNLGIgBgJQAAgUATAAQASABAAASQAAAIgGAGQgGAEgHAAQgNAAgEgIgAG2KyIgBgJQAAgUATABQASAAAAASQAAAIgGAGQgFAEgIAAQgNABgEgJgADzJxIgBgJQAAgTATAAQASgBABAUQAAAHgHAFQgFAGgIAAQgNAAgEgJgAMtJiIgBgJQAAgUATAAQARABABASQgBAIgFAGQgFAEgHAAQgOABgEgJgABxH+IgBgJQAAgUATAAQASABAAASQAAAIgGAGQgGAEgGAAQgOABgEgJgAEvHlIgBgJQAAgUATAAQASABAAASQAAAIgGAGQgFAEgIAAQgNAAgEgIgAI4HNIgBgKQAAgTATgBQASAAABAUQAAAIgHAEQgGAFgGABQgOgBgEgHgAK1GBIgBgJQAAgUATAAQASABABASQAAAIgHAGQgFAEgIAAQgNABgEgJgAimF9IgBgKQAAgTATAAQATgBgBAUQAAAHgGAFQgGAFgGABQgOgBgEgHgABdFGIgBgKQAAgTATgBQATAAAAAUQgBAIgGAEQgGAFgGABQgOgBgEgHgAFcD6IgBgJQAAgUATAAQASABAAASQAAAIgGAGQgFAEgIAAQgNABgEgJgAk8DXIgBgJQAAgUATAAQASABAAASQABAIgHAGQgFAEgIAAQgNAAgEgIgAJ+C1IgBgKQAAgTATgBQASAAAAATQABAIgHAGQgFAEgIAAQgNAAgEgHgAhvCWIgBgJQAAgUATAAQASABAAASQAAAIgGAGQgGAEgHAAQgNABgEgJgADzBzIgBgJQAAgUATAAQASABABASQAAAIgHAGQgFAEgIAAQgNABgEgJgAG7BlIgBgKQAAgTATgBQATAAAAAUQgBAIgGAEQgGAFgGABQgOgBgEgHgAiwAZIgBgJQAAgTATAAQATABAAARQgBAIgGAGQgGAEgGAAQgOABgEgJgAgBgEIgBgJQAAgTASAAQASgBAAAUQABAHgHAFQgFAFgIAAQgNAAgDgIgAmggdIgBgJQAAgUATAAQASABAAASQAAAIgGAGQgFAEgIAAQgNABgEgJgAK6hOIgBgKQAAgTATgBQASAAAAAUQAAAIgGAEQgGAFgHABQgNgBgEgHgADkhOIgBgKQAAgTATgBQATAAAAAUQgBAIgGAEQgGAFgGABQgOgBgEgHgAp9hiQgBgTAUgBQASAAABATQgBAIgGAGQgGAEgGAAQgUAAABgRgAHKh3IgBgJQAAgUATAAQASABAAASQABAIgHAGQgFAEgIAAQgNABgEgJgAlujuIgBgKQAAgTATAAQATgBAAAUQgBAHgGAFQgGAGgGAAQgOgBgEgHgAhMkSIgBgJQAAgTATAAQATgBgBAUQAAAHgGAFQgGAGgGAAQgOAAgEgJgAIakbIgBgKQAAgTATAAQASgBAAAUQABAHgHAFQgFAGgIAAQgNgBgEgHgACZkhIgBgJQAAgUATAAQASABABASQAAAIgHAGQgFAEgIAAQgNABgEgJgALiliIgBgJQAAgUATABQASAAABASQAAAJgHAEQgFAGgIgBQgNABgEgJgAqDl/QABgTASAAQAUgBgBAUQAAAHgGAFQgFAGgIAAQgSAAgBgSgAlznAIgBgKQAAgTATgBQASAAAAATQAAAIgGAGQgFAEgIAAQgNAAgEgHgADanjIgBgKQAAgTATgBQATAAAAAUQgBAIgGAEQgGAFgGABQgOgBgEgHgAq5nyQAAgUASABQATAAAAASQAAAJgGAEQgGAGgHgBQgSAAAAgRgAirn4IgBgJQAAgUATAAQASABAAASQABAIgHAGQgFAEgIAAQgNAAgEgIgAIGpmIgBgJQAAgUATAAQASABAAASQAAAIgGAGQgGAEgHAAQgNABgEgJgApop6IgBgJQAAgTATAAQATgBgBAUQAAAHgGAFQgGAGgGAAQgOAAgEgJgAtQq6QABgTASAAQATgBAAAUQAAAHgGAFQgFAGgIAAQgSAAgBgSg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gras04, new cjs.Rectangle(-84.8,-71.8,169.7,143.7), null);


(lib.gras03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("ArJNbQAAgUATAAQASAAAAATQAAAIgEAFQgGAFgIAAQgTAAAAgRgAoaMkQAAgUATAAQATAAAAATQAAAIgHAFQgFAFgGAAQgUAAAAgRgArdLEQAAgTATAAQASAAAAATQABAIgHAFQgEAFgIAAQgTAAAAgSgAlNKJQAAgUATAAQASAAABATQAAAIgGAFQgGAFgGAAQgUAAAAgRgAADJ0QgBgCAAgIQgBgTAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAn3JWQAAgTATAAQASAAABATQgBAIgFAFQgFAFgHAAQgUAAAAgSgAkRIaQAAgTATAAQATAAAAATQAAAHgGAGQgFAFgIAAQgTAAAAgSgAnKHAQAAgTATAAQASAAABATQgBAIgFAFQgFAFgHAAQgUAAAAgSgAqmGyQAAgUATAAQASAAAAATQABAIgGAFQgFAFgIAAQgTAAAAgRgAASGYQgCgDAAgGQAAgUATAAQATAAAAATQAAAIgGAFQgGAFgHAAQgOAAgDgIgAEMF/QgBgDgBgHQABgTASAAQATAAAAATQAAAHgGAGQgFAFgIAAQgNAAgEgIgAkMF1QAAgTATAAQATAAAAATQAAAHgGAGQgGAFgGAAQgUAAAAgSgAnjEIQAAgUATAAQATAAAAATQgBAIgFAFQgGAFgGAAQgUAAAAgRgApvECQAAgTATAAQASAAAAATQAAAIgEAFQgGAFgIAAQgTAAAAgSgAgQDpQgCgDAAgHQAAgTATAAQASAAAAATQAAAHgGAGQgGAFgGAAQgNAAgEgIgADpDGQgBgDgBgHQABgTASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgNAAgEgIgAstCyQAAgTATAAQASAAAAATQABAHgGAGQgFAFgIAAQgTAAAAgSgAjdCoQgBgDAAgHQgBgTAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAHUB7QgCgDAAgHQAAgTATAAQATAAAAATQAAAIgGAFQgGAFgHAAQgOAAgDgIgAmJAEQAAgTATAAQATAAAAASQgBAIgFAFQgGAFgGAAQgUAAAAgRgAANAIQgCgDABgGQgBgTAUAAQASAAAAATQAAAGgGAGQgGAFgGAAQgOAAgEgIgAqcgPQAAgUATAAQASAAAAATQAAAIgEAFQgGAEgIAAQgTAAAAgQgAEbgLQgCgDABgHQgBgTAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAIohMQgBgTAUAAQASAAAAATQAAAHgGAGQgGAFgGAAQgUAAABgSgABwjDQAAgUATAAQASAAAAATQAAAIgGAFQgGAFgGAAQgTAAAAgRgAi1jOQgBgDgBgHQABgTASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgNAAgEgIgAn8jmQAAgUATAAQASAAAAATQABAIgHAFQgEAFgIAAQgTAAAAgRgAhTjsQABgTASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgSAAgBgSgAGTkKQgBgDgBgGQABgUASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgNAAgEgIgAsZlaQAAgTATAAQASAAAAATQAAAHgFAGQgGAFgHAAQgTAAAAgSgAn8mWQAAgTATAAQASAAAAATQABAHgHAGQgFAFgHAAQgTAAAAgSgAAhmRQgBgDgBgGQABgUASAAQATAAAAATQAAAIgGAFQgGAFgHAAQgOAAgDgIgAlwnDQAAgTATAAQASAAABATQgBAIgFAFQgFAFgHAAQgUAAAAgSgAJCm+QgBgDAAgGQgBgUAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAERncQgBgCAAgIQgBgTAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAsFn+QAAgUATAAQASAAABATQgBAIgFAFQgFAFgHAAQgUAAAAgRgALxoEQgBgDAAgHQAAgTASAAQATAAAAATQAAAHgGAGQgGAFgHAAQgOAAgDgIgAj9peQAAgTATAAQATAAAAATQAAAIgGAFQgGAFgHAAQgTAAAAgSgADkpZQgBgDAAgGQgBgUAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAgkp3QgBgDgBgHQABgTASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgNAAgEgIgALdqLQgCgDABgHQgBgTAUAAQASAAAAATQAAAHgGAGQgGAFgGAAQgOAAgEgIgAHKrMQgBgDgBgGQABgUASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgNAAgEgIgAMKtOQgCgDABgHQgBgTAUAAQASAAAAATQAAAHgGAGQgGAFgGAAQgOAAgEgIg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gras03, new cjs.Rectangle(-81.4,-87.6,162.8,175.2), null);


(lib.gras02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AqeO5QAAgTASAAQATAAAAATQAAAIgGAFQgFAFgHAAQgUAAABgSgAnNObQABgTASAAQATAAAAATQAAAIgGAFQgFAFgHAAQgUAAAAgSgAhxNQQgCgDAAgGQAAgUATAAQATAAAAATQAAAIgHAFQgFAFgHAAQgOAAgDgIgAodMaQAAgUATAAQATAAAAATQAAAIgFAFQgGAFgHAAQgTAAgBgRgAIXLtQgBgEAAgGQAAgSATgBQATAAgBATQABAGgHAGQgFAFgHAAQgOAAgEgHgADXLZQgBgDAAgHQAAgTATAAQASAAAAASQAAAJgFAFQgHAFgGAAQgOAAgEgIgAsILAQABgTASAAQATAAAAATQAAAHgGAGQgFAFgHAAQgUAAAAgSgAmqKsQABgTASAAQATAAAAASQAAAJgFAFQgGAFgHAAQgUAAAAgSgAjfKnQgCgDAAgHQAAgTATAAQASAAABATQgBAHgFAGQgGAFgHAAQgOAAgDgIgAAyKTQgBgDAAgHQAAgSATgBQASAAAAATQABAHgHAGQgGAFgGAAQgOAAgEgIgAp7JrQgBgTAUAAQASAAAAASQAAAJgFAFQgGAFgHAAQgTAAAAgSgALpJXQgBgDAAgHQAAgTATAAQASAAAAATQAAAHgFAGQgGAFgHAAQgNAAgFgIgAFpIMQgCgDAAgHQAAgSATgBQASAAABATQgBAHgFAGQgGAFgHAAQgOAAgDgIgAC1ICQgCgDAAgHQAAgTATAAQASAAABASQgBAJgFAFQgGAFgHAAQgOAAgDgIgAKVH4QgCgDAAgHQAAgTATAAQATAAAAASQAAAJgHAFQgFAFgHAAQgOAAgDgIgAieHzQgCgDAAgHQAAgTATAAQATAAAAATQAAAHgHAGQgFAFgHAAQgOAAgDgIgAr0HkQAAgTAUAAQASAAAAASQAAAJgFAFQgFAFgIAAQgTAAgBgSgAnqHfQAAgTASAAQATAAAAATQAAAHgGAGQgFAFgHAAQgUAAABgSgAABG3QgBgDAAgHQAAgUASAAQASAAABATQgBAJgFAFQgGAFgHAAQgOAAgDgIgAlzGeQABgUASAAQATAAAAATQAAAIgGAGQgGAEgGAAQgUAAAAgRgAHNF/QgCgDAAgGQAAgUATABQASAAABASQgBAIgGAFQgFAGgHgBQgOABgDgJgAkdESQgBgUAUABQASgBAAAUQAAAHgGAFQgFAGgHAAQgTAAAAgSgAg6EWQgCgDAAgGQAAgUATAAQATABAAASQAAAIgHAGQgFAEgHAAQgOAAgDgIgAC5EMQgBgCAAgHQAAgUATAAQASABAAASQABAIgHAGQgGAEgGAAQgOABgEgJgAn6D5QABgUASAAQATAAAAATQAAAIgGAGQgGAEgGAAQgUAAAAgRgAsMD5QgBgUAUAAQASAAAAATQAAAIgGAGQgFAEgHAAQgTAAAAgRgAJODVQgBgCAAgHQAAgUATAAQASAAAAATQABAIgHAGQgGAEgGAAQgOABgEgJgArCDCQABgUASABQATAAAAATQAAAHgFAFQgGAGgHgBQgUAAAAgRgAGLCBQgBgDAAgHQAAgUATABQASgBAAAUQAAAHgFAFQgHAFgGABQgOgBgEgHgAhtBeQgBgDAAgHQAAgUATAAQASAAAAAUQAAAHgFAFQgGAGgHAAQgNgBgFgHgAmHA7QABgUASABQATAAAAASQAAAIgFAFQgGAGgHAAQgUAAAAgSgAJUA1QgCgDAAgGQAAgUATAAQASABABASQgBAIgGAGQgFAEgHAAQgOAAgDgIgADNgPQgBgEAAgGQAAgUATAAQASAAAAAUQAAAHgFAFQgGAFgHABQgNgBgFgHgAAZhGQgBgEAAgGQAAgUATAAQASAAAAATQAAAIgFAGQgGAEgHAAQgNAAgFgHgAlAhzQgBgUAUAAQASAAAAAUQAAAIgFAEQgGAFgHABQgTgBAAgRgAqLh4QABgUASABQATAAAAASQAAAJgFAEQgGAGgHgBQgUAAAAgRgAGqh+QgCgCAAgHQAAgUATAAQATABAAASQAAAIgHAGQgFAEgHAAQgOAAgDgIgAoTj6QAAgUAUAAQASAAAAAUQAAAIgFAEQgFAFgIABQgTgBgBgRgAhakOQAAgUATAAQASABABASQgBAIgFAGQgGAEgHAAQgTAAAAgRgAkPknQAAgUATAAQAUAAAAAUQgBAHgFAFQgGAFgHABQgTgBgBgRgAr4kxQAAgUASAAQATAAAAATQAAAIgGAGQgGAEgGAAQgUAAABgRgACIk2QgCgDAAgHQAAgUATAAQASAAABAUQgBAHgFAFQgGAGgHAAQgOgBgDgHgAltm4QgBgUAUAAQASAAAAATQAAAJgFAFQgGAEgHAAQgTAAAAgRgAhnnRQgCgEAAgGQAAgUATAAQATAAAAAUQAAAHgHAFQgFAFgHABQgOgBgDgHgAFUnXQgBgDAAgGQAAgUATABQASAAAAASQAAAIgFAFQgGAGgHgBQgNABgFgJgArLngQAAgUASABQATAAAAASQAAAIgGAFQgGAGgGgBQgUAAABgRgAoToDQAAgUAUAAQASAAAAATQAAAIgFAGQgFAEgIAAQgTAAgBgRgACIo7QgCgCAAgHQAAgUATABQASgBABAUQgBAHgFAFQgGAGgHAAQgOAAgDgJgAjqpoQgBgCAAgHQAAgUATABQASgBAAAUQAAAHgFAFQgHAGgGAAQgOAAgEgJgAmqpxQABgUASABQATgBAAAUQAAAHgFAFQgGAGgHAAQgUAAAAgSgAr5rFIgIgFIAAgEIgBgLQgBgVAUAAQASAAAAAVQAAAVgSABQgHgBgDgBgAgnrlQgBgCAAgHQAAgUATABQASAAAAASQABAIgHAFQgGAGgGgBQgOABgEgJgAposbQABgUASABQATAAAAASQAAAIgFAFQgGAGgHgBQgUAAAAgRgAk2tmQAAgUASABQATgBAAAUQAAAHgGAFQgGAFgGABQgUAAABgSgArvu2QABgUASAAQATAAAAAUQAAAHgFAFQgGAGgHAAQgUAAAAgSg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gras02, new cjs.Rectangle(-78.1,-97.1,156.3,194.2), null);


(lib.gras01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("ALzO5IgBgKQAAgTATAAQASAAAAATQABAHgHAGQgFAFgIAAQgNAAgEgIgAEEOvIgBgKQAAgTATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgAjqOWIgBgKQAAgTATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgAAeNzIgBgKQAAgTATAAQATAAAAATQgBAIgGAFQgGAFgGAAQgOAAgEgIgAIwNQIgBgKQAAgTATAAQATAAAAATQgBAHgGAGQgGAFgGAAQgOAAgEgIgAqLMAQABgTASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgSAAgBgSgAD6LAIgBgKQAAgTATAAQASAAAAASQABAIgHAGQgFAFgIAAQgNAAgEgIgAI1KsIgBgKQAAgTATAAQASAAAAASQABAIgHAGQgFAFgIAAQgNAAgEgIgAiVKEIgBgKQAAgTATAAQATAAAAASQgBAIgGAGQgGAFgGAAQgOAAgEgIgAs5J6QgBgTAUAAQASAAAAASQAAAIgGAGQgFAFgHAAQgUAAABgSgAmeHkIgBgKQAAgTATAAQASAAAAASQABAIgHAGQgFAFgIAAQgNAAgEgIgAIXHaIgBgKQAAgTATAAQATAAgBASQAAAIgGAGQgGAFgGAAQgOAAgEgIgALzHLIgBgKQAAgTATAAQASAAAAASQABAIgHAGQgFAFgIAAQgNAAgEgIgAE7GeIgBgKQAAgUATAAQASAAABATQAAAHgHAGQgGAGgHAAQgNAAgEgIgABkF6IgBgJQAAgUATAAQASAAABATQAAAIgHAFQgGAFgGAAQgOAAgEgIgAq4FsQABgUASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgSAAgBgRgAiLFhIgBgJQAAgUATAAQATAAgBATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAlxDGIgBgJQAAgUATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgAGzC8IgBgJQAAgUATAAQATAAAAATQgBAIgGAFQgGAFgGAAQgOAAgEgIgAMWCFIgBgJQAAgUATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgApiBUQgBgUAUAAQASAAAAATQAAAIgGAFQgGAFgGAAQgUAAABgRgADrBYIgBgJQAAgUATAAQASAAABATQAAAIgHAFQgGAFgGAAQgOAAgEgIgAH0AXIgBgJQAAgTATAAQASAAAAASQAAAIgGAFQgGAFgGAAQgOAAgEgIgAhAgQIgBgJQAAgUATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgAmoh5IgBgJQAAgUATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgAKeiSIgBgJQAAgUATAAQATAAAAATQgBAIgGAFQgGAFgGAAQgOAAgEgIgAClimIgBgJQAAgUATAAQATAAAAATQgBAIgGAFQgGAFgGAAQgOAAgEgIgApei0QABgUASAAQATAAAAATQAAAIgGAFQgFAFgIAAQgSAAgBgRgAgniwIgBgJQAAgUATAAQASAAAAATQAAAIgGAFQgGAFgHAAQgNAAgEgIgAFykFIgBgJQAAgUATAAQASAAABATQAAAIgHAFQgGAFgGAAQgOAAgEgIgAkIkoIgBgJQAAgUATAAQASAAAAATQAAAIgGAFQgGAFgHAAQgNAAgEgIgALQmRIgBgJQAAgUATAAQASAAABATQAAAIgHAFQgFAFgIAAQgNAAgEgIgAi4m0IgBgJQAAgUATAAQATAAgBATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAHHoTIgBgJQAAgUATAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIgABzoiIgBgJQAAgUATAAQASAAAAATQABAIgHAFQgFAFgIAAQgNAAgEgIgALaqpIgBgJQAAgUATAAQASAAABATQAAAIgHAFQgGAFgGAAQgOAAgEgIgADcswIgBgJQAAgUATAAQATAAgBATQAAAIgGAFQgGAFgGAAQgOAAgEgIgAJOujIgBgJQAAgUATAAQASAAAAATQAAAIgGAFQgGAFgGAAQgOAAgEgIg");
	this.shape.setTransform(0,-0.0256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gras01, new cjs.Rectangle(-82.6,-96.1,165.3,192.2), null);


(lib.gieter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap887();
	this.instance.setTransform(-52,-46);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gieter, new cjs.Rectangle(-52,-46,105,92), null);


(lib.flaplinks2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C8A673").s().p("AoTg9IMCjAIElEEIsDD3g");
	this.shape.setTransform(0.175,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.flaplinks2, new cjs.Rectangle(-53,-25.4,106.4,50.8), null);


(lib.flapachter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E0BE8B").s().p("AnVAkIDjjqILIB+IjUEPg");
	this.shape.setTransform(0.025,0.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.flapachter, new cjs.Rectangle(-46.9,-19.6,93.9,39.8), null);


(lib.fl01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C2A06D").s().p("AoTg9IMCjAIElEEIsDD3g");
	this.shape.setTransform(-0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fl01, new cjs.Rectangle(-53.2,-25.4,106.4,50.8), null);


(lib.fbtitelyellow_sm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BFBF00").s().p("AWSMuICMkdQClBwCNAAQB4AAAAhWQAAgugqgZQgbgQhfgWQhpgZghgNQh1gwgphmQgXg3AAhOQAAiUBihwQB9iQEFAAQC2AACrBKIiCEDQhsg5hhAAQh0AAAABTQAAAnAvAXQAVALBnAXQCWAgBIBJQBaBbAACSQAAC2h8BzQiMCDj9gBQjgABjTiEgAtLMZQi9ivAAkeQAAkmDCitQCZiLDGAAQB0AABmAyQA7AeA+BEIAAhxIGAAAIAAR1ImAAAIAAh+Qg3BJg5AgQhiA6h9AAQjKABieiTgAo7CkQg8BJAABfQAABfA8BIQBHBbB0AAQBoAABIhLQBHhKAAhtQAAhshIhMQhIhLhnAAQhzAAhIBbgA9YNxQg8gigzhHIAAB+ImCAAIAA83IGCAAIAAM0QA+hEA6geQBmgzB0AAQDGAACaCLQDBCtAAEmQAAEei9CvQieCTjJgBQh+AAhig6gA+LCUQhIBLAABuQAABsBIBLQBIBNBnAAQB0AABIhbQA7hMAAhdQAAhgg7hKQhJhbhzAAQhnAAhIBMgAOyOGIAA83IGCAAIAAc3gAGPOGIAA83IGCAAIAAc3g");
	this.shape.setTransform(1081.975,-28.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("EAlPATPIGZr/InRtnIAAECQhQgphTAAQi9AAg4CkQgWA6AABkIAAHoImBAAIAAx1IGBAAIAAC7QA9hjBHgtQBdg6CDAAQAeAAAsADIAAAMIGDAAIEiJKIEbpKIG4AAIuRbYgADoHJQiUiqAAj3QAAjeCVisQC2jQFPAAQE1AAC3DQQCXCpgBDrQABDtiVCqQi1DOlFAAQlGAAi0jOgAIhh5Qg9BLAABgQAABhA9BMQBKBeB3AAQBrAABJhOQBJhNABhwQgBhuhJhOQhKhNhqAAQh3AAhKBegA1+G/QiMirAAjhQAAjhCMirQCvjTEqAAQCGAAB0BAIAAFXQhlhLhiAAQhxAAhMBNQhKBOgBB4QABB4BKBOQBMBNBxABQBgAABnhLIAAFYQh3A/iDAAQkqgBivjTgEgq6AH/Qi8ivgBkeQABklDBiuQCaiLDGAAQBzAABnAyQA6AeA+BEIAAhxIGBAAIAAR1ImBAAIAAh+Qg3BJg4AgQhjA6h9AAQjKABieiTgEgmqgB1Qg8BJAABeQAABfA8BIQBIBbBzAAQBpAABHhLQBIhKAAhtQgBhrhIhMQhHhLhoAAQhyAAhJBbgAoGJsIAAsqIh/AAIAAlLIB/AAIAAlXIGBAAIAAFXIDaAAIAAFLIjaAAIAAMqgEg4FAJsIAAsoIiJAAIAAlNICJAAIAAiWQAAj9B6iJQCXipDUAAQBUAABWApIAAFfQhOgug4AAQhOAAgkA/QgWAkAACOIAAB6IEOAAIAAFNIkOAAIAAMog");
	this.shape_1.setTransform(468.35,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF00").s().p("EhsCAUoMAAAgpPMDYFAAAMAAAApPg");
	this.shape_2.setTransform(691.525,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fbtitelyellow_sm, new cjs.Rectangle(0,-132,1383.1,264.1), null);


(lib.fbtitelyellow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AE+GcQAAhsguiEIgCgGQhNB5hwBWQiJBph7AAQhPAAgugzQgugzAAhZQAAh+BThbQBThaB2AAQA4AAAiAcQAhAcAAAwQAABPhdA9QhfA8h7AAQAACBBtgBQBeABBxhbQBnhRBVh/QgmhZgwgyQAmgUAfAAQAwABAyB9QAxB/AWC0QBMhhAzhoQAyhoAGhLQBCAaAAAiQAAAdg/BqQg/BqhKBeQgkAtgYANQgZAOg5AEQAJgnAAgcgAi8BXQgyBAgNBbQBcgFBCgwQBCgvAAg/QAAg4gyAAQg8AAgzBAgATPG3QAAgVAQhQIAWhtIADgQQhEBbhZBFQiKBph7AAQhPAAgugzQgugzAAhZQAAh+BThbQBThaB2AAQA4AAAjAcQAhAcAAAwQAABPheA9QhfA8h7AAQAACBBtgBQBeABByhbQBqhSBWiFIABgXQAAgZgPgSQAugQAdAAQAfAAAAAnQAAAZgWBmIgYCBQBTiiBUhZQBUhZBEAAQAYAAASAOQARANAAATQAAAfhCAzQgRgigfgBQg4AAhWB4Qg1BJgoBPQgoBOAAAiIABAHQgeAOgSAAQgtAAAAgngANNBXQgyBAgNBbQBcgFBCgwQBCgvAAg/QAAg4gyAAQg8AAgzBAgAswG3QAAgVAQhQIAWhtQAKgwAFgkQgsASgsAAQgxAAg+gUIABATQAAB/hWBfQhWBeh0AAQhYAAg3g5Qg4g4AAhaQAAhmBIhMQBHhLBiABQAPgBARAEQgLgUAAgMQAAgWAOgSQBrAIBIBkQBJAyBPAAQAnAAAsgVIAAgHQAAgZgOgSQAugQAdAAQAfAAAAAnQAAAZgWBmIgZCBQBTiiBUhZQBUhZBFAAQAYAAARAOQASANAAATQAAAfhDAzQgRgigegBQg4AAhWB4Qg2BJgnBPQgoBOAAAiIAAAHQgdAOgTAAQgtAAAAgngA0TCFQg6BEAABVQAAA/AjAoQAjAoA3AAQBKAAA2hLQA1hLAAhnQAAgkgLgiQgkgLgfgZQgXgEgPAAQhKAAg6BDgA6QGyQAAggAOhJIBOmDIgJAAQhCAAgwAgQAKg4AVgPQAUgPBCAAIAQAAIAPhIQAdiUBBhBQBQhRBhAAQAmAAAbASQAbARAAAaQAAAZg4AgQgQhCg5AAQhjAAgrDZIgUBhICaAAQBpAAAxgMQgVAvgbAKQgbAJhwAAIiEAAIhKF4QgLA2AAApQAAAbALAUQgsAPgYAAQgkAAAAgpg");
	this.shape.setTransform(1455.375,50.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BFBF00").s().p("AWSMuICMkdQClBwCNAAQB4AAAAhWQAAgugqgZQgbgQhfgWQhpgZghgNQh1gwgphmQgXg3AAhOQAAiUBihwQB9iQEFAAQC2AACrBKIiCEDQhsg5hhAAQh0AAAABTQAAAnAvAXQAVALBnAXQCWAgBIBJQBaBbAACSQAAC2h8BzQiMCDj9gBQjgABjTiEgAtLMZQi9ivAAkeQAAkmDCitQCZiLDGAAQB0AABmAyQA7AeA+BEIAAhxIGAAAIAAR1ImAAAIAAh+Qg3BJg5AgQhiA6h9AAQjKABieiTgAo7CkQg8BJAABfQAABfA8BIQBHBbB0AAQBoAABIhLQBHhKAAhtQAAhshIhMQhIhLhnAAQhzAAhIBbgA9YNxQg8gigzhHIAAB+ImCAAIAA83IGCAAIAAM0QA+hEA6geQBmgzB0AAQDGAACaCLQDBCtAAEmQAAEei9CvQieCTjJgBQh+AAhig6gA+LCUQhIBLAABuQAABsBIBLQBIBNBnAAQB0AABIhbQA7hMAAhdQAAhgg7hKQhJhbhzAAQhnAAhIBMgAOyOGIAA83IGCAAIAAc3gAGPOGIAA83IGCAAIAAc3g");
	this.shape_1.setTransform(1081.975,-28.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("EAlPATPIGZr/InRtnIAAECQhQgphTAAQi9AAg4CkQgWA6AABkIAAHoImBAAIAAx1IGBAAIAAC7QA9hjBHgtQBdg6CDAAQAeAAAsADIAAAMIGDAAIEiJKIEbpKIG4AAIuRbYgADoHJQiUiqAAj3QAAjeCVisQC2jQFPAAQE1AAC3DQQCXCpgBDrQABDtiVCqQi1DOlFAAQlGAAi0jOgAIhh5Qg9BLAABgQAABhA9BMQBKBeB3AAQBrAABJhOQBJhNABhwQgBhuhJhOQhKhNhqAAQh3AAhKBegA1+G/QiMirAAjhQAAjhCMirQCvjTEqAAQCGAAB0BAIAAFXQhlhLhiAAQhxAAhMBNQhKBOgBB4QABB4BKBOQBMBNBxABQBgAABnhLIAAFYQh3A/iDAAQkqgBivjTgEgq6AH/Qi8ivgBkeQABklDBiuQCaiLDGAAQBzAABnAyQA6AeA+BEIAAhxIGBAAIAAR1ImBAAIAAh+Qg3BJg4AgQhjA6h9AAQjKABieiTgEgmqgB1Qg8BJAABeQAABfA8BIQBIBbBzAAQBpAABHhLQBIhKAAhtQgBhrhIhMQhHhLhoAAQhyAAhJBbgAoGJsIAAsqIh/AAIAAlLIB/AAIAAlXIGBAAIAAFXIDaAAIAAFLIjaAAIAAMqgEg4FAJsIAAsoIiJAAIAAlNICJAAIAAiWQAAj9B6iJQCXipDUAAQBUAABWApIAAFfQhOgug4AAQhOAAgkA/QgWAkAACOIAAB6IEOAAIAAFNIkOAAIAAMog");
	this.shape_2.setTransform(468.35,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("EiDkAUoMAAAgpPMEHJAAAMAAAApPg");
	this.shape_3.setTransform(842.1,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fbtitelyellow, new cjs.Rectangle(0,-132,1684.2,264.1), null);


(lib.fa01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E4C28F").s().p("AnVAlIDjjqILIB9IjSEOg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fa01, new cjs.Rectangle(-46.9,-19.8,93.9,39.6), null);


(lib.doosbinnen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A18050").s().p("AmGAKIMIj0IAGHVg");
	this.shape.setTransform(-35.95,0.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E4C28F").s().p("AlqjqILWCoQgBABrPEsg");
	this.shape_1.setTransform(38.95,0.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doosbinnen, new cjs.Rectangle(-75.1,-22.9,150.39999999999998,46.9), null);


(lib.ditvh = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.itchbadge2();
	this.instance.setTransform(-83.9,-25,0.5952,0.5952);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ditvh, new cjs.Rectangle(-83.9,-25,167.9,50), null);


(lib.bloemblauw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap901();
	this.instance.setTransform(1,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Bitmap900();
	this.instance_1.setTransform(-34,-41);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bloemblauw, new cjs.Rectangle(-34,-41,107,117), null);


(lib.bloem = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap898();
	this.instance.setTransform(1,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Bitmap897();
	this.instance_1.setTransform(-34,-41);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bloem, new cjs.Rectangle(-34,-41,107,117), null);


(lib.balsymbool = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","#EEEEEE","#8D8D8D","#888888"],[0,0.173,0.741,0.898],60,-70,0,60,-70,281).s().p("Az6T2QoNoSAArkQAAroINoSQISoNLoAAQLpAAININQISISAALoQAALkoSISQoNISrpAAQroAAoSoSg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.balsymbool, new cjs.Rectangle(-180,-180,360,360), null);


(lib.balp1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"groen":1,"oranje":2,"blauw":3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-180,-110);

	this.instance_1 = new lib.Bitmap21();
	this.instance_1.setTransform(-180,-110);

	this.instance_2 = new lib.Bitmap22();
	this.instance_2.setTransform(-180,-110);

	this.instance_3 = new lib.Bitmap23();
	this.instance_3.setTransform(-180,-110);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-180,-110,360,220);


(lib.ball13p20mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,paars:5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap844();
	this.instance.setTransform(-85,-91);

	this.instance_1 = new lib.Bitmap845();
	this.instance_1.setTransform(-85,-91);

	this.instance_2 = new lib.Bitmap846();
	this.instance_2.setTransform(-85,-91);

	this.instance_3 = new lib.Bitmap847();
	this.instance_3.setTransform(-85,-91);

	this.instance_4 = new lib.Bitmap848();
	this.instance_4.setTransform(-85,-91);

	this.instance_5 = new lib.Bitmap849();
	this.instance_5.setTransform(-85,-91);

	this.instance_6 = new lib.Bitmap850();
	this.instance_6.setTransform(-85,-91);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-91,170,182);


(lib.ball13p19mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap837();
	this.instance.setTransform(-41,-53);

	this.instance_1 = new lib.Bitmap838();
	this.instance_1.setTransform(-41,-53);

	this.instance_2 = new lib.Bitmap839();
	this.instance_2.setTransform(-41,-53);

	this.instance_3 = new lib.Bitmap840();
	this.instance_3.setTransform(-41,-53);

	this.instance_4 = new lib.Bitmap841();
	this.instance_4.setTransform(-41,-53);

	this.instance_5 = new lib.Bitmap842();
	this.instance_5.setTransform(-41,-53);

	this.instance_6 = new lib.Bitmap843();
	this.instance_6.setTransform(-41,-53);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-53,83,106);


(lib.ball13p18mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap830();
	this.instance.setTransform(-40,-53);

	this.instance_1 = new lib.Bitmap831();
	this.instance_1.setTransform(-40,-53);

	this.instance_2 = new lib.Bitmap832();
	this.instance_2.setTransform(-40,-53);

	this.instance_3 = new lib.Bitmap833();
	this.instance_3.setTransform(-40,-53);

	this.instance_4 = new lib.Bitmap834();
	this.instance_4.setTransform(-40,-53);

	this.instance_5 = new lib.Bitmap835();
	this.instance_5.setTransform(-40,-53);

	this.instance_6 = new lib.Bitmap836();
	this.instance_6.setTransform(-40,-53);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-53,79,106);


(lib.ball13p17mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap823();
	this.instance.setTransform(-61,-88);

	this.instance_1 = new lib.Bitmap824();
	this.instance_1.setTransform(-61,-88);

	this.instance_2 = new lib.Bitmap825();
	this.instance_2.setTransform(-61,-88);

	this.instance_3 = new lib.Bitmap826();
	this.instance_3.setTransform(-61,-88);

	this.instance_4 = new lib.Bitmap827();
	this.instance_4.setTransform(-61,-88);

	this.instance_5 = new lib.Bitmap828();
	this.instance_5.setTransform(-61,-88);

	this.instance_6 = new lib.Bitmap829();
	this.instance_6.setTransform(-61,-88);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-88,123,176);


(lib.ball13p16mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap809();
	this.instance.setTransform(-81,-56);

	this.instance_1 = new lib.Bitmap810();
	this.instance_1.setTransform(-81,-56);

	this.instance_2 = new lib.Bitmap811();
	this.instance_2.setTransform(-81,-56);

	this.instance_3 = new lib.Bitmap812();
	this.instance_3.setTransform(-81,-56);

	this.instance_4 = new lib.Bitmap813();
	this.instance_4.setTransform(-81,-56);

	this.instance_5 = new lib.Bitmap814();
	this.instance_5.setTransform(-81,-56);

	this.instance_6 = new lib.Bitmap815();
	this.instance_6.setTransform(-81,-56);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81,-56,162,112);


(lib.ball13p15mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap802();
	this.instance.setTransform(-29,-38);

	this.instance_1 = new lib.Bitmap803();
	this.instance_1.setTransform(-29,-38);

	this.instance_2 = new lib.Bitmap804();
	this.instance_2.setTransform(-29,-38);

	this.instance_3 = new lib.Bitmap805();
	this.instance_3.setTransform(-29,-38);

	this.instance_4 = new lib.Bitmap806();
	this.instance_4.setTransform(-29,-38);

	this.instance_5 = new lib.Bitmap807();
	this.instance_5.setTransform(-29,-38);

	this.instance_6 = new lib.Bitmap808();
	this.instance_6.setTransform(-29,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29,-38,57,76);


(lib.ball13p14mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap788();
	this.instance.setTransform(-26,-39);

	this.instance_1 = new lib.Bitmap789();
	this.instance_1.setTransform(-26,-39);

	this.instance_2 = new lib.Bitmap790();
	this.instance_2.setTransform(-26,-39);

	this.instance_3 = new lib.Bitmap791();
	this.instance_3.setTransform(-26,-39);

	this.instance_4 = new lib.Bitmap792();
	this.instance_4.setTransform(-26,-39);

	this.instance_5 = new lib.Bitmap793();
	this.instance_5.setTransform(-26,-39);

	this.instance_6 = new lib.Bitmap794();
	this.instance_6.setTransform(-26,-39);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-39,52,79);


(lib.ball13p13mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap781();
	this.instance.setTransform(-48,-52);

	this.instance_1 = new lib.Bitmap782();
	this.instance_1.setTransform(-48,-52);

	this.instance_2 = new lib.Bitmap783();
	this.instance_2.setTransform(-48,-52);

	this.instance_3 = new lib.Bitmap784();
	this.instance_3.setTransform(-48,-52);

	this.instance_4 = new lib.Bitmap785();
	this.instance_4.setTransform(-48,-52);

	this.instance_5 = new lib.Bitmap786();
	this.instance_5.setTransform(-48,-52);

	this.instance_6 = new lib.Bitmap787();
	this.instance_6.setTransform(-48,-52);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48,-52,96,104);


(lib.ball13p12mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap816();
	this.instance.setTransform(-64,-35);

	this.instance_1 = new lib.Bitmap817();
	this.instance_1.setTransform(-64,-35);

	this.instance_2 = new lib.Bitmap818();
	this.instance_2.setTransform(-64,-35);

	this.instance_3 = new lib.Bitmap819();
	this.instance_3.setTransform(-64,-35);

	this.instance_4 = new lib.Bitmap820();
	this.instance_4.setTransform(-64,-35);

	this.instance_5 = new lib.Bitmap821();
	this.instance_5.setTransform(-64,-35);

	this.instance_6 = new lib.Bitmap822();
	this.instance_6.setTransform(-64,-35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-35,127,70);


(lib.ball13p11mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap795();
	this.instance.setTransform(-40,-34);

	this.instance_1 = new lib.Bitmap796();
	this.instance_1.setTransform(-40,-34);

	this.instance_2 = new lib.Bitmap797();
	this.instance_2.setTransform(-40,-34);

	this.instance_3 = new lib.Bitmap798();
	this.instance_3.setTransform(-40,-34);

	this.instance_4 = new lib.Bitmap799();
	this.instance_4.setTransform(-40,-34);

	this.instance_5 = new lib.Bitmap800();
	this.instance_5.setTransform(-40,-34);

	this.instance_6 = new lib.Bitmap801();
	this.instance_6.setTransform(-40,-34);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-34,81,67);


(lib.ball13p10mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap774();
	this.instance.setTransform(-64,-36);

	this.instance_1 = new lib.Bitmap775();
	this.instance_1.setTransform(-64,-36);

	this.instance_2 = new lib.Bitmap776();
	this.instance_2.setTransform(-64,-36);

	this.instance_3 = new lib.Bitmap777();
	this.instance_3.setTransform(-64,-36);

	this.instance_4 = new lib.Bitmap778();
	this.instance_4.setTransform(-64,-36);

	this.instance_5 = new lib.Bitmap779();
	this.instance_5.setTransform(-64,-36);

	this.instance_6 = new lib.Bitmap780();
	this.instance_6.setTransform(-64,-36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-36,127,72);


(lib.ball13p9mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap767();
	this.instance.setTransform(-40,-33);

	this.instance_1 = new lib.Bitmap768();
	this.instance_1.setTransform(-40,-33);

	this.instance_2 = new lib.Bitmap769();
	this.instance_2.setTransform(-40,-33);

	this.instance_3 = new lib.Bitmap770();
	this.instance_3.setTransform(-40,-33);

	this.instance_4 = new lib.Bitmap771();
	this.instance_4.setTransform(-40,-33);

	this.instance_5 = new lib.Bitmap772();
	this.instance_5.setTransform(-40,-33);

	this.instance_6 = new lib.Bitmap773();
	this.instance_6.setTransform(-40,-33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-33,81,67);


(lib.ball13p8mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap760();
	this.instance.setTransform(-81,-54);

	this.instance_1 = new lib.Bitmap761();
	this.instance_1.setTransform(-81,-54);

	this.instance_2 = new lib.Bitmap762();
	this.instance_2.setTransform(-81,-54);

	this.instance_3 = new lib.Bitmap763();
	this.instance_3.setTransform(-81,-54);

	this.instance_4 = new lib.Bitmap764();
	this.instance_4.setTransform(-81,-54);

	this.instance_5 = new lib.Bitmap765();
	this.instance_5.setTransform(-81,-54);

	this.instance_6 = new lib.Bitmap766();
	this.instance_6.setTransform(-81,-54);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81,-54,162,109);


(lib.ball13p7mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap753();
	this.instance.setTransform(-30,-45);

	this.instance_1 = new lib.Bitmap754();
	this.instance_1.setTransform(-30,-45);

	this.instance_2 = new lib.Bitmap755();
	this.instance_2.setTransform(-30,-45);

	this.instance_3 = new lib.Bitmap756();
	this.instance_3.setTransform(-30,-45);

	this.instance_4 = new lib.Bitmap757();
	this.instance_4.setTransform(-30,-45);

	this.instance_5 = new lib.Bitmap758();
	this.instance_5.setTransform(-30,-45);

	this.instance_6 = new lib.Bitmap759();
	this.instance_6.setTransform(-30,-45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30,-45,60,89);


(lib.ball13p6mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap746();
	this.instance.setTransform(-27,-48);

	this.instance_1 = new lib.Bitmap747();
	this.instance_1.setTransform(-27,-48);

	this.instance_2 = new lib.Bitmap748();
	this.instance_2.setTransform(-27,-48);

	this.instance_3 = new lib.Bitmap749();
	this.instance_3.setTransform(-27,-48);

	this.instance_4 = new lib.Bitmap750();
	this.instance_4.setTransform(-27,-48);

	this.instance_5 = new lib.Bitmap751();
	this.instance_5.setTransform(-27,-48);

	this.instance_6 = new lib.Bitmap752();
	this.instance_6.setTransform(-27,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-48,55,96);


(lib.ball13p5mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap739();
	this.instance.setTransform(-50,-52);

	this.instance_1 = new lib.Bitmap740();
	this.instance_1.setTransform(-50,-52);

	this.instance_2 = new lib.Bitmap741();
	this.instance_2.setTransform(-50,-52);

	this.instance_3 = new lib.Bitmap742();
	this.instance_3.setTransform(-50,-52);

	this.instance_4 = new lib.Bitmap743();
	this.instance_4.setTransform(-50,-52);

	this.instance_5 = new lib.Bitmap744();
	this.instance_5.setTransform(-50,-52);

	this.instance_6 = new lib.Bitmap745();
	this.instance_6.setTransform(-50,-52);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50,-52,99,104);


(lib.ball13p4mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap732();
	this.instance.setTransform(-84,-86);

	this.instance_1 = new lib.Bitmap733();
	this.instance_1.setTransform(-84,-86);

	this.instance_2 = new lib.Bitmap734();
	this.instance_2.setTransform(-84,-86);

	this.instance_3 = new lib.Bitmap735();
	this.instance_3.setTransform(-84,-86);

	this.instance_4 = new lib.Bitmap736();
	this.instance_4.setTransform(-84,-86);

	this.instance_5 = new lib.Bitmap737();
	this.instance_5.setTransform(-84,-86);

	this.instance_6 = new lib.Bitmap738();
	this.instance_6.setTransform(-84,-86);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84,-86,167,172);


(lib.ball13p3mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap725();
	this.instance.setTransform(-41,-59);

	this.instance_1 = new lib.Bitmap726();
	this.instance_1.setTransform(-41,-59);

	this.instance_2 = new lib.Bitmap727();
	this.instance_2.setTransform(-41,-59);

	this.instance_3 = new lib.Bitmap728();
	this.instance_3.setTransform(-41,-59);

	this.instance_4 = new lib.Bitmap729();
	this.instance_4.setTransform(-41,-59);

	this.instance_5 = new lib.Bitmap730();
	this.instance_5.setTransform(-41,-59);

	this.instance_6 = new lib.Bitmap731();
	this.instance_6.setTransform(-41,-59);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-59,81,119);


(lib.ball13p2mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap718();
	this.instance.setTransform(-38,-59);

	this.instance_1 = new lib.Bitmap719();
	this.instance_1.setTransform(-38,-59);

	this.instance_2 = new lib.Bitmap720();
	this.instance_2.setTransform(-38,-59);

	this.instance_3 = new lib.Bitmap721();
	this.instance_3.setTransform(-38,-59);

	this.instance_4 = new lib.Bitmap722();
	this.instance_4.setTransform(-38,-59);

	this.instance_5 = new lib.Bitmap723();
	this.instance_5.setTransform(-38,-59);

	this.instance_6 = new lib.Bitmap724();
	this.instance_6.setTransform(-38,-59);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38,-59,77,118);


(lib.ball13p1mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap711();
	this.instance.setTransform(-62,-83);

	this.instance_1 = new lib.Bitmap712();
	this.instance_1.setTransform(-62,-83);

	this.instance_2 = new lib.Bitmap713();
	this.instance_2.setTransform(-62,-83);

	this.instance_3 = new lib.Bitmap714();
	this.instance_3.setTransform(-62,-83);

	this.instance_4 = new lib.Bitmap715();
	this.instance_4.setTransform(-62,-83);

	this.instance_5 = new lib.Bitmap716();
	this.instance_5.setTransform(-62,-83);

	this.instance_6 = new lib.Bitmap717();
	this.instance_6.setTransform(-62,-83);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-83,124,167);


(lib.ball12p16mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap698();
	this.instance.setTransform(-51,-37);

	this.instance_1 = new lib.Bitmap699();
	this.instance_1.setTransform(-51,-37);

	this.instance_2 = new lib.Bitmap700();
	this.instance_2.setTransform(-51,-37);

	this.instance_3 = new lib.Bitmap701();
	this.instance_3.setTransform(-51,-37);

	this.instance_4 = new lib.Bitmap702();
	this.instance_4.setTransform(-51,-37);

	this.instance_5 = new lib.Bitmap703();
	this.instance_5.setTransform(-51,-37);

	this.instance_6 = new lib.Bitmap704();
	this.instance_6.setTransform(-51,-37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-37,102,74);


(lib.ball12p15mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap691();
	this.instance.setTransform(-34,-38);

	this.instance_1 = new lib.Bitmap692();
	this.instance_1.setTransform(-34,-38);

	this.instance_2 = new lib.Bitmap693();
	this.instance_2.setTransform(-34,-38);

	this.instance_3 = new lib.Bitmap694();
	this.instance_3.setTransform(-34,-38);

	this.instance_4 = new lib.Bitmap695();
	this.instance_4.setTransform(-34,-38);

	this.instance_5 = new lib.Bitmap696();
	this.instance_5.setTransform(-34,-38);

	this.instance_6 = new lib.Bitmap697();
	this.instance_6.setTransform(-34,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-38,67,75);


(lib.ball12p14mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap684();
	this.instance.setTransform(-94,-79);

	this.instance_1 = new lib.Bitmap685();
	this.instance_1.setTransform(-94,-79);

	this.instance_2 = new lib.Bitmap686();
	this.instance_2.setTransform(-94,-79);

	this.instance_3 = new lib.Bitmap687();
	this.instance_3.setTransform(-94,-79);

	this.instance_4 = new lib.Bitmap688();
	this.instance_4.setTransform(-94,-79);

	this.instance_5 = new lib.Bitmap689();
	this.instance_5.setTransform(-94,-79);

	this.instance_6 = new lib.Bitmap690();
	this.instance_6.setTransform(-94,-79);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94,-79,189,157);


(lib.ball12p13mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap677();
	this.instance.setTransform(-61,-79);

	this.instance_1 = new lib.Bitmap678();
	this.instance_1.setTransform(-61,-79);

	this.instance_2 = new lib.Bitmap679();
	this.instance_2.setTransform(-61,-79);

	this.instance_3 = new lib.Bitmap680();
	this.instance_3.setTransform(-61,-79);

	this.instance_4 = new lib.Bitmap681();
	this.instance_4.setTransform(-61,-79);

	this.instance_5 = new lib.Bitmap682();
	this.instance_5.setTransform(-61,-79);

	this.instance_6 = new lib.Bitmap683();
	this.instance_6.setTransform(-61,-79);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-79,122,158);


(lib.ball12p12mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap670();
	this.instance.setTransform(-70,-53);

	this.instance_1 = new lib.Bitmap671();
	this.instance_1.setTransform(-70,-53);

	this.instance_2 = new lib.Bitmap672();
	this.instance_2.setTransform(-70,-53);

	this.instance_3 = new lib.Bitmap673();
	this.instance_3.setTransform(-70,-53);

	this.instance_4 = new lib.Bitmap674();
	this.instance_4.setTransform(-70,-53);

	this.instance_5 = new lib.Bitmap675();
	this.instance_5.setTransform(-70,-53);

	this.instance_6 = new lib.Bitmap676();
	this.instance_6.setTransform(-70,-53);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,-53,140,106);


(lib.ball12p11mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap663();
	this.instance.setTransform(-43,-48);

	this.instance_1 = new lib.Bitmap664();
	this.instance_1.setTransform(-43,-48);

	this.instance_2 = new lib.Bitmap665();
	this.instance_2.setTransform(-43,-48);

	this.instance_3 = new lib.Bitmap666();
	this.instance_3.setTransform(-43,-48);

	this.instance_4 = new lib.Bitmap667();
	this.instance_4.setTransform(-43,-48);

	this.instance_5 = new lib.Bitmap668();
	this.instance_5.setTransform(-43,-48);

	this.instance_6 = new lib.Bitmap669();
	this.instance_6.setTransform(-43,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43,-48,86,95);


(lib.ball12p10mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap656();
	this.instance.setTransform(-43,-49);

	this.instance_1 = new lib.Bitmap657();
	this.instance_1.setTransform(-43,-49);

	this.instance_2 = new lib.Bitmap658();
	this.instance_2.setTransform(-43,-49);

	this.instance_3 = new lib.Bitmap659();
	this.instance_3.setTransform(-43,-49);

	this.instance_4 = new lib.Bitmap660();
	this.instance_4.setTransform(-43,-49);

	this.instance_5 = new lib.Bitmap661();
	this.instance_5.setTransform(-43,-49);

	this.instance_6 = new lib.Bitmap662();
	this.instance_6.setTransform(-43,-49);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43,-49,86,99);


(lib.ball12p9mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap649();
	this.instance.setTransform(-33,-53);

	this.instance_1 = new lib.Bitmap650();
	this.instance_1.setTransform(-33,-53);

	this.instance_2 = new lib.Bitmap651();
	this.instance_2.setTransform(-33,-53);

	this.instance_3 = new lib.Bitmap652();
	this.instance_3.setTransform(-33,-53);

	this.instance_4 = new lib.Bitmap653();
	this.instance_4.setTransform(-33,-53);

	this.instance_5 = new lib.Bitmap654();
	this.instance_5.setTransform(-33,-53);

	this.instance_6 = new lib.Bitmap655();
	this.instance_6.setTransform(-33,-53);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-53,67,107);


(lib.ball12p8mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap642();
	this.instance.setTransform(-72,-55);

	this.instance_1 = new lib.Bitmap643();
	this.instance_1.setTransform(-72,-55);

	this.instance_2 = new lib.Bitmap644();
	this.instance_2.setTransform(-72,-55);

	this.instance_3 = new lib.Bitmap645();
	this.instance_3.setTransform(-72,-55);

	this.instance_4 = new lib.Bitmap646();
	this.instance_4.setTransform(-72,-55);

	this.instance_5 = new lib.Bitmap647();
	this.instance_5.setTransform(-72,-55);

	this.instance_6 = new lib.Bitmap648();
	this.instance_6.setTransform(-72,-55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72,-55,143,110);


(lib.ball12p7mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap635();
	this.instance.setTransform(-45,-51);

	this.instance_1 = new lib.Bitmap636();
	this.instance_1.setTransform(-45,-51);

	this.instance_2 = new lib.Bitmap637();
	this.instance_2.setTransform(-45,-51);

	this.instance_3 = new lib.Bitmap638();
	this.instance_3.setTransform(-45,-51);

	this.instance_4 = new lib.Bitmap639();
	this.instance_4.setTransform(-45,-51);

	this.instance_5 = new lib.Bitmap640();
	this.instance_5.setTransform(-45,-51);

	this.instance_6 = new lib.Bitmap641();
	this.instance_6.setTransform(-45,-51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45,-51,90,102);


(lib.ball12p6mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap628();
	this.instance.setTransform(-37,-51);

	this.instance_1 = new lib.Bitmap629();
	this.instance_1.setTransform(-37,-51);

	this.instance_2 = new lib.Bitmap630();
	this.instance_2.setTransform(-37,-51);

	this.instance_3 = new lib.Bitmap631();
	this.instance_3.setTransform(-37,-51);

	this.instance_4 = new lib.Bitmap632();
	this.instance_4.setTransform(-37,-51);

	this.instance_5 = new lib.Bitmap633();
	this.instance_5.setTransform(-37,-51);

	this.instance_6 = new lib.Bitmap634();
	this.instance_6.setTransform(-37,-51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37,-51,73,101);


(lib.ball12p5mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap621();
	this.instance.setTransform(-33,-48);

	this.instance_1 = new lib.Bitmap622();
	this.instance_1.setTransform(-33,-48);

	this.instance_2 = new lib.Bitmap623();
	this.instance_2.setTransform(-33,-48);

	this.instance_3 = new lib.Bitmap624();
	this.instance_3.setTransform(-33,-48);

	this.instance_4 = new lib.Bitmap625();
	this.instance_4.setTransform(-33,-48);

	this.instance_5 = new lib.Bitmap626();
	this.instance_5.setTransform(-33,-48);

	this.instance_6 = new lib.Bitmap627();
	this.instance_6.setTransform(-33,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-48,66,95);


(lib.ball12p4mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap614();
	this.instance.setTransform(-97,-90);

	this.instance_1 = new lib.Bitmap615();
	this.instance_1.setTransform(-97,-90);

	this.instance_2 = new lib.Bitmap616();
	this.instance_2.setTransform(-97,-90);

	this.instance_3 = new lib.Bitmap617();
	this.instance_3.setTransform(-97,-90);

	this.instance_4 = new lib.Bitmap618();
	this.instance_4.setTransform(-97,-90);

	this.instance_5 = new lib.Bitmap619();
	this.instance_5.setTransform(-97,-90);

	this.instance_6 = new lib.Bitmap620();
	this.instance_6.setTransform(-97,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-90,194,179);


(lib.ball12p2mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap600();
	this.instance.setTransform(-54,-48);

	this.instance_1 = new lib.Bitmap601();
	this.instance_1.setTransform(-54,-48);

	this.instance_2 = new lib.Bitmap602();
	this.instance_2.setTransform(-54,-48);

	this.instance_3 = new lib.Bitmap603();
	this.instance_3.setTransform(-54,-48);

	this.instance_4 = new lib.Bitmap604();
	this.instance_4.setTransform(-54,-48);

	this.instance_5 = new lib.Bitmap605();
	this.instance_5.setTransform(-54,-48);

	this.instance_6 = new lib.Bitmap606();
	this.instance_6.setTransform(-54,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-48,107,97);


(lib.ball11p20mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap592();
	this.instance.setTransform(-97,-48);

	this.instance_1 = new lib.Bitmap593();
	this.instance_1.setTransform(-97,-48);

	this.instance_2 = new lib.Bitmap594();
	this.instance_2.setTransform(-97,-48);

	this.instance_3 = new lib.Bitmap595();
	this.instance_3.setTransform(-97,-48);

	this.instance_4 = new lib.Bitmap596();
	this.instance_4.setTransform(-97,-48);

	this.instance_5 = new lib.Bitmap597();
	this.instance_5.setTransform(-97,-48);

	this.instance_6 = new lib.Bitmap598();
	this.instance_6.setTransform(-97,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-48,194,96);


(lib.ball11p19mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap585();
	this.instance.setTransform(-64,-48);

	this.instance_1 = new lib.Bitmap586();
	this.instance_1.setTransform(-64,-48);

	this.instance_2 = new lib.Bitmap587();
	this.instance_2.setTransform(-64,-48);

	this.instance_3 = new lib.Bitmap588();
	this.instance_3.setTransform(-64,-48);

	this.instance_4 = new lib.Bitmap589();
	this.instance_4.setTransform(-64,-48);

	this.instance_5 = new lib.Bitmap590();
	this.instance_5.setTransform(-64,-48);

	this.instance_6 = new lib.Bitmap591();
	this.instance_6.setTransform(-64,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-48,128,96);


(lib.ball11p18mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap578();
	this.instance.setTransform(-103,-36);

	this.instance_1 = new lib.Bitmap579();
	this.instance_1.setTransform(-103,-36);

	this.instance_2 = new lib.Bitmap580();
	this.instance_2.setTransform(-103,-36);

	this.instance_3 = new lib.Bitmap581();
	this.instance_3.setTransform(-103,-36);

	this.instance_4 = new lib.Bitmap582();
	this.instance_4.setTransform(-103,-36);

	this.instance_5 = new lib.Bitmap583();
	this.instance_5.setTransform(-103,-36);

	this.instance_6 = new lib.Bitmap584();
	this.instance_6.setTransform(-103,-36);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103,-36,205,71);


(lib.ball11p17mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap571();
	this.instance.setTransform(-64,-32);

	this.instance_1 = new lib.Bitmap572();
	this.instance_1.setTransform(-64,-32);

	this.instance_2 = new lib.Bitmap573();
	this.instance_2.setTransform(-64,-32);

	this.instance_3 = new lib.Bitmap574();
	this.instance_3.setTransform(-64,-32);

	this.instance_4 = new lib.Bitmap575();
	this.instance_4.setTransform(-64,-32);

	this.instance_5 = new lib.Bitmap576();
	this.instance_5.setTransform(-64,-32);

	this.instance_6 = new lib.Bitmap577();
	this.instance_6.setTransform(-64,-32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-32,128,64);


(lib.ball11p16mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap564();
	this.instance.setTransform(-112,-44);

	this.instance_1 = new lib.Bitmap565();
	this.instance_1.setTransform(-112,-44);

	this.instance_2 = new lib.Bitmap566();
	this.instance_2.setTransform(-112,-44);

	this.instance_3 = new lib.Bitmap567();
	this.instance_3.setTransform(-112,-44);

	this.instance_4 = new lib.Bitmap568();
	this.instance_4.setTransform(-112,-44);

	this.instance_5 = new lib.Bitmap569();
	this.instance_5.setTransform(-112,-44);

	this.instance_6 = new lib.Bitmap570();
	this.instance_6.setTransform(-112,-44);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-44,225,88);


(lib.ball11p15mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap557();
	this.instance.setTransform(-70,-44);

	this.instance_1 = new lib.Bitmap558();
	this.instance_1.setTransform(-70,-44);

	this.instance_2 = new lib.Bitmap559();
	this.instance_2.setTransform(-70,-44);

	this.instance_3 = new lib.Bitmap560();
	this.instance_3.setTransform(-70,-44);

	this.instance_4 = new lib.Bitmap561();
	this.instance_4.setTransform(-70,-44);

	this.instance_5 = new lib.Bitmap562();
	this.instance_5.setTransform(-70,-44);

	this.instance_6 = new lib.Bitmap563();
	this.instance_6.setTransform(-70,-44);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,-44,140,89);


(lib.ball11p14mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap543();
	this.instance.setTransform(-81,-33);

	this.instance_1 = new lib.Bitmap544();
	this.instance_1.setTransform(-81,-33);

	this.instance_2 = new lib.Bitmap545();
	this.instance_2.setTransform(-81,-33);

	this.instance_3 = new lib.Bitmap546();
	this.instance_3.setTransform(-81,-33);

	this.instance_4 = new lib.Bitmap547();
	this.instance_4.setTransform(-81,-33);

	this.instance_5 = new lib.Bitmap548();
	this.instance_5.setTransform(-81,-33);

	this.instance_6 = new lib.Bitmap549();
	this.instance_6.setTransform(-81,-33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81,-33,163,66);


(lib.ball11p13mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap550();
	this.instance.setTransform(-41,-22);

	this.instance_1 = new lib.Bitmap551();
	this.instance_1.setTransform(-41,-22);

	this.instance_2 = new lib.Bitmap552();
	this.instance_2.setTransform(-41,-22);

	this.instance_3 = new lib.Bitmap553();
	this.instance_3.setTransform(-41,-22);

	this.instance_4 = new lib.Bitmap554();
	this.instance_4.setTransform(-41,-22);

	this.instance_5 = new lib.Bitmap555();
	this.instance_5.setTransform(-41,-22);

	this.instance_6 = new lib.Bitmap556();
	this.instance_6.setTransform(-41,-22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-22,83,44);


(lib.ball11p12mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap529();
	this.instance.setTransform(-61,-34);

	this.instance_1 = new lib.Bitmap530();
	this.instance_1.setTransform(-61,-34);

	this.instance_2 = new lib.Bitmap531();
	this.instance_2.setTransform(-61,-34);

	this.instance_3 = new lib.Bitmap532();
	this.instance_3.setTransform(-61,-34);

	this.instance_4 = new lib.Bitmap533();
	this.instance_4.setTransform(-61,-34);

	this.instance_5 = new lib.Bitmap534();
	this.instance_5.setTransform(-61,-34);

	this.instance_6 = new lib.Bitmap535();
	this.instance_6.setTransform(-61,-34);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-34,122,67);


(lib.ball11p11mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap536();
	this.instance.setTransform(-36,-22);

	this.instance_1 = new lib.Bitmap537();
	this.instance_1.setTransform(-36,-22);

	this.instance_2 = new lib.Bitmap538();
	this.instance_2.setTransform(-36,-22);

	this.instance_3 = new lib.Bitmap539();
	this.instance_3.setTransform(-36,-22);

	this.instance_4 = new lib.Bitmap540();
	this.instance_4.setTransform(-36,-22);

	this.instance_5 = new lib.Bitmap541();
	this.instance_5.setTransform(-36,-22);

	this.instance_6 = new lib.Bitmap542();
	this.instance_6.setTransform(-36,-22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36,-22,73,44);


(lib.ball11p10mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap522();
	this.instance.setTransform(-42,-23);

	this.instance_1 = new lib.Bitmap523();
	this.instance_1.setTransform(-42,-23);

	this.instance_2 = new lib.Bitmap524();
	this.instance_2.setTransform(-42,-23);

	this.instance_3 = new lib.Bitmap525();
	this.instance_3.setTransform(-42,-23);

	this.instance_4 = new lib.Bitmap526();
	this.instance_4.setTransform(-42,-23);

	this.instance_5 = new lib.Bitmap527();
	this.instance_5.setTransform(-42,-23);

	this.instance_6 = new lib.Bitmap528();
	this.instance_6.setTransform(-42,-23);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42,-23,83,46);


(lib.ball11p9mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap515();
	this.instance.setTransform(-81,-29);

	this.instance_1 = new lib.Bitmap516();
	this.instance_1.setTransform(-81,-29);

	this.instance_2 = new lib.Bitmap517();
	this.instance_2.setTransform(-81,-29);

	this.instance_3 = new lib.Bitmap518();
	this.instance_3.setTransform(-81,-29);

	this.instance_4 = new lib.Bitmap519();
	this.instance_4.setTransform(-81,-29);

	this.instance_5 = new lib.Bitmap520();
	this.instance_5.setTransform(-81,-29);

	this.instance_6 = new lib.Bitmap521();
	this.instance_6.setTransform(-81,-29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81,-29,163,58);


(lib.ball11p8mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap508();
	this.instance.setTransform(-36,-21);

	this.instance_1 = new lib.Bitmap509();
	this.instance_1.setTransform(-36,-21);

	this.instance_2 = new lib.Bitmap510();
	this.instance_2.setTransform(-36,-21);

	this.instance_3 = new lib.Bitmap511();
	this.instance_3.setTransform(-36,-21);

	this.instance_4 = new lib.Bitmap512();
	this.instance_4.setTransform(-36,-21);

	this.instance_5 = new lib.Bitmap513();
	this.instance_5.setTransform(-36,-21);

	this.instance_6 = new lib.Bitmap514();
	this.instance_6.setTransform(-36,-21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36,-21,73,42);


(lib.ball11p7mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap501();
	this.instance.setTransform(-61,-32);

	this.instance_1 = new lib.Bitmap502();
	this.instance_1.setTransform(-61,-32);

	this.instance_2 = new lib.Bitmap503();
	this.instance_2.setTransform(-61,-32);

	this.instance_3 = new lib.Bitmap504();
	this.instance_3.setTransform(-61,-32);

	this.instance_4 = new lib.Bitmap505();
	this.instance_4.setTransform(-61,-32);

	this.instance_5 = new lib.Bitmap506();
	this.instance_5.setTransform(-61,-32);

	this.instance_6 = new lib.Bitmap507();
	this.instance_6.setTransform(-61,-32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-32,122,64);


(lib.ball11p6mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap494();
	this.instance.setTransform(-112,-45);

	this.instance_1 = new lib.Bitmap495();
	this.instance_1.setTransform(-112,-45);

	this.instance_2 = new lib.Bitmap496();
	this.instance_2.setTransform(-112,-45);

	this.instance_3 = new lib.Bitmap497();
	this.instance_3.setTransform(-112,-45);

	this.instance_4 = new lib.Bitmap498();
	this.instance_4.setTransform(-112,-45);

	this.instance_5 = new lib.Bitmap499();
	this.instance_5.setTransform(-112,-45);

	this.instance_6 = new lib.Bitmap500();
	this.instance_6.setTransform(-112,-45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-45,225,90);


(lib.ball11p5mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap487();
	this.instance.setTransform(-69,-45);

	this.instance_1 = new lib.Bitmap488();
	this.instance_1.setTransform(-69,-45);

	this.instance_2 = new lib.Bitmap489();
	this.instance_2.setTransform(-69,-45);

	this.instance_3 = new lib.Bitmap490();
	this.instance_3.setTransform(-69,-45);

	this.instance_4 = new lib.Bitmap491();
	this.instance_4.setTransform(-69,-45);

	this.instance_5 = new lib.Bitmap492();
	this.instance_5.setTransform(-69,-45);

	this.instance_6 = new lib.Bitmap493();
	this.instance_6.setTransform(-69,-45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69,-45,137,90);


(lib.ball11p4mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap480();
	this.instance.setTransform(-104,-33);

	this.instance_1 = new lib.Bitmap481();
	this.instance_1.setTransform(-104,-33);

	this.instance_2 = new lib.Bitmap482();
	this.instance_2.setTransform(-104,-33);

	this.instance_3 = new lib.Bitmap483();
	this.instance_3.setTransform(-104,-33);

	this.instance_4 = new lib.Bitmap484();
	this.instance_4.setTransform(-104,-33);

	this.instance_5 = new lib.Bitmap485();
	this.instance_5.setTransform(-104,-33);

	this.instance_6 = new lib.Bitmap486();
	this.instance_6.setTransform(-104,-33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104,-33,209,66);


(lib.ball11p3mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap473();
	this.instance.setTransform(-62,-31);

	this.instance_1 = new lib.Bitmap474();
	this.instance_1.setTransform(-62,-31);

	this.instance_2 = new lib.Bitmap475();
	this.instance_2.setTransform(-62,-31);

	this.instance_3 = new lib.Bitmap476();
	this.instance_3.setTransform(-62,-31);

	this.instance_4 = new lib.Bitmap477();
	this.instance_4.setTransform(-62,-31);

	this.instance_5 = new lib.Bitmap478();
	this.instance_5.setTransform(-62,-31);

	this.instance_6 = new lib.Bitmap479();
	this.instance_6.setTransform(-62,-31);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-31,124,61);


(lib.ball11p2movn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap466();
	this.instance.setTransform(-94,-64);

	this.instance_1 = new lib.Bitmap467();
	this.instance_1.setTransform(-94,-64);

	this.instance_2 = new lib.Bitmap468();
	this.instance_2.setTransform(-94,-64);

	this.instance_3 = new lib.Bitmap469();
	this.instance_3.setTransform(-94,-64);

	this.instance_4 = new lib.Bitmap470();
	this.instance_4.setTransform(-94,-64);

	this.instance_5 = new lib.Bitmap471();
	this.instance_5.setTransform(-94,-64);

	this.instance_6 = new lib.Bitmap472();
	this.instance_6.setTransform(-94,-64);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94,-64,189,127);


(lib.ball11p1mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap459();
	this.instance.setTransform(-67,-63);

	this.instance_1 = new lib.Bitmap460();
	this.instance_1.setTransform(-67,-63);

	this.instance_2 = new lib.Bitmap461();
	this.instance_2.setTransform(-67,-63);

	this.instance_3 = new lib.Bitmap462();
	this.instance_3.setTransform(-67,-63);

	this.instance_4 = new lib.Bitmap463();
	this.instance_4.setTransform(-67,-63);

	this.instance_5 = new lib.Bitmap464();
	this.instance_5.setTransform(-67,-63);

	this.instance_6 = new lib.Bitmap465();
	this.instance_6.setTransform(-67,-63);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67,-63,134,127);


(lib.ball5p16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap291();
	this.instance.setTransform(-64,-45);

	this.instance_1 = new lib.Bitmap292();
	this.instance_1.setTransform(-64,-45);

	this.instance_2 = new lib.Bitmap293();
	this.instance_2.setTransform(-64,-45);

	this.instance_3 = new lib.Bitmap294();
	this.instance_3.setTransform(-64,-45);

	this.instance_4 = new lib.Bitmap295();
	this.instance_4.setTransform(-64,-45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-45,128,89);


(lib.ball5p15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap296();
	this.instance.setTransform(-94,-57);

	this.instance_1 = new lib.Bitmap297();
	this.instance_1.setTransform(-94,-57);

	this.instance_2 = new lib.Bitmap298();
	this.instance_2.setTransform(-94,-57);

	this.instance_3 = new lib.Bitmap299();
	this.instance_3.setTransform(-94,-57);

	this.instance_4 = new lib.Bitmap300();
	this.instance_4.setTransform(-94,-57);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94,-57,187,114);


(lib.ball5p13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap306();
	this.instance.setTransform(-48,-37);

	this.instance_1 = new lib.Bitmap307();
	this.instance_1.setTransform(-48,-37);

	this.instance_2 = new lib.Bitmap308();
	this.instance_2.setTransform(-48,-37);

	this.instance_3 = new lib.Bitmap309();
	this.instance_3.setTransform(-48,-37);

	this.instance_4 = new lib.Bitmap310();
	this.instance_4.setTransform(-48,-37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48,-37,97,75);


(lib.ball5p12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap311();
	this.instance.setTransform(-41,-38);

	this.instance_1 = new lib.Bitmap312();
	this.instance_1.setTransform(-41,-38);

	this.instance_2 = new lib.Bitmap313();
	this.instance_2.setTransform(-41,-38);

	this.instance_3 = new lib.Bitmap314();
	this.instance_3.setTransform(-41,-38);

	this.instance_4 = new lib.Bitmap315();
	this.instance_4.setTransform(-41,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-38,82,76);


(lib.ball5p11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap316();
	this.instance.setTransform(-64,-46);

	this.instance_1 = new lib.Bitmap317();
	this.instance_1.setTransform(-64,-46);

	this.instance_2 = new lib.Bitmap318();
	this.instance_2.setTransform(-64,-46);

	this.instance_3 = new lib.Bitmap319();
	this.instance_3.setTransform(-64,-46);

	this.instance_4 = new lib.Bitmap320();
	this.instance_4.setTransform(-64,-46);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-46,128,93);


(lib.ball5p10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap361();
	this.instance.setTransform(-97,-64);

	this.instance_1 = new lib.Bitmap362();
	this.instance_1.setTransform(-97,-64);

	this.instance_2 = new lib.Bitmap363();
	this.instance_2.setTransform(-97,-64);

	this.instance_3 = new lib.Bitmap364();
	this.instance_3.setTransform(-97,-64);

	this.instance_4 = new lib.Bitmap365();
	this.instance_4.setTransform(-97,-64);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-64,194,129);


(lib.ball5p8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap341();
	this.instance.setTransform(-46,-60);

	this.instance_1 = new lib.Bitmap342();
	this.instance_1.setTransform(-46,-60);

	this.instance_2 = new lib.Bitmap343();
	this.instance_2.setTransform(-46,-60);

	this.instance_3 = new lib.Bitmap344();
	this.instance_3.setTransform(-46,-60);

	this.instance_4 = new lib.Bitmap345();
	this.instance_4.setTransform(-46,-60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46,-60,91,120);


(lib.ball5p7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap346();
	this.instance.setTransform(-43,-51);

	this.instance_1 = new lib.Bitmap347();
	this.instance_1.setTransform(-43,-51);

	this.instance_2 = new lib.Bitmap348();
	this.instance_2.setTransform(-43,-51);

	this.instance_3 = new lib.Bitmap349();
	this.instance_3.setTransform(-43,-51);

	this.instance_4 = new lib.Bitmap350();
	this.instance_4.setTransform(-43,-51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43,-51,85,102);


(lib.bal12p3mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap607();
	this.instance.setTransform(-59,-85);

	this.instance_1 = new lib.Bitmap608();
	this.instance_1.setTransform(-59,-85);

	this.instance_2 = new lib.Bitmap609();
	this.instance_2.setTransform(-59,-85);

	this.instance_3 = new lib.Bitmap610();
	this.instance_3.setTransform(-59,-85);

	this.instance_4 = new lib.Bitmap611();
	this.instance_4.setTransform(-59,-85);

	this.instance_5 = new lib.Bitmap612();
	this.instance_5.setTransform(-59,-85);

	this.instance_6 = new lib.Bitmap613();
	this.instance_6.setTransform(-59,-85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-85,118,170);


(lib.bal12p1mov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"zwart":3,"rood":4,"paars":5,"geel":6});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(-34,-48);

	this.instance_1 = new lib.Bitmap248();
	this.instance_1.setTransform(-34,-48);

	this.instance_2 = new lib.Bitmap450();
	this.instance_2.setTransform(-34,-48);

	this.instance_3 = new lib.Bitmap451();
	this.instance_3.setTransform(-34,-48);

	this.instance_4 = new lib.Bitmap452();
	this.instance_4.setTransform(-34,-48);

	this.instance_5 = new lib.Bitmap453();
	this.instance_5.setTransform(-34,-48);

	this.instance_6 = new lib.Bitmap599();
	this.instance_6.setTransform(-34,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34,-48,67,95);


(lib.bal8p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{gras1:0,gras2:1,gras3:2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-97,-94);

	this.instance_1 = new lib.Bitmap26();
	this.instance_1.setTransform(-97,-94);

	this.instance_2 = new lib.Bitmap27();
	this.instance_2.setTransform(-97,-94);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-94,194,187);


(lib.bal8p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"gras1":0,"gras2":1,"gras3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap199();
	this.instance.setTransform(-98,-100);

	this.instance_1 = new lib.Bitmap240();
	this.instance_1.setTransform(-98,-100);

	this.instance_2 = new lib.Bitmap241();
	this.instance_2.setTransform(-98,-100);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98,-100,196,200);


(lib.bal8p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"gras1":0,"gras2":1,"gras3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap242();
	this.instance.setTransform(-98,-190);

	this.instance_1 = new lib.Bitmap243();
	this.instance_1.setTransform(-98,-190);

	this.instance_2 = new lib.Bitmap244();
	this.instance_2.setTransform(-98,-190);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98,-190,196,380);


(lib.bal8p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"gras1":0,"gras2":1,"gras3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap245();
	this.instance.setTransform(-97,-190);

	this.instance_1 = new lib.Bitmap246();
	this.instance_1.setTransform(-97,-190);

	this.instance_2 = new lib.Bitmap247();
	this.instance_2.setTransform(-97,-190);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97,-190,194,379);


(lib.bal5p22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap261();
	this.instance.setTransform(-73,-43);

	this.instance_1 = new lib.Bitmap262();
	this.instance_1.setTransform(-73,-43);

	this.instance_2 = new lib.Bitmap263();
	this.instance_2.setTransform(-73,-43);

	this.instance_3 = new lib.Bitmap264();
	this.instance_3.setTransform(-73,-43);

	this.instance_4 = new lib.Bitmap265();
	this.instance_4.setTransform(-73,-43);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-73,-43,144,84);


(lib.bal5p21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap266();
	this.instance.setTransform(-51,-35);

	this.instance_1 = new lib.Bitmap267();
	this.instance_1.setTransform(-51,-35);

	this.instance_2 = new lib.Bitmap268();
	this.instance_2.setTransform(-51,-35);

	this.instance_3 = new lib.Bitmap269();
	this.instance_3.setTransform(-51,-35);

	this.instance_4 = new lib.Bitmap270();
	this.instance_4.setTransform(-51,-35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51,-35,103,67);


(lib.bal5p20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap271();
	this.instance.setTransform(-45,-39);

	this.instance_1 = new lib.Bitmap272();
	this.instance_1.setTransform(-45,-39);

	this.instance_2 = new lib.Bitmap273();
	this.instance_2.setTransform(-45,-39);

	this.instance_3 = new lib.Bitmap274();
	this.instance_3.setTransform(-45,-39);

	this.instance_4 = new lib.Bitmap275();
	this.instance_4.setTransform(-45,-39);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45,-39,90,77);


(lib.bal5p19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap276();
	this.instance.setTransform(-76,-37);

	this.instance_1 = new lib.Bitmap277();
	this.instance_1.setTransform(-76,-37);

	this.instance_2 = new lib.Bitmap278();
	this.instance_2.setTransform(-76,-37);

	this.instance_3 = new lib.Bitmap279();
	this.instance_3.setTransform(-76,-37);

	this.instance_4 = new lib.Bitmap280();
	this.instance_4.setTransform(-76,-37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76,-37,152,74);


(lib.bal5p18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap281();
	this.instance.setTransform(-38,-23);

	this.instance_1 = new lib.Bitmap282();
	this.instance_1.setTransform(-38,-23);

	this.instance_2 = new lib.Bitmap283();
	this.instance_2.setTransform(-38,-23);

	this.instance_3 = new lib.Bitmap284();
	this.instance_3.setTransform(-38,-23);

	this.instance_4 = new lib.Bitmap285();
	this.instance_4.setTransform(-38,-23);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38,-23,75,47);


(lib.bal5p17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap286();
	this.instance.setTransform(-46,-33);

	this.instance_1 = new lib.Bitmap287();
	this.instance_1.setTransform(-46,-33);

	this.instance_2 = new lib.Bitmap288();
	this.instance_2.setTransform(-46,-33);

	this.instance_3 = new lib.Bitmap289();
	this.instance_3.setTransform(-46,-33);

	this.instance_4 = new lib.Bitmap290();
	this.instance_4.setTransform(-46,-33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46,-33,93,65);


(lib.bal5p14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap301();
	this.instance.setTransform(-46,-39);

	this.instance_1 = new lib.Bitmap302();
	this.instance_1.setTransform(-46,-39);

	this.instance_2 = new lib.Bitmap303();
	this.instance_2.setTransform(-46,-39);

	this.instance_3 = new lib.Bitmap304();
	this.instance_3.setTransform(-46,-39);

	this.instance_4 = new lib.Bitmap305();
	this.instance_4.setTransform(-46,-39);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46,-39,93,79);


(lib.bal5p9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap366();
	this.instance.setTransform(-41,-48);

	this.instance_1 = new lib.Bitmap367();
	this.instance_1.setTransform(-41,-48);

	this.instance_2 = new lib.Bitmap368();
	this.instance_2.setTransform(-41,-48);

	this.instance_3 = new lib.Bitmap369();
	this.instance_3.setTransform(-41,-48);

	this.instance_4 = new lib.Bitmap370();
	this.instance_4.setTransform(-41,-48);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-48,80,97);


(lib.bal5p6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap321();
	this.instance.setTransform(-91,-42);

	this.instance_1 = new lib.Bitmap322();
	this.instance_1.setTransform(-91,-42);

	this.instance_2 = new lib.Bitmap323();
	this.instance_2.setTransform(-91,-42);

	this.instance_3 = new lib.Bitmap324();
	this.instance_3.setTransform(-91,-42);

	this.instance_4 = new lib.Bitmap325();
	this.instance_4.setTransform(-91,-42);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91,-42,180,85);


(lib.bal5p5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap326();
	this.instance.setTransform(-36,-32);

	this.instance_1 = new lib.Bitmap327();
	this.instance_1.setTransform(-36,-32);

	this.instance_2 = new lib.Bitmap328();
	this.instance_2.setTransform(-36,-32);

	this.instance_3 = new lib.Bitmap329();
	this.instance_3.setTransform(-36,-32);

	this.instance_4 = new lib.Bitmap330();
	this.instance_4.setTransform(-36,-32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36,-32,72,65);


(lib.bal5p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap351();
	this.instance.setTransform(-42,-38);

	this.instance_1 = new lib.Bitmap352();
	this.instance_1.setTransform(-42,-38);

	this.instance_2 = new lib.Bitmap353();
	this.instance_2.setTransform(-42,-38);

	this.instance_3 = new lib.Bitmap354();
	this.instance_3.setTransform(-42,-38);

	this.instance_4 = new lib.Bitmap355();
	this.instance_4.setTransform(-42,-38);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42,-38,83,75);


(lib.bal5p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap356();
	this.instance.setTransform(-77,-73);

	this.instance_1 = new lib.Bitmap357();
	this.instance_1.setTransform(-77,-73);

	this.instance_2 = new lib.Bitmap358();
	this.instance_2.setTransform(-77,-73);

	this.instance_3 = new lib.Bitmap359();
	this.instance_3.setTransform(-77,-73);

	this.instance_4 = new lib.Bitmap360();
	this.instance_4.setTransform(-77,-73);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77,-73,154,147);


(lib.bal5p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap331();
	this.instance.setTransform(-57,-74);

	this.instance_1 = new lib.Bitmap332();
	this.instance_1.setTransform(-57,-74);

	this.instance_2 = new lib.Bitmap333();
	this.instance_2.setTransform(-57,-74);

	this.instance_3 = new lib.Bitmap334();
	this.instance_3.setTransform(-57,-74);

	this.instance_4 = new lib.Bitmap335();
	this.instance_4.setTransform(-57,-74);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57,-74,114,150);


(lib.bal5p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"oranje":1,"blauw":2,"rood":3,"geel":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap336();
	this.instance.setTransform(-59,-66);

	this.instance_1 = new lib.Bitmap337();
	this.instance_1.setTransform(-59,-66);

	this.instance_2 = new lib.Bitmap338();
	this.instance_2.setTransform(-59,-66);

	this.instance_3 = new lib.Bitmap339();
	this.instance_3.setTransform(-59,-66);

	this.instance_4 = new lib.Bitmap340();
	this.instance_4.setTransform(-59,-66);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-66,117,133);


(lib.bal3p18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap91();
	this.instance.setTransform(-50,-32);

	this.instance_1 = new lib.Bitmap92();
	this.instance_1.setTransform(-50,-32);

	this.instance_2 = new lib.Bitmap93();
	this.instance_2.setTransform(-50,-32);

	this.instance_3 = new lib.Bitmap94();
	this.instance_3.setTransform(-50,-32);

	this.instance_4 = new lib.Bitmap95();
	this.instance_4.setTransform(-50,-32);

	this.instance_5 = new lib.Bitmap96();
	this.instance_5.setTransform(-50,-32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50,-32,99,63);


(lib.bal3p17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap97();
	this.instance.setTransform(-89,-34);

	this.instance_1 = new lib.Bitmap98();
	this.instance_1.setTransform(-89,-34);

	this.instance_2 = new lib.Bitmap99();
	this.instance_2.setTransform(-89,-34);

	this.instance_3 = new lib.Bitmap100();
	this.instance_3.setTransform(-89,-34);

	this.instance_4 = new lib.Bitmap101();
	this.instance_4.setTransform(-89,-34);

	this.instance_5 = new lib.Bitmap102();
	this.instance_5.setTransform(-89,-34);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89,-34,178,67);


(lib.bal3p16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap103();
	this.instance.setTransform(-160,-44);

	this.instance_1 = new lib.Bitmap104();
	this.instance_1.setTransform(-160,-44);

	this.instance_2 = new lib.Bitmap105();
	this.instance_2.setTransform(-160,-44);

	this.instance_3 = new lib.Bitmap106();
	this.instance_3.setTransform(-160,-44);

	this.instance_4 = new lib.Bitmap107();
	this.instance_4.setTransform(-160,-44);

	this.instance_5 = new lib.Bitmap108();
	this.instance_5.setTransform(-160,-44);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160,-44,320,88);


(lib.bal3p15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap109();
	this.instance.setTransform(-41,-21);

	this.instance_1 = new lib.Bitmap110();
	this.instance_1.setTransform(-41,-21);

	this.instance_2 = new lib.Bitmap111();
	this.instance_2.setTransform(-41,-21);

	this.instance_3 = new lib.Bitmap112();
	this.instance_3.setTransform(-41,-21);

	this.instance_4 = new lib.Bitmap113();
	this.instance_4.setTransform(-41,-21);

	this.instance_5 = new lib.Bitmap114();
	this.instance_5.setTransform(-41,-21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-21,84,44);


(lib.bal3p14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap115();
	this.instance.setTransform(-86,-25);

	this.instance_1 = new lib.Bitmap116();
	this.instance_1.setTransform(-86,-25);

	this.instance_2 = new lib.Bitmap117();
	this.instance_2.setTransform(-86,-25);

	this.instance_3 = new lib.Bitmap118();
	this.instance_3.setTransform(-86,-25);

	this.instance_4 = new lib.Bitmap119();
	this.instance_4.setTransform(-86,-25);

	this.instance_5 = new lib.Bitmap120();
	this.instance_5.setTransform(-86,-25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-86,-25,173,51);


(lib.bal3p13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap121();
	this.instance.setTransform(-173,-35);

	this.instance_1 = new lib.Bitmap122();
	this.instance_1.setTransform(-173,-35);

	this.instance_2 = new lib.Bitmap123();
	this.instance_2.setTransform(-173,-35);

	this.instance_3 = new lib.Bitmap124();
	this.instance_3.setTransform(-173,-35);

	this.instance_4 = new lib.Bitmap125();
	this.instance_4.setTransform(-173,-35);

	this.instance_5 = new lib.Bitmap126();
	this.instance_5.setTransform(-173,-35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-173,-35,347,72);


(lib.bal3p12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap127();
	this.instance.setTransform(-39,-20);

	this.instance_1 = new lib.Bitmap128();
	this.instance_1.setTransform(-39,-20);

	this.instance_2 = new lib.Bitmap129();
	this.instance_2.setTransform(-39,-20);

	this.instance_3 = new lib.Bitmap130();
	this.instance_3.setTransform(-39,-20);

	this.instance_4 = new lib.Bitmap131();
	this.instance_4.setTransform(-39,-20);

	this.instance_5 = new lib.Bitmap132();
	this.instance_5.setTransform(-39,-20);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-20,77,40);


(lib.bal3p11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap133();
	this.instance.setTransform(-83,-24);

	this.instance_1 = new lib.Bitmap134();
	this.instance_1.setTransform(-83,-24);

	this.instance_2 = new lib.Bitmap135();
	this.instance_2.setTransform(-83,-24);

	this.instance_3 = new lib.Bitmap136();
	this.instance_3.setTransform(-83,-24);

	this.instance_4 = new lib.Bitmap137();
	this.instance_4.setTransform(-83,-24);

	this.instance_5 = new lib.Bitmap138();
	this.instance_5.setTransform(-83,-24);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-24,167,49);


(lib.bal3p10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap187();
	this.instance.setTransform(-180,-37);

	this.instance_1 = new lib.Bitmap188();
	this.instance_1.setTransform(-180,-37);

	this.instance_2 = new lib.Bitmap189();
	this.instance_2.setTransform(-180,-37);

	this.instance_3 = new lib.Bitmap190();
	this.instance_3.setTransform(-180,-37);

	this.instance_4 = new lib.Bitmap191();
	this.instance_4.setTransform(-180,-37);

	this.instance_5 = new lib.Bitmap192();
	this.instance_5.setTransform(-180,-37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-180,-37,360,73);


(lib.bal3p9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap193();
	this.instance.setTransform(-37,-25);

	this.instance_1 = new lib.Bitmap194();
	this.instance_1.setTransform(-37,-25);

	this.instance_2 = new lib.Bitmap195();
	this.instance_2.setTransform(-37,-25);

	this.instance_3 = new lib.Bitmap196();
	this.instance_3.setTransform(-37,-25);

	this.instance_4 = new lib.Bitmap197();
	this.instance_4.setTransform(-37,-25);

	this.instance_5 = new lib.Bitmap198();
	this.instance_5.setTransform(-37,-25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37,-25,73,50);


(lib.bal3p8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap163();
	this.instance.setTransform(-80,-29);

	this.instance_1 = new lib.Bitmap164();
	this.instance_1.setTransform(-80,-29);

	this.instance_2 = new lib.Bitmap165();
	this.instance_2.setTransform(-80,-29);

	this.instance_3 = new lib.Bitmap166();
	this.instance_3.setTransform(-80,-29);

	this.instance_4 = new lib.Bitmap167();
	this.instance_4.setTransform(-80,-29);

	this.instance_5 = new lib.Bitmap168();
	this.instance_5.setTransform(-80,-29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80,-29,162,59);


(lib.bal3p7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap169();
	this.instance.setTransform(-180,-40);

	this.instance_1 = new lib.Bitmap170();
	this.instance_1.setTransform(-180,-40);

	this.instance_2 = new lib.Bitmap171();
	this.instance_2.setTransform(-180,-40);

	this.instance_3 = new lib.Bitmap172();
	this.instance_3.setTransform(-180,-40);

	this.instance_4 = new lib.Bitmap173();
	this.instance_4.setTransform(-180,-40);

	this.instance_5 = new lib.Bitmap174();
	this.instance_5.setTransform(-180,-40);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-180,-40,360,80);


(lib.bal3p6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap139();
	this.instance.setTransform(-35,-27);

	this.instance_1 = new lib.Bitmap140();
	this.instance_1.setTransform(-35,-27);

	this.instance_2 = new lib.Bitmap141();
	this.instance_2.setTransform(-35,-27);

	this.instance_3 = new lib.Bitmap142();
	this.instance_3.setTransform(-35,-27);

	this.instance_4 = new lib.Bitmap143();
	this.instance_4.setTransform(-35,-27);

	this.instance_5 = new lib.Bitmap144();
	this.instance_5.setTransform(-35,-27);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35,-27,70,53);


(lib.bal3p5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap145();
	this.instance.setTransform(-79,-31);

	this.instance_1 = new lib.Bitmap146();
	this.instance_1.setTransform(-79,-31);

	this.instance_2 = new lib.Bitmap147();
	this.instance_2.setTransform(-79,-31);

	this.instance_3 = new lib.Bitmap148();
	this.instance_3.setTransform(-79,-31);

	this.instance_4 = new lib.Bitmap149();
	this.instance_4.setTransform(-79,-31);

	this.instance_5 = new lib.Bitmap150();
	this.instance_5.setTransform(-79,-31);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79,-31,157,62);


(lib.bal3p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap175();
	this.instance.setTransform(-178,-45);

	this.instance_1 = new lib.Bitmap176();
	this.instance_1.setTransform(-178,-45);

	this.instance_2 = new lib.Bitmap177();
	this.instance_2.setTransform(-178,-45);

	this.instance_3 = new lib.Bitmap178();
	this.instance_3.setTransform(-178,-45);

	this.instance_4 = new lib.Bitmap179();
	this.instance_4.setTransform(-178,-45);

	this.instance_5 = new lib.Bitmap180();
	this.instance_5.setTransform(-178,-45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-178,-45,357,89);


(lib.bal3p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap181();
	this.instance.setTransform(-55,-73);

	this.instance_1 = new lib.Bitmap182();
	this.instance_1.setTransform(-55,-73);

	this.instance_2 = new lib.Bitmap183();
	this.instance_2.setTransform(-55,-73);

	this.instance_3 = new lib.Bitmap184();
	this.instance_3.setTransform(-55,-73);

	this.instance_4 = new lib.Bitmap185();
	this.instance_4.setTransform(-55,-73);

	this.instance_5 = new lib.Bitmap186();
	this.instance_5.setTransform(-55,-73);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55,-73,111,146);


(lib.bal3p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap151();
	this.instance.setTransform(-96,-72);

	this.instance_1 = new lib.Bitmap152();
	this.instance_1.setTransform(-96,-72);

	this.instance_2 = new lib.Bitmap153();
	this.instance_2.setTransform(-96,-72);

	this.instance_3 = new lib.Bitmap154();
	this.instance_3.setTransform(-96,-72);

	this.instance_4 = new lib.Bitmap155();
	this.instance_4.setTransform(-96,-72);

	this.instance_5 = new lib.Bitmap156();
	this.instance_5.setTransform(-96,-72);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96,-72,191,144);


(lib.bal3p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"wit":0,"blauw":1,"magenta":2,"geel":3,"zwart":4,"oranje":5});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// Layer_1
	this.instance = new lib.Bitmap157();
	this.instance.setTransform(-165,-66);

	this.instance_1 = new lib.Bitmap158();
	this.instance_1.setTransform(-165,-66);

	this.instance_2 = new lib.Bitmap159();
	this.instance_2.setTransform(-165,-66);

	this.instance_3 = new lib.Bitmap160();
	this.instance_3.setTransform(-165,-66);

	this.instance_4 = new lib.Bitmap161();
	this.instance_4.setTransform(-165,-66);

	this.instance_5 = new lib.Bitmap162();
	this.instance_5.setTransform(-165,-66);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-165,-66,331,132);


(lib.bal_centraal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#06526A").s().p("Am5G6Qi3i3AAkDQAAkCC3i3QC3i3ECAAQEDAAC3C3QC3C3AAECQAAEDi3C3Qi3C3kDAAQkCAAi3i3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bal_centraal, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.aah3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E4CE43").ss(3.9,1,1).p("AuPMmQCbtQHImTQHImTL0Aw");
	this.shape.setTransform(0,-34.2602);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#ECBE2C").ss(3.9,1,1).p("AiKAkQCLg4CKgP");
	this.shape_1.setTransform(45.625,111.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aah3, new cjs.Rectangle(-93.1,-116.8,186.2,233.6), null);


(lib.aah2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E1A635").ss(3.9,1,1).p("AJND4IBNCPALkJiQhNCHjDBfQjDBfk/A6AKeGLQCJBVg8B5AgwPlQnqA7jiA0Am1xTQOqDhBYRj");
	this.shape.setTransform(-0.0007,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aah2, new cjs.Rectangle(-78.4,-112.7,156.9,225.4), null);


(lib.aah1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#ECBE2C").ss(3.9,1,1).p("ApsD9QkgiOA7iqQA8iuGcjAANcD5Qt7FhpKld");
	this.shape.setTransform(-0.0023,0.0315);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aah1, new cjs.Rectangle(-87.9,-44.5,175.8,89.1), null);


(lib.toolbalmovieyellow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleX:0.968,scaleY:0.968},0).wait(1).to({scaleX:0.872,scaleY:0.872},0).wait(1).to({scaleX:0.712,scaleY:0.712},0).wait(1).to({scaleX:0.488,scaleY:0.488},0).wait(1).to({scaleX:0.2,scaleY:0.2},0).wait(1).to({scaleX:0.488,scaleY:0.488},0).wait(1).to({scaleX:0.712,scaleY:0.712},0).wait(1).to({scaleX:0.872,scaleY:0.872},0).wait(1).to({scaleX:0.968,scaleY:0.968},0).wait(1).to({scaleX:1,scaleY:1},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,-62.5,125,125);


(lib.toolbal_movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12));

	// Layer_1
	this.instance = new lib.toolbalsymb();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleX:0.968,scaleY:0.968},0).wait(1).to({scaleX:0.872,scaleY:0.872},0).wait(1).to({scaleX:0.712,scaleY:0.712},0).wait(1).to({scaleX:0.488,scaleY:0.488},0).wait(1).to({scaleX:0.2,scaleY:0.2},0).wait(1).to({scaleX:0.488,scaleY:0.488},0).wait(1).to({scaleX:0.712,scaleY:0.712},0).wait(1).to({scaleX:0.872,scaleY:0.872},0).wait(1).to({scaleX:0.968,scaleY:0.968},0).wait(1).to({scaleX:1,scaleY:1},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,-62.5,125,125);


(lib.symbzorrolintjes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.symbzorro();
	this.instance.setTransform(-0.05,0,0.275,0.275);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AosBaIgHgCQACgIAEgHIgDgBIgEgEIgBgBQAFgSAUgHIAngMQBAgTBFgCQAjgBAggDIBBABQAIAAACAIQgBAIgJABIgVABIgBACQhlAOhoASQguAIgnAVIgDADIgCAAIgBAAIgCAAgAGDBHQgEAAABgEIAUgIIgTgHIgBgCQALgFANgDQgWgFgVgLQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAvgHA4AGQArAEASgTQAAgHgCgGIgFgQQgKgTgWgIQhGAAhDgKQgEAAABgEIAAgBQABgGAFgBIAUgDIgSgLQgDgCAGgCIADgBQAmAHAkAKQAoACAoAEQA1AGgEA1QgCAWgRANQgCAFgFADQgRAdg2AHQgTADgTAAQgXAAgVgEgAIEgvIAAgBIgCAAIACABgAiSg1QB2glB9ABIABAAIAAANQgrACgrAGQg8AHg6ARIgoALg");
	this.shape.setTransform(8.164,-6.6638);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbzorrolintjes, new cjs.Rectangle(-49.8,-31.3,114.6,69), null);


(lib.symbskibriltoolbal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.symbskibril();
	this.instance.setTransform(0,0,0.2947,0.2947);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231C1E").s().p("AH+CNQABgFAFgDIAIgEIgBgDQgEgJAIgIIANgNIAAgBIgBgTIAAgYIAAgMIAAAAQgIgCgCgIIgGgSIAAgDQAAgEgGADQgdAMAEgYQABgGAIgBIAMgCQAJgHAMgDIAIgDQgCgFgFgFIgEgFQgwgDgwAJQgdAGAMgUIADgEIAAgDIADgGQgBgCABgDIgPAAQgRAAgBgOQAAgHAEgCIAAgBQABgIAGgCIg1gHQgDAAgBAFQABgJAKgBIALAAIgggGQgIgBABgHIgvAAQgPAAgJgaQAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAIAuAFIAGgDIAyAGQA9AEBCALQAPACAcAUQAZASADAIIALAMQAFAGABAHQAGANgCABIADANIAAACQACAOAAAPIAAAQQADA9gaAxQgKASgSALQgLAGgGAAQgJAAADgRgAomBpQgVgBgFgUQgQg9ATg4QAGgSARgJQAVgLAXgIQAPgCABAMQACANgOADIgBABQAjgPgBAbQgBAFgFAAQg0AAgNArQgFARgCATQgBAKgKAAQAFAZAHAVQABAFgEAAIgBAAg");
	this.shape.setTransform(1.3547,-12.8003);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibriltoolbal, new cjs.Rectangle(-57.1,-32.7,116.9,65.4), null);


(lib.symbskibrilkleintools = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.symbskibrilklein();
	this.instance.setTransform(0,0.05,0.288,0.288,0,0,0,122.4,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AoHBiQhDgdAjhBQAHgLAPgFQEQhNEdgCQBQAABOgFQCzgQClA+QAsAQgMAtQgNA1g+AJQgaAEgSgPQgXgUAfgJQAmgLAigRQgUgjg4gGQlUgilVAoQhSAKhSAQQhBALg6AbQAYAdgIAdQgCAIgGAAIgGgCg");
	this.shape.setTransform(0.6947,-7.786);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilkleintools, new cjs.Rectangle(-55.7,-21.7,112.9,43.5), null);


(lib.symbskibrilklein12tools = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.symbskibrilklein2();
	this.instance.setTransform(2.85,2.95,0.3123,0.3123,0,0,0,121.9,10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AIGBaQgJgggcgUQg7gphJgWQiwgzjBASQi+ASi5ApQgYAFgXAHQg+ATgXAuQgUApgPgqQgHgUANgQQAogtA5gWQCqg/C6gGQBCgDBBgHQC5gMCiA1QB4AnBBBjQAOAVgVAJQgJAEgGAAQgPAAgFgSg");
	this.shape.setTransform(2.9802,-10.0797);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbskibrilklein12tools, new cjs.Rectangle(-53.6,-20.9,113.2,37), null);


(lib.symbmake = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fbtitelyellow_sm();
	this.instance.setTransform(43.7,0,0.1211,0.1212,0,0,0,1500.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgLAvQgFgFAAgGQAAgIAFgEQAFgFAGAAQAHAAAFAFQAFAEAAAIQAAAGgFAFQgFAFgHAAQgGAAgFgFgAgLgWQgFgFAAgHQAAgHAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAHQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape.setTransform(208.9,1.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AGzCHIAshRIg+htIA0AAIAiBAIAhhAIA0AAIhmC+gAL/A5QgLgMAAgUIAAhQIAtAAIAABHQAAAMAGAGQAGAGALAAQALAAAGgGQAFgGAAgMIAAhHIAtAAIAABQQAAAjghAMQgOAFgUAAQgoAAgRgUgAdKA1QgOgSAAgaQAAgdASgTQASgTAiAAQApAAASAeQAKARAAAVIAAAGIheAAQAAAdAcAAQANAAAIgMIArAAQgFARgKAJQgSARgfAAQgnAAgUgXgAdxgXQgFAFgCAKIAzAAQgFgWgUAAQgMAAgHAHgAYdA1QgPgSAAgaQAAgdASgTQATgTAiAAQApAAASAeQAKARAAAVIAAAGIheAAQAAAdAbAAQAOAAAHgMIAsAAQgFARgKAJQgTARgeAAQgoAAgTgXgAZEgXQgGAFgBAKIAzAAQgFgWgVAAQgLAAgHAHgAUTA1QgRgTAAgbQAAgYASgTQAVgXAnAAQAkAAAVAXQASATAAAZQAAAagSATQgVAXgmAAQgmAAgVgXgAU4gKQgHAIAAAKQAAALAHAIQAIAKAOAAQANAAAIgIQAJgJAAgMQAAgLgJgJQgIgJgNAAQgOAAgIALgAPxA9IAQgfQATAMARAAQAOAAAAgJQAAgFgFgDQgDgCgLgCIgQgFQgOgFgFgLQgDgGAAgIQAAgRAMgMQAOgQAfAAQAVAAAUAIIgPAdQgNgHgLAAQgOAAAAAKQAAAEAGADIAOADQASAEAIAHQALAKAAAQQAAAVgPANQgQAOgeAAQgaAAgYgPgAJdA1QgRgTAAgbQAAgYASgTQAVgXAnAAQAkAAAVAXQASATAAAZQAAAagSATQgVAXgmAAQgmAAgVgXgAKCgKQgHAIAAAKQAAALAHAIQAIAKAOAAQANAAAIgIQAJgJAAgMQAAgLgJgJQgIgJgNAAQgOAAgIALgA35A1QgPgSAAgaQAAgdASgTQATgTAiAAQApAAASAeQAKARAAAVIAAAGIheAAQAAAdAbAAQAOAAAHgMIAsAAQgFARgKAJQgTARgeAAQgoAAgTgXgA3SgXQgGAFgBAKIAzAAQgFgWgVAAQgLAAgHAHgA84A7QgWgTAAggQAAggAWgTQASgQAXAAQAOAAAMAGQAGADAIAIIAAgNIAtAAIAAB+IgtAAIAAgOQgHAIgGAEQgMAGgPAAQgXAAgSgQgA8ZgKQgHAIAAAKQAAAKAHAIQAJALANAAQAMAAAJgJQAIgIAAgMQAAgLgJgJQgIgIgMAAQgNAAgJAKgAfXBHIAAh+IAtAAIAAAVQAHgLAIgFQALgGAPAAIAJAAIAAArQgKgFgJAAQgWAAgHASQgCAGAAALIAAA2gAbbBHIhBh+IAyAAIAfBAIAehAIAyAAIhCB+gAWqBHIAAh+IAtAAIAAAVQAHgLAIgFQALgGAPAAIAJAAIAAArQgJgFgKAAQgWAAgGASQgDAGAAALIAAA2gAS0BHIAAhZIgQAAIAAglIAQAAIAAgQQAAgcAOgQQASgTAYAAQAKAAAKAFIAAAnQgJgFgGAAQgKAAgEAHQgCAEAAAQIAAANIAfAAIAAAlIgfAAIAABZgAOQBHIAAh+IAtAAIAAAVQAHgLAIgFQALgGAPAAIAJAAIAAArQgKgFgJAAQgWAAgHASQgCAGAAALIAAA2gA5IBHIgxgzIAAAzIgtAAIAAjMIAtAAIAAB8IAvguIA9AAIg/A6IBDBEgA+LBHIAAg+QAAgQgDgGQgFgJgKAAQgMAAgGAKQgEAHAAAOIAAA+IgtAAIAAg+QAAgQgDgFQgFgKgLAAQgLAAgGAJQgCADgBAFIgBAOIAAA+IgtAAIAAh+IAtAAIAAAQQAIgIAHgDQALgHAPAAQATAAAMAKQAHAFAFAJQAGgIAGgFQAOgLARAAQAOAAALAHQAMAIAEAMQACAIAAAMIAABRg");
	this.shape_1.setTransform(-5.375,-0.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.symbmake, new cjs.Rectangle(-215.5,-16,426.1,32), null);


(lib.swc_doos3achter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{open:0,toe:1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21).call(this.frame_21).wait(1));

	// flaplinks2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CAAA76").s().p("AEph7ICqgCIqGDgIkfAbg");
	this.shape.setTransform(-29.725,-44.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C1A16D").s().p("ADeh7IFAgCIqGDgIm1Abg");
	this.shape_1.setTransform(-22.225,-44.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C4A470").s().p("Ao2BKIL7j6IFyBPIr0ESg");
	this.shape_2.setTransform(-19.725,-39.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},18).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

	// flapachter
	this.flapachter = new lib.flapachter();
	this.flapachter.name = "flapachter";
	this.flapachter.setTransform(47.45,-60.15);

	this.flapachter_1 = new lib.fa01();
	this.flapachter_1.name = "flapachter_1";
	this.flapachter_1.setTransform(47.45,-59.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E1BF8C").s().p("AmzA0ICfkIILIB9IiPEsg");
	this.shape_3.setTransform(44.1,-61.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DFBF8B").s().p("AmVBZIBjlTILIB+IhTF3g");
	this.shape_4.setTransform(41.1,-65.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DDBB88").s().p("AlvBsIAXl4ILIB9IgHGcg");
	this.shape_5.setTransform(37.35,-67.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DEBE8A").s().p("AlOBdIg7laILIB9IBLF+g");
	this.shape_6.setTransform(34.05,-65.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#DFBF8B").s().p("Ak8BHIhgkuILIB+IBxFRg");
	this.shape_7.setTransform(32.175,-63.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DCBA87").s().p("AkHApIjJjyILIB+IDZEVg");
	this.shape_8.setTransform(26.925,-60.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DDBB88").s().p("Aj0ALIjvi2ILIB+ID/DZg");
	this.shape_9.setTransform(25.05,-57.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E2C28E").s().p("AjpgaIkFhrILIB9IEVCOg");
	this.shape_10.setTransform(23.925,-53.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C7A773").s().p("AE2BSIspisIEIAQILeClg");
	this.shape_11.setTransform(23.7,-49.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C1A16D").s().p("AoYhHIFSgdILfClIkIAkg");
	this.shape_12.setTransform(19.95,-46.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BE9C69").s().p("AohgNIFlh5ILeClIkeBog");
	this.shape_13.setTransform(19.025,-43.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.flapachter}]}).to({state:[{t:this.flapachter_1}]},2).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).wait(9));

	// flaplinks
	this.flaplinks = new lib.flaplinks2();
	this.flaplinks.name = "flaplinks";
	this.flaplinks.setTransform(-52.6,-57.65);

	this.flaplinks_1 = new lib.fl01();
	this.flaplinks_1.name = "flaplinks_1";
	this.flaplinks_1.setTransform(-52.4,-57.65);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CFAD7A").s().p("AnrhWIMCjAIDVE2IsDD3g");
	this.shape_14.setTransform(-48.425,-60.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#C0A06C").s().p("AnShvIMCjAICjFoIsDD3g");
	this.shape_15.setTransform(-45.925,-62.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#C9A774").s().p("Amvh+IMCjAIBdGGIsDD3g");
	this.shape_16.setTransform(-42.425,-64.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BF9F6B").s().p("AmCiSIMCjAIADGuIsDD3g");
	this.shape_17.setTransform(-37.925,-66.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#C4A470").s().p("AleiIIMCjAIhEGaIsDD3g");
	this.shape_18.setTransform(-34.475,-65.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#C8A874").s().p("Ak7hvIMCjAIiKFoIsDD3g");
	this.shape_19.setTransform(-30.975,-62.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#C8A874").s().p("AkThRIMCjAIjaEsIsDD3g");
	this.shape_20.setTransform(-26.975,-59.675);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#C8A673").s().p("Aj1gpIMCjAIkWDdIsDD2g");
	this.shape_21.setTransform(-23.975,-55.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#C19F6C").s().p("AjhgGIMCjAIk+CXIsDD2g");
	this.shape_22.setTransform(-21.975,-52.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.flaplinks}]}).to({state:[{t:this.flaplinks_1}]},8).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[]},1).wait(4));

	// Layer_1
	this.doosbinnen = new lib.doosbinnen();
	this.doosbinnen.name = "doosbinnen";
	this.doosbinnen.setTransform(-1.75,-34.1);

	this.timeline.addTween(cjs.Tween.get(this.doosbinnen).wait(22));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.6,-100,200.1,89.9);


(lib.riemmetachter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.riemvoor();
	this.instance.setTransform(0,24.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.riemachter();
	this.instance_1.setTransform(0.7,-44.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riemmetachter, new cjs.Rectangle(-182,-88.1,362,184.2), null);


(lib.riembreedmetachter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.riembreedvoor();
	this.instance.setTransform(0,24.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.riembreedachter();
	this.instance_1.setTransform(-0.8,-64.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riembreedmetachter, new cjs.Rectangle(-182,-109.1,362,236.2), null);


(lib.riem13tool = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.riem13bovenn();
	this.instance.setTransform(0,0,0.2796,0.2796);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhcHEQgagJgCggIgFg5QgRirAlijIAThTQgCiBgSh9QgLhQAwg3QAfgjAtgFIA/AAIAAgCQAAgDAEAAIAFAHIADADIABACIAAACIABADIAAACQAMAYAGAcIACABQAiDXgJDdQgIDfgfDaQgEAXgIAUIgGABIgCAAIAAACQhRgRhRgdgAhaBgQgaCrAfClQAhAIAhAKQgPgUgIggIgNg6QgdiFgCiJIgEAag");
	this.shape.setTransform(11.8147,0.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem13tool, new cjs.Rectangle(-19.8,-53.1,44.8,106.2), null);


(lib.riem11toolb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.riemball11();
	this.instance.setTransform(-0.05,0,0.3074,0.3074,0,0,0,-8.6,38.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AFoBbQhlgYhoAHQkiASkhgRQgUgBgQgKQgRgKgJgRQgSgkAJgZIgEABQgHAAAEgHQATgmA5gKQCbgYCeALQDWAADVAIQBJADBKAQQAzAMgJAiQAAAEgEABQAEAQgHATQgIAYgRASQgdAggsAAQgSAAgUgFg");
	this.shape.setTransform(-0.1164,-21.8006);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.riem11toolb, new cjs.Rectangle(-54.3,-31.3,108.3,58.2), null);


(lib.mutsrechtsgras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.mutsrandgras();
	this.instance.setTransform(2.4,18.2,1,1.0485,0,0,0,2.1,18.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#333333"],[0,0.173,0.741,0.898],-10.6,-7.7,0,-10.6,-7.7,21).s().p("AhejAQAkABAgAMQAlAQAcAbQA4A5ABBPIgBAKIgFAjQgMA0gnAoQg2A3hPABg");
	this.shape.setTransform(14.3,18.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsrechtsgras, new cjs.Rectangle(4.3,-1.3,19.599999999999998,39.5), null);


(lib.mutsrechts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.mutsrand13();
	this.instance.setTransform(3.2,18.2,1,1.0272,0,0,0,2.1,18.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#333333"],[0,0.173,0.741,0.898],-7.9,-7.2,0,-7.9,-7.2,20.1).s().p("AhTCUIgHgSQgIgWgHgiQgGgeAAgIQAAhHAEgfQAGg4AZg7QAAAAAAAAQAAAAABgBQAAAAABAAQAAAAABAAIABAAIAFABQAlAAAgANQAiAOAZAaQAzA2AABKQAAAWgEAVQgLAxgkAlQgzA2hJAAg");
	this.shape.setTransform(11.425,18.1625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutsrechts, new cjs.Rectangle(-0.9,-0.7,23.599999999999998,37.900000000000006), null);


(lib.mutslinksgras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.mutsrandgras();
	this.instance.setTransform(14.3,18.1,1,1,0,0,0,2.1,18.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#333333"],[0,0.173,0.741,0.898],2.7,-7.5,0,2.7,-7.5,21.4).s().p("AAbCsQgegMghgbQg4gtAAhYIAAgBQABhPA3g1QAZgYAfgLQAVgIA0gJIgBFzQgqgFgXgJg");
	this.shape.setTransform(7.775,18.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutslinksgras, new cjs.Rectangle(-1.5,-0.5,19.2,37.7), null);


(lib.mutslinks13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.mutsrand13();
	this.instance.setTransform(14.6,18.1,1,1,0,0,0,2.1,18.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#333333"],[0,0.173,0.741,0.898],2.9,-7.2,0,2.9,-7.2,20.2).s().p("AAZCiQgXgKgfgZQg3gqAAhVIAAgBQABhPA2gvQAagWAZgMQAVgJAigHQgZA8gFAdQgGAbgCBVQgCA0AMAlQAKAgAaAhQgkgFgYgLg");
	this.shape.setTransform(7.575,18.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutslinks13, new cjs.Rectangle(-0.9,-0.3,17.9,36.9), null);


(lib.mutslinks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.mutsrand();
	this.instance.setTransform(14.3,18.1,1,1,0,0,0,2.1,18.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","#999999","#333333","#333333"],[0,0.173,0.741,0.898],3.2,-7.2,0,3.2,-7.2,20.2).s().p("AAXCjQgYgLgbgZQg1gwAAhPIAAgBQABhPA0gvQAZgWAYgMQAUgJAigHQgZA8gFAdQgFAbgCBVQgCA0AMAlQAJAgAZAhQgkgFgXgKg");
	this.shape.setTransform(7.3,18.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutslinks, new cjs.Rectangle(-0.9,-0.2,17.299999999999997,36.800000000000004), null);


(lib.levelnbrmoviegrey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snbr5grey();
	this.instance.setTransform(14.05,0.9);

	this.instance_1 = new lib.snbr2grey();
	this.instance_1.setTransform(-13.7,0.5);

	this.instance_2 = new lib.snbr4grey();
	this.instance_2.setTransform(14.65,1.05);

	this.instance_3 = new lib.snbr3grey();
	this.instance_3.setTransform(14.75,0.9);

	this.instance_4 = new lib.snbr2grey();
	this.instance_4.setTransform(-14.35,1.05);

	this.instance_5 = new lib.snbr1grey();
	this.instance_5.setTransform(13.8,1.05);

	this.instance_6 = new lib.snbr0grey();
	this.instance_6.setTransform(14.05,0.9);

	this.instance_7 = new lib.snbr9grey();
	this.instance_7.setTransform(13.95,0.8);

	this.instance_8 = new lib.snbr8grey();
	this.instance_8.setTransform(13.7,0.9);

	this.instance_9 = new lib.snbr7grey();
	this.instance_9.setTransform(15.55,1.05);

	this.instance_10 = new lib.snbr6grey();
	this.instance_10.setTransform(14.1,1.45);

	this.instance_11 = new lib.snbr1grey();
	this.instance_11.setTransform(-14.35,1.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{x:-13.7,y:0.5}},{t:this.instance,p:{x:14.05,y:0.9}}]}).to({state:[]},1).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance,p:{x:14.95,y:1.45}}]},18).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance_2,p:{x:14.65}}]},1).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance_3,p:{x:14.75}}]},1).to({state:[{t:this.instance_4},{t:this.instance_1,p:{x:14.45,y:0.5}}]},1).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance_5,p:{x:13.8}}]},1).to({state:[{t:this.instance_1,p:{x:-13.7,y:0.5}},{t:this.instance_6,p:{x:14.05}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_7,p:{x:13.95}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_8,p:{x:13.7}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_9,p:{x:15.55}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_10,p:{x:14.1}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance,p:{x:14.95,y:1.45}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_2,p:{x:14.65}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_3,p:{x:14.75}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_1,p:{x:14.45,y:0.5}}]},1).to({state:[{t:this.instance_11},{t:this.instance_5,p:{x:13.8}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_6,p:{x:14.05}}]},1).to({state:[{t:this.instance_7,p:{x:-0.15}}]},1).to({state:[{t:this.instance_8,p:{x:-0.4}}]},1).to({state:[{t:this.instance_9,p:{x:1.45}}]},1).to({state:[{t:this.instance_10,p:{x:0}}]},1).to({state:[{t:this.instance,p:{x:0.85,y:1.45}}]},1).to({state:[{t:this.instance_2,p:{x:0.55}}]},1).to({state:[{t:this.instance_3,p:{x:0.65}}]},1).to({state:[{t:this.instance_1,p:{x:0.35,y:0.5}}]},1).to({state:[{t:this.instance_5,p:{x:-0.25}}]},1).to({state:[{t:this.instance_6,p:{x:0.45}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.8,-18.2,56.1,38.3);


(lib.levelnbrmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.snbr5();
	this.instance.setTransform(14.05,0.9);

	this.instance_1 = new lib.snbr2();
	this.instance_1.setTransform(-13.7,0.5);

	this.instance_2 = new lib.snbr4();
	this.instance_2.setTransform(14.65,1.05);

	this.instance_3 = new lib.snbr3();
	this.instance_3.setTransform(14.75,0.9);

	this.instance_4 = new lib.snbr2();
	this.instance_4.setTransform(-14.35,1.05);

	this.instance_5 = new lib.snbr1();
	this.instance_5.setTransform(13.8,1.05);

	this.instance_6 = new lib.snbr0();
	this.instance_6.setTransform(14.05,0.9);

	this.instance_7 = new lib.snbr9();
	this.instance_7.setTransform(13.95,0.8);

	this.instance_8 = new lib.snbr8();
	this.instance_8.setTransform(13.7,0.9);

	this.instance_9 = new lib.snbr7();
	this.instance_9.setTransform(15.55,1.05);

	this.instance_10 = new lib.snbr6();
	this.instance_10.setTransform(14.1,1.45);

	this.instance_11 = new lib.snbr1();
	this.instance_11.setTransform(-14.35,1.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{x:-13.7,y:0.5}},{t:this.instance,p:{x:14.05,y:0.9}}]}).to({state:[]},1).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance,p:{x:14.95,y:1.45}}]},18).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance_2,p:{x:14.65}}]},1).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance_3,p:{x:14.75}}]},1).to({state:[{t:this.instance_4},{t:this.instance_1,p:{x:14.45,y:0.5}}]},1).to({state:[{t:this.instance_1,p:{x:-14.35,y:1.05}},{t:this.instance_5,p:{x:13.8}}]},1).to({state:[{t:this.instance_1,p:{x:-13.7,y:0.5}},{t:this.instance_6,p:{x:14.05}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_7,p:{x:13.95}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_8,p:{x:13.7}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_9,p:{x:15.55}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_10,p:{x:14.1}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance,p:{x:14.95,y:1.45}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_2,p:{x:14.65}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_3,p:{x:14.75}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_1,p:{x:14.45,y:0.5}}]},1).to({state:[{t:this.instance_11},{t:this.instance_5,p:{x:13.8}}]},1).to({state:[{t:this.instance_5,p:{x:-14.35}},{t:this.instance_6,p:{x:14.05}}]},1).to({state:[{t:this.instance_7,p:{x:-0.15}}]},1).to({state:[{t:this.instance_8,p:{x:-0.4}}]},1).to({state:[{t:this.instance_9,p:{x:1.45}}]},1).to({state:[{t:this.instance_10,p:{x:0}}]},1).to({state:[{t:this.instance,p:{x:0.85,y:1.45}}]},1).to({state:[{t:this.instance_2,p:{x:0.55}}]},1).to({state:[{t:this.instance_3,p:{x:0.65}}]},1).to({state:[{t:this.instance_1,p:{x:0.35,y:0.5}}]},1).to({state:[{t:this.instance_5,p:{x:-0.25}}]},1).to({state:[{t:this.instance_6,p:{x:0.45}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.8,-18.2,56.1,38.3);


(lib.kruisjesymbool2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.playtxt = new lib.ppijlplay();
	this.playtxt.name = "playtxt";
	this.playtxt.setTransform(-15,0);

	this.timeline.addTween(cjs.Tween.get(this.playtxt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.kruisjesymbool2, new cjs.Rectangle(-35,-22.7,40,45.5), null);


(lib.helmsymb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.aah3();
	this.instance.setTransform(135.15,111.35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.instance_1 = new lib.aah2();
	this.instance_1.setTransform(271.6,108.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_3
	this.instance_2 = new lib.aah1();
	this.instance_2.setTransform(80.25,201.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer_2
	this.instance_3 = new lib.helm1pngcopy();
	this.instance_3.setTransform(-8.65,-4.15,1.1967,1.1967);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helmsymb, new cjs.Rectangle(-8.6,-5.4,358.70000000000005,251.4), null);


(lib.graszaad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Bitmap886();
	this.instance.setTransform(-19,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.zaadzak();
	this.instance_1.setTransform(0.15,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graszaad, new cjs.Rectangle(-36.8,-50.7,75,99), null);


(lib.fblevel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.leveltxt = new lib.levelnbrmoviegrey();
	this.leveltxt.name = "leveltxt";
	this.leveltxt.setTransform(0.6,1.1,1,1,0,0,0,0.6,1.1);

	this.timeline.addTween(cjs.Tween.get(this.leveltxt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fblevel, new cjs.Rectangle(-27.2,-18.2,52.8,37.8), null);


(lib.buttonsound = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.ontxt = new lib.symbstreep();
	this.ontxt.name = "ontxt";
	this.ontxt.setTransform(-20,-38.5,0.2778,0.2778);
	this.ontxt.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 255, 0, 0)];
	this.ontxt.cache(-43,-44,86,89);

	this.offtxt = new lib.symbstreep();
	this.offtxt.name = "offtxt";
	this.offtxt.setTransform(0,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.offtxt},{t:this.ontxt}]}).wait(1));

	// Layer_4
	this.soundtxt = new lib.symbsound();
	this.soundtxt.name = "soundtxt";
	this.soundtxt.setTransform(-7.2,0.95);

	this.timeline.addTween(cjs.Tween.get(this.soundtxt).wait(1));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonsound, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonquit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.kruis = new lib.kruisjesymbool2();
	this.kruis.name = "kruis";
	this.kruis.setTransform(-21.8,0,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.kruis).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbalmovieyellow();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonquit, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonnextemo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhIDkQgHgCgFgFQgEgGgBgHIAAhcIi+BtQgGAEgHgBQgHgCgEgFQgGgGAAgHIAAmfQAAgHAFgFQAEgGAIgBQAGgCAHAEIC+BuIAAhdQAAgHAFgFQAFgGAGgBQAIgCAGAEIFnDQQAHADACAHQACAGgCAHQgCAGgHAEIlmDQQgGADgFAAIgDAAg");
	this.shape.setTransform(4.4,0.0407);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbalmovieyellowemo();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonnextemo, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonnewplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.playtxt = new lib.ppijlplay();
	this.playtxt.name = "playtxt";
	this.playtxt.setTransform(5,0);

	this.timeline.addTween(cjs.Tween.get(this.playtxt).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbalmovieyellow();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonnewplay, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonmusic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.ontxt = new lib.symbstreep();
	this.ontxt.name = "ontxt";
	this.ontxt.setTransform(-40,-19.5,0.2778,0.2778);
	this.ontxt.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 255, 0, 0)];
	this.ontxt.cache(-43,-44,86,89);

	this.offtxt = new lib.symbstreep();
	this.offtxt.name = "offtxt";
	this.offtxt.setTransform(0,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.offtxt},{t:this.ontxt}]}).wait(1));

	// Layer_4
	this.musictxt = new lib.symbmuz();
	this.musictxt.name = "musictxt";
	this.musictxt.setTransform(-4,0);

	this.timeline.addTween(cjs.Tween.get(this.musictxt).wait(1));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonmusic, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonlinktwitter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.kruis = new lib.simlinktw();
	this.kruis.name = "kruis";
	this.kruis.setTransform(3.5,3);

	this.timeline.addTween(cjs.Tween.get(this.kruis).wait(1));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonlinktwitter, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonlinkhome = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.kruis = new lib.symbinsta();
	this.kruis.name = "kruis";
	this.kruis.setTransform(0,-0.05,1.1667,1.1662);

	this.timeline.addTween(cjs.Tween.get(this.kruis).wait(1));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonlinkhome, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonlinkfacebook = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.kruis = new lib.simlinkface();
	this.kruis.name = "kruis";
	this.kruis.setTransform(0.9,1.35);

	this.timeline.addTween(cjs.Tween.get(this.kruis).wait(1));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonlinkfacebook, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonlang = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.langtxt = new lib.symbglobe();
	this.langtxt.name = "langtxt";

	this.timeline.addTween(cjs.Tween.get(this.langtxt).wait(1));

	// Layer_1
	this.instance = new lib.toolbalsymbyellow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonlang, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttoncontinue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.leveltxt = new lib.levelnbrmovie();
	this.leveltxt.name = "leveltxt";
	this.leveltxt.setTransform(-1.6,0.1);

	this.timeline.addTween(cjs.Tween.get(this.leveltxt).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbalmovieyellow();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttoncontinue, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.bloemwitzaad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bloem();
	this.instance.setTransform(0.6,3.5,0.2552,0.2552,0,0,0,19.6,18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Bitmap896();
	this.instance_1.setTransform(-20,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_1
	this.instance_2 = new lib.zaadzak();
	this.instance_2.setTransform(0.15,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bloemwitzaad, new cjs.Rectangle(-36.8,-50.7,75,99), null);


(lib.bloemwit4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{bloem1:0,bloem2:1,bloem3:2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AGfITQgCgFgBgOQAAgnAmAAQAmAAgBAmQAAAPgMALQgLAKgOAAQgcAAgHgQgAnkiAQgCgFgBgOQAAgnAmAAQAmAAgBAmQAAAPgMALQgLAKgOAAQgcAAgHgQgABLnoQgDgFAAgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgMAKgNAAQgbAAgIgQg");
	this.shape.setTransform(-74,-63.975);

	this.instance = new lib.bloem();
	this.instance.setTransform(-121.95,-78.95,0.3324,0.3207,0,-163.2945,-148.0852,19.7,17.9);

	this.instance_1 = new lib.bloem();
	this.instance_1.setTransform(-29.05,-14,0.3862,0.3717,0,-110.7788,-126.543,19.3,17.9);

	this.instance_2 = new lib.bloem();
	this.instance_2.setTransform(-61.95,-118.1,0.3967,0.3967,0,0,0,19.6,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{regX:19.6,scaleX:0.3967,scaleY:0.3967,x:-61.95}},{t:this.instance_1,p:{regX:19.3,scaleX:0.3862,scaleY:0.3717,skewY:-126.543,x:-29.05,y:-14}},{t:this.instance,p:{scaleX:0.3324,scaleY:0.3207,skewX:-163.2945,skewY:-148.0852}}]},1).to({state:[{t:this.instance_2,p:{regX:19.5,scaleX:0.6752,scaleY:0.6752,x:-62.05}},{t:this.instance_1,p:{regX:19.4,scaleX:0.6645,scaleY:0.6395,skewY:-126.5441,x:-29.1,y:-14.05}},{t:this.instance,p:{scaleX:0.5821,scaleY:0.5618,skewX:-163.2957,skewY:-148.085}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157.7,-157.9,184.5,185.70000000000002);


(lib.bloemwit3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("An4H1QgDgFABgOQAAgnAlAAQAlAAAAAmQAAAQgMAKQgMAKgNAAQgcAAgHgQgAmyioQgCgFAAgOQgBgnAmAAQAmAAAAAmQAAAPgNALQgMAKgNAAQgbAAgIgQgAG0nKQgEgFAAgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgLAKgOAAQgbAAgHgQg");
	this.shape.setTransform(-3,-33.975);

	this.instance = new lib.bloem();
	this.instance.setTransform(44.15,-83.8,0.2895,0.2794,0,64.2354,79.448,19.4,17.8);

	this.instance_1 = new lib.bloem();
	this.instance_1.setTransform(-48.1,15.95,0.3646,0.3509,0,-169.9401,174.2937,19.4,17.9);

	this.instance_2 = new lib.bloem();
	this.instance_2.setTransform(-42.45,-57.1,0.3313,0.3313,0,0,0,19.4,17.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{regX:19.4,regY:17.9,scaleX:0.3313,scaleY:0.3313}},{t:this.instance_1,p:{regY:17.9,scaleX:0.3646,scaleY:0.3509,skewX:-169.9401,skewY:174.2937,y:15.95}},{t:this.instance,p:{regX:19.4,regY:17.8,scaleX:0.2895,scaleY:0.2794,skewX:64.2354,skewY:79.448,y:-83.8}}]},1).to({state:[{t:this.instance_2,p:{regX:19.5,regY:18,scaleX:0.6752,scaleY:0.6752}},{t:this.instance_1,p:{regY:18,scaleX:0.6645,scaleY:0.6395,skewX:-169.9394,skewY:174.2936,y:15.9}},{t:this.instance,p:{regX:19.6,regY:17.9,scaleX:0.5822,scaleY:0.5617,skewX:64.2361,skewY:79.4476,y:-83.7}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.1,-128.7,169.8,185.29999999999998);


(lib.bloemwit2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AgJIYQgCgFAAgOQAAgnAkAAQAlAAAAAmQAAAPgMALQgMAKgNAAQgbAAgHgQgAFejpQgCgFAAgOQAAgnAlAAQAmAAAAAmQgBAPgMALQgMAKgNAAQgcAAgHgQgAmjntQgCgFgBgOQAAgnAmAAQAmAAgBAmQAAAPgMALQgLAKgOAAQgcAAgHgQg");
	this.shape.setTransform(-26.5,-41.475);

	this.instance = new lib.bloem();
	this.instance.setTransform(11.1,-67,0.3676,0.3547,0,18.2533,33.4612,19.6,17.9);

	this.instance_1 = new lib.bloem();
	this.instance_1.setTransform(-66.05,-92.05,0.3981,0.3831,0,61.7499,45.9845,19.3,18.1);

	this.instance_2 = new lib.bloem();
	this.instance_2.setTransform(-24.05,10.9,0.3652,0.3652,0,0,0,19.4,17.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{regX:19.4,regY:17.9,scaleX:0.3652,scaleY:0.3652}},{t:this.instance_1,p:{regX:19.3,regY:18.1,scaleX:0.3981,scaleY:0.3831,skewX:61.7499,skewY:45.9845,y:-92.05}},{t:this.instance,p:{regY:17.9,scaleX:0.3676,scaleY:0.3547,skewY:33.4612,y:-67}}]},1).to({state:[{t:this.instance_2,p:{regX:19.5,regY:18,scaleX:0.6752,scaleY:0.6752}},{t:this.instance_1,p:{regX:19.4,regY:18,scaleX:0.6645,scaleY:0.6395,skewX:61.7491,skewY:45.9834,y:-92.1}},{t:this.instance,p:{regY:18,scaleX:0.5822,scaleY:0.5617,skewY:33.4631,y:-66.95}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-123.3,-135.4,170.7,185.5);


(lib.bloemwit1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AGuJAQgDgFAAgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgMAKgNAAQgbAAgIgQgAnzFaQgCgFgBgOQAAgnAmAAQAmAAgBAmQAAAPgMALQgLAKgOAAQgcAAgHgQgAGkoVQgDgFAAgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgMAKgNAAQgbAAgIgQg");
	this.shape.setTransform(-54.5,-58.475);

	this.instance = new lib.bloem();
	this.instance.setTransform(-101.9,-24.95,0.31,0.2991,0,-132.3038,-117.0923,19.6,17.9);

	this.instance_1 = new lib.bloem();
	this.instance_1.setTransform(-11.05,-115.15,0.376,0.3618,0,0,-15.7656,19.5,17.9);

	this.instance_2 = new lib.bloem();
	this.instance_2.setTransform(-9.05,-3.15,0.3643,0.3643,0,0,0,19.5,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{scaleX:0.3643,scaleY:0.3643,y:-3.15}},{t:this.instance_1,p:{regX:19.5,regY:17.9,scaleX:0.376,scaleY:0.3618,skewY:-15.7656,x:-11.05,y:-115.15}},{t:this.instance,p:{scaleX:0.31,scaleY:0.2991,skewX:-132.3038,skewY:-117.0923,y:-24.95}}]},1).to({state:[{t:this.instance_2,p:{scaleX:0.6752,scaleY:0.6752,y:-3.1}},{t:this.instance_1,p:{regX:19.4,regY:18,scaleX:0.6645,scaleY:0.6395,skewY:-15.7654,x:-11.1,y:-115.1}},{t:this.instance,p:{scaleX:0.5822,scaleY:0.5618,skewX:-132.3039,skewY:-117.0936,y:-24.9}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140.5,-162.5,167.6,198.6);


(lib.bloemblauwzaad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bloemblauw();
	this.instance.setTransform(0.6,3.5,0.2552,0.2552,0,0,0,19.6,18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Bitmap899();
	this.instance_1.setTransform(-20,-17);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_1
	this.instance_2 = new lib.zaadzak();
	this.instance_2.setTransform(0.15,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bloemblauwzaad, new cjs.Rectangle(-36.8,-50.7,75,99), null);


(lib.bloemblauw4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AAKFkQgDgFAAgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgMAKgNAAQgbAAgIgQgAJsjfQgCgFgBgOQAAgnAmAAQAmAAgBAmQAAAPgMALQgLAKgOAAQgcAAgHgQgAqxk5QgCgFAAgOQgBgnAmAAQAmAAAAAmQAAAPgNALQgMAKgNAAQgbAAgIgQg");
	this.shape.setTransform(-67.5,-87.475);

	this.instance = new lib.bloemblauw();
	this.instance.setTransform(-135.7,-122.5,0.3343,0.3226,0,-163.2948,-148.0844,19.6,17.9);

	this.instance_1 = new lib.bloemblauw();
	this.instance_1.setTransform(-68.05,-54.1,0.3243,0.3121,0,-110.7777,-126.5437,19.4,18);

	this.instance_2 = new lib.bloemblauw();
	this.instance_2.setTransform(-1.05,-111.1,0.3946,0.3946,0,0,0,19.5,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{scaleX:0.3946,scaleY:0.3946}},{t:this.instance_1,p:{regY:18,scaleX:0.3243,scaleY:0.3121,skewX:-110.7777,skewY:-126.5437,x:-68.05,y:-54.1}},{t:this.instance,p:{regX:19.6,scaleX:0.3343,scaleY:0.3226,skewX:-163.2948,skewY:-148.0844,x:-135.7,y:-122.5}}]},1).to({state:[{t:this.instance_2,p:{scaleX:0.6752,scaleY:0.6752}},{t:this.instance_1,p:{regY:17.9,scaleX:0.6645,scaleY:0.6395,skewX:-110.7788,skewY:-126.5441,x:-68.1,y:-54.05}},{t:this.instance,p:{regX:19.7,scaleX:0.5821,scaleY:0.5618,skewX:-163.2957,skewY:-148.085,x:-135.75,y:-122.55}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.5,-170.2,206.6,158);


(lib.bloemblauw3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("Ao5F4QgCgFAAgOQAAgnAlAAQAlAAAAAmQAAAPgMALQgMAKgNAAQgcAAgHgQgAH1FkQgDgFAAgOQgBgnAmAAQAmAAAAAmQgBAPgLALQgMAKgOAAQgbAAgHgQgAC+lNQgCgFgBgOQAAgnAmAAQAmAAgBAmQAAAPgMALQgLAKgOAAQgcAAgHgQg");
	this.shape.setTransform(-24.5,-54.475);

	this.instance = new lib.bloemblauw();
	this.instance.setTransform(28.1,-21.65,0.3322,0.3205,0,91.4812,106.6902,19.7,17.9);

	this.instance_1 = new lib.bloemblauw();
	this.instance_1.setTransform(-79.05,-18.1,0.3641,0.3393,0,-179.3455,174.2925,19.4,18);

	this.instance_2 = new lib.bloemblauw();
	this.instance_2.setTransform(-2.45,-91.9,0.3581,0.3581,0,0,0,19.4,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{regX:19.4,scaleX:0.3581,scaleY:0.3581}},{t:this.instance_1,p:{regX:19.4,regY:18,scaleX:0.3641,scaleY:0.3393,skewX:-179.3455,skewY:174.2925,x:-79.05,y:-18.1}},{t:this.instance,p:{scaleX:0.3322,scaleY:0.3205,skewX:91.4812,skewY:106.6902,y:-21.65}}]},1).to({state:[{t:this.instance_2,p:{regX:19.5,scaleX:0.6752,scaleY:0.6752}},{t:this.instance_1,p:{regX:19.3,regY:17.9,scaleX:0.6645,scaleY:0.6192,skewX:-179.3449,skewY:174.2936,x:-78.95,y:-18.05}},{t:this.instance,p:{scaleX:0.5822,scaleY:0.5618,skewX:91.4802,skewY:106.6913,y:-21.6}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.9,-131.7,185.10000000000002,153.7);


(lib.bloemblauw2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("ApSLRQgCgFgBgOQAAgnAmAAQAlAAAAAmQAAAQgMAKQgLAKgOAAQgcAAgHgQgAIOFzQgDgFgBgOQAAgnAmAAQAmAAAAAmQgBAPgMALQgLAKgOAAQgbAAgHgQgAhAqmQgDgFABgOQAAgnAlAAQAkAAAAAmQAAAPgLALQgMAKgNAAQgcAAgHgQg");
	this.shape.setTransform(-28,-52.975);

	this.instance = new lib.bloemblauw();
	this.instance.setTransform(24.1,-18.85,0.3363,0.3245,0,18.2543,33.463,19.6,18.1);

	this.instance_1 = new lib.bloemblauw();
	this.instance_1.setTransform(-30.45,-124.1,0.3203,0.3082,0,61.7502,45.9825,19.3,17.9);

	this.instance_2 = new lib.bloemblauw();
	this.instance_2.setTransform(-81.05,16.9,0.3574,0.3574,0,0,0,19.4,18.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{regX:19.4,regY:18.1,scaleX:0.3574,scaleY:0.3574}},{t:this.instance_1,p:{regX:19.3,regY:17.9,scaleX:0.3203,scaleY:0.3082,skewX:61.7502,skewY:45.9825,x:-30.45}},{t:this.instance,p:{regY:18.1,scaleX:0.3363,scaleY:0.3245,skewX:18.2543,skewY:33.463,y:-18.85}}]},1).to({state:[{t:this.instance_2,p:{regX:19.5,regY:18,scaleX:0.6752,scaleY:0.6752}},{t:this.instance_1,p:{regX:19.4,regY:18,scaleX:0.6645,scaleY:0.6395,skewX:61.7491,skewY:45.9834,x:-30.5}},{t:this.instance,p:{regY:18,scaleX:0.5822,scaleY:0.5617,skewX:18.2533,skewY:33.4631,y:-18.95}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117.1,-167.4,177.5,223.5);


(lib.bloemblauw1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"bloem1":0,"bloem2":1,"bloem3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#660000").s().p("AkhFzQgCgFgBgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgLAKgOAAQgbAAgIgQgAGvDdQgEgFAAgOQAAgnAmAAQAmAAAAAmQAAAPgNALQgLAKgOAAQgbAAgHgQgAnzlIQgDgFABgOQAAgnAlAAQAlAAAAAmQAAAPgMALQgMAKgNAAQgcAAgHgQg");
	this.shape.setTransform(-29.5,-70.975);

	this.instance = new lib.bloemblauw();
	this.instance.setTransform(-78.85,-105.65,0.3464,0.3343,0,-103.8631,-88.6547,19.5,18);

	this.instance_1 = new lib.bloemblauw();
	this.instance_1.setTransform(-56.75,-35.75,0.3606,0.3471,0,-16.4814,-32.2477,19.7,18.2);

	this.instance_2 = new lib.bloemblauw();
	this.instance_2.setTransform(16.95,-53.15,0.3953,0.3953,0,0,0,19.5,17.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2,p:{regY:17.9,scaleX:0.3953,scaleY:0.3953,y:-53.15}},{t:this.instance_1,p:{regX:19.7,regY:18.2,scaleX:0.3606,scaleY:0.3471,skewX:-16.4814,skewY:-32.2477,y:-35.75}},{t:this.instance,p:{regX:19.5,regY:18,scaleX:0.3464,scaleY:0.3343,skewX:-103.8631,skewY:-88.6547,x:-78.85,y:-105.65}}]},1).to({state:[{t:this.instance_2,p:{regY:18,scaleX:0.6752,scaleY:0.6752,y:-53.1}},{t:this.instance_1,p:{regX:19.6,regY:18.1,scaleX:0.6645,scaleY:0.6395,skewX:-16.4813,skewY:-32.2471,y:-35.7}},{t:this.instance,p:{regX:19.7,regY:17.9,scaleX:0.5822,scaleY:0.5617,skewX:-103.8649,skewY:-88.6543,x:-78.95,y:-105.75}}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.7,-144.6,164.8,163.4);


(lib.arrowsymb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.playtxt = new lib.ppijlplay();
	this.playtxt.name = "playtxt";
	this.playtxt.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get(this.playtxt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowsymb, new cjs.Rectangle(-21,-22.7,40,45.5), null);


(lib.mutslinksmetachter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mutslinks();
	this.instance.setTransform(0.15,-0.1,2.8708,2.8708,0,0,0,7.8,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AAzIGIAAggIg4AAQgGgSgFgWIhwAAIAAsdIBbAAIABgIQAZidAmgBQAngBAeCcQAdCdAEDdQADDegaCeQgNBTgRAng");
	this.shape.setTransform(17.3158,-0.3251);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mutslinksmetachter, new cjs.Rectangle(-24.8,-52.7,55.1,105.6), null);


(lib.levelbal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_7 = function() {
		this.stop();
	}
	this.frame_8 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1).call(this.frame_8).wait(1));

	// spin
	this.helm = new lib.helmsymb();
	this.helm.name = "helm";
	this.helm.setTransform(-28.85,-77.1,1.3006,1.3006,0,0,0,173.1,121);

	this.b3helm = new lib.helmsymb();
	this.b3helm.name = "b3helm";
	this.b3helm.setTransform(-28.85,-66.6,1.3006,1.3006,0,0,0,173.1,121);

	this.b4phonelinks = new lib.headphonemovie();
	this.b4phonelinks.name = "b4phonelinks";
	this.b4phonelinks.setTransform(-62.7,-85.15);

	this.b6helm = new lib.helmsymb();
	this.b6helm.name = "b6helm";
	this.b6helm.setTransform(-28.85,-66.6,1.3006,1.3006,0,0,0,173.1,121);

	this.b7helm = new lib.helmsymb();
	this.b7helm.name = "b7helm";
	this.b7helm.setTransform(-28.85,-88.1,1.3006,1.3006,0,0,0,173.1,121);

	this.b8helm = new lib.helmsymb();
	this.b8helm.name = "b8helm";
	this.b8helm.setTransform(-28.85,-88.1,1.3006,1.3006,0,0,0,173.1,121);

	this.b9helm = new lib.helmsymb();
	this.b9helm.name = "b9helm";
	this.b9helm.setTransform(-28.85,-88.1,1.3006,1.3006,0,0,0,173.1,121);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.helm}]}).to({state:[]},1).to({state:[{t:this.b3helm}]},1).to({state:[{t:this.b4phonelinks}]},1).to({state:[]},1).to({state:[{t:this.b6helm}]},1).to({state:[{t:this.b7helm}]},1).to({state:[{t:this.b8helm}]},1).to({state:[{t:this.b9helm}]},1).wait(1));

	// spinbig
	this.p2 = new lib.p2();
	this.p2.name = "p2";
	this.p2.setTransform(0,89.5);

	this.b3riembreedv2 = new lib.riembreed();
	this.b3riembreedv2.name = "b3riembreedv2";
	this.b3riembreedv2.setTransform(1.85,1.55,1.011,1,90);

	this.b4phonerechts = new lib.phonerechtsmovie();
	this.b4phonerechts.name = "b4phonerechts";
	this.b4phonerechts.setTransform(14.7,-68.65);

	this.b6mutslinks = new lib.mutslinksgras();
	this.b6mutslinks.name = "b6mutslinks";
	this.b6mutslinks.setTransform(-89.45,-0.25,10.4607,10.4424,0,0,0,8.8,18.1);

	this.b7skibrilklein1 = new lib.symbskibrilklein21();
	this.b7skibrilklein1.name = "b7skibrilklein1";
	this.b7skibrilklein1.setTransform(-121.4,4.8);

	this.b8rieml1boven = new lib.riemball11();
	this.b8rieml1boven.name = "b8rieml1boven";
	this.b8rieml1boven.setTransform(18.5,-5.45,1.056,1.0717,46.4116);
	this.b8rieml1boven.filters = [new cjs.ColorFilter(0.75, 0.75, 0.75, 1, 0, 0, 0, 0)];
	this.b8rieml1boven.cache(-187,-50,356,178);

	this.b9skibril = new lib.symbskibril();
	this.b9skibril.name = "b9skibril";
	this.b9skibril.setTransform(1.8,0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p2}]}).to({state:[]},1).to({state:[{t:this.b3riembreedv2}]},1).to({state:[{t:this.b4phonerechts}]},1).to({state:[]},1).to({state:[{t:this.b6mutslinks}]},1).to({state:[{t:this.b7skibrilklein1}]},1).to({state:[{t:this.b8rieml1boven}]},1).to({state:[{t:this.b9skibril}]},1).wait(1));

	// slurf
	this.p1 = new lib.balp1();
	this.p1.name = "p1";
	this.p1.setTransform(0,-70.15);

	this.b3riemv2 = new lib.riem();
	this.b3riemv2.name = "b3riemv2";
	this.b3riemv2.setTransform(1.85,0.85,0.9997,1,90);

	this.b4mutsboven = new lib.mutsboven();
	this.b4mutsboven.name = "b4mutsboven";
	this.b4mutsboven.setTransform(-0.35,-76.5);

	this.b6mutsrechts = new lib.mutsrechtsgras();
	this.b6mutsrechts.name = "b6mutsrechts";
	this.b6mutsrechts.setTransform(57.3,0.1,9.9692,9.9896,0,0,0,10.3,18.2);

	this.b7riem1 = new lib.riemball11();
	this.b7riem1.name = "b7riem1";
	this.b7riem1.setTransform(9.4,-25.95,1.0486,1);

	this.b8riemrboven = new lib.riemball11();
	this.b8riemrboven.name = "b8riemrboven";
	this.b8riemrboven.setTransform(8.35,20.05,1.0668,1.0197,129.9814);

	this.b9skibrilklein = new lib.symbskibrilklein();
	this.b9skibrilklein.name = "b9skibrilklein";
	this.b9skibrilklein.setTransform(-121.4,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.p1}]}).to({state:[]},1).to({state:[{t:this.b3riemv2}]},1).to({state:[{t:this.b4mutsboven}]},1).to({state:[]},1).to({state:[{t:this.b6mutsrechts}]},1).to({state:[{t:this.b7riem1}]},1).to({state:[{t:this.b8riemrboven}]},1).to({state:[{t:this.b9skibrilklein}]},1).wait(1));

	// brilgroot
	this.b3riembreed2 = new lib.riembreed();
	this.b3riembreed2.name = "b3riembreed2";
	this.b3riembreed2.setTransform(1.85,1.55,1.011,1);

	this.b4mutsonder = new lib.mutsonder();
	this.b4mutsonder.name = "b4mutsonder";
	this.b4mutsonder.setTransform(-0.35,-76.5);

	this.b6bloemblauw4 = new lib.bloemblauw4();
	this.b6bloemblauw4.name = "b6bloemblauw4";
	this.b6bloemblauw4.setTransform(-20.65,174.05);

	this.b7skibrilklein2 = new lib.symbskibrilklein22();
	this.b7skibrilklein2.name = "b7skibrilklein2";
	this.b7skibrilklein2.setTransform(-121.4,4.8);

	this.b8rieml2boven = new lib.riemball11();
	this.b8rieml2boven.name = "b8rieml2boven";
	this.b8rieml2boven.setTransform(18.4,-5.55,1.056,1.0718,46.4081);
	this.b8rieml2boven.filters = [new cjs.ColorFilter(0.75, 0.75, 0.75, 1, 0, 0, 0, 0)];
	this.b8rieml2boven.cache(-187,-50,356,178);

	this.b9riem4 = new lib.riem13bovenn();
	this.b9riem4.name = "b9riem4";
	this.b9riem4.setTransform(-25.55,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3riembreed2}]},2).to({state:[{t:this.b4mutsonder}]},1).to({state:[]},1).to({state:[{t:this.b6bloemblauw4}]},1).to({state:[{t:this.b7skibrilklein2}]},1).to({state:[{t:this.b8rieml2boven}]},1).to({state:[{t:this.b9riem4}]},1).wait(1));

	// brilgrootonder
	this.b3riem = new lib.riem();
	this.b3riem.name = "b3riem";
	this.b3riem.setTransform(1.85,1.55,1.011,1);

	this.b4helm = new lib.helmsymb();
	this.b4helm.name = "b4helm";
	this.b4helm.setTransform(-29.85,-76.45,1.3006,1.3006,6.348,0,0,173.1,121);

	this.b6bloemblauw3 = new lib.bloemblauw3();
	this.b6bloemblauw3.name = "b6bloemblauw3";
	this.b6bloemblauw3.setTransform(99.35,134.05);

	this.b7zorro = new lib.symbzorro();
	this.b7zorro.name = "b7zorro";
	this.b7zorro.setTransform(0.65,-5.3,1.0055,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","#EEEEEE","#8D8D8D","#888888"],[0,0.173,0.741,0.898],156.5,80.5,0,156.5,80.5,278.7).s().p("AAKgFIgKAGIgJAFIATgLg");
	this.shape.setTransform(-97.025,-149.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("Ag9AyIgCACIgGAFIgIAHIgCACIASgQgAgcAVIgBAAIgBABIACgBgAA6gwIgLAIIgDADIgPALIAdgWgABQhBIgGAFIgCACIAIgHg");
	this.shape_1.setTransform(-113.075,-137.375);

	this.b8mutslinks = new lib.mutslinks13();
	this.b8mutslinks.name = "b8mutslinks";
	this.b8mutslinks.setTransform(-83.8,5.6,10.8729,10.4335,-2.9694,0,0,8.8,18.1);

	this.b9mutslinks = new lib.mutslinks13();
	this.b9mutslinks.name = "b9mutslinks";
	this.b9mutslinks.setTransform(-78.3,-0.1,10.7138,10.2788,0,0,0,8.8,18.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3riem}]},2).to({state:[{t:this.b4helm}]},1).to({state:[]},1).to({state:[{t:this.b6bloemblauw3}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.b7zorro}]},1).to({state:[{t:this.b8mutslinks}]},1).to({state:[{t:this.b9mutslinks}]},1).wait(1));

	// bril
	this.b3riembreed1 = new lib.riembreed2();
	this.b3riembreed1.name = "b3riembreed1";
	this.b3riembreed1.setTransform(1.85,1.55,1.0026,1);

	this.b4riemvoor = new lib.riembreed2();
	this.b4riemvoor.name = "b4riemvoor";
	this.b4riemvoor.setTransform(1.85,1.55,1.0026,1);

	this.b6bloemblauw2 = new lib.bloemblauw2();
	this.b6bloemblauw2.name = "b6bloemblauw2";
	this.b6bloemblauw2.setTransform(119.35,-15.95);

	this.b7skibrilklein3 = new lib.symbskibrilklein2();
	this.b7skibrilklein3.name = "b7skibrilklein3";
	this.b7skibrilklein3.setTransform(-121.4,4.8);

	this.b8mutsrechts = new lib.mutsrechts();
	this.b8mutsrechts.name = "b8mutsrechts";
	this.b8mutsrechts.setTransform(56.95,-3.8,10.1277,10.1584,-4.4301,0,0,10.3,18.2);

	this.b9mutsrechts = new lib.mutsrechts();
	this.b9mutsrechts.name = "b9mutsrechts";
	this.b9mutsrechts.setTransform(57.3,0.1,9.9692,9.9896,0,0,0,10.3,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3riembreed1}]},2).to({state:[{t:this.b4riemvoor}]},1).to({state:[]},1).to({state:[{t:this.b6bloemblauw2}]},1).to({state:[{t:this.b7skibrilklein3}]},1).to({state:[{t:this.b8mutsrechts}]},1).to({state:[{t:this.b9mutsrechts}]},1).wait(1));

	// brilonder
	this.b3riemv1 = new lib.riem();
	this.b3riemv1.name = "b3riemv1";
	this.b3riemv1.setTransform(1.85,0.85,0.9997,1,90);

	this.b4riemv = new lib.riem();
	this.b4riemv.name = "b4riemv";
	this.b4riemv.setTransform(1.85,0.85,0.9997,1,90);

	this.b6bloemblauw1 = new lib.bloemblauw1();
	this.b6bloemblauw1.name = "b6bloemblauw1";
	this.b6bloemblauw1.setTransform(-40.65,-15.95);

	this.b7riem2 = new lib.riemball11();
	this.b7riem2.name = "b7riem2";
	this.b7riem2.setTransform(8.9,-25.95,1.017,1);

	this.b8rieml1 = new lib.riemball11();
	this.b8rieml1.name = "b8rieml1";
	this.b8rieml1.setTransform(18.4,-5.45,1.0283,1.0436,46.4135);
	this.b8rieml1.filters = [new cjs.ColorFilter(0.75, 0.75, 0.75, 1, 0, 0, 0, 0)];
	this.b8rieml1.cache(-187,-50,356,178);

	this.b9riem2 = new lib.riem13onder3();
	this.b9riem2.name = "b9riem2";
	this.b9riem2.setTransform(-25.55,-1.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3riemv1}]},2).to({state:[{t:this.b4riemv}]},1).to({state:[]},1).to({state:[{t:this.b6bloemblauw1}]},1).to({state:[{t:this.b7riem2}]},1).to({state:[{t:this.b8rieml1}]},1).to({state:[{t:this.b9riem2}]},1).wait(1));

	// phonelinks
	this.b3riembreedv1 = new lib.riembreed2();
	this.b3riembreedv1.name = "b3riembreedv1";
	this.b3riembreedv1.setTransform(1.85,1.05,1.0004,1,90);

	this.b4riem = new lib.riembreed2();
	this.b4riem.name = "b4riem";
	this.b4riem.setTransform(1.85,1.55,1.0026,1);

	this.b6bloemwit4 = new lib.bloemwit4();
	this.b6bloemwit4.name = "b6bloemwit4";
	this.b6bloemwit4.setTransform(-20.65,174.05);

	this.b7skibrilklein4 = new lib.symbskibrilklein3();
	this.b7skibrilklein4.name = "b7skibrilklein4";
	this.b7skibrilklein4.setTransform(-121.4,4.8);

	this.b8riemr = new lib.riemball11();
	this.b8riemr.name = "b8riemr";
	this.b8riemr.setTransform(9.4,19.05,1.0296,0.9842,129.974);

	this.b9riem3 = new lib.riem13onder2();
	this.b9riem3.name = "b9riem3";
	this.b9riem3.setTransform(-25.55,-1.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3riembreedv1}]},2).to({state:[{t:this.b4riem}]},1).to({state:[]},1).to({state:[{t:this.b6bloemwit4}]},1).to({state:[{t:this.b7skibrilklein4}]},1).to({state:[{t:this.b8riemr}]},1).to({state:[{t:this.b9riem3}]},1).wait(1));

	// phonerechts
	this.b3riembreed0 = new lib.riembreed2();
	this.b3riembreed0.name = "b3riembreed0";
	this.b3riembreed0.setTransform(1.85,1.55,1.0026,1);

	this.b4p22 = new lib.bal5p22();
	this.b4p22.name = "b4p22";
	this.b4p22.setTransform(80.2,136.05);

	this.b6bloemwit3 = new lib.bloemwit3();
	this.b6bloemwit3.name = "b6bloemwit3";
	this.b6bloemwit3.setTransform(99.35,134.05);

	this.b7p1 = new lib.ball11p1mov();
	this.b7p1.name = "b7p1";
	this.b7p1.setTransform(-73.95,-113.6);

	this.b8rieml2 = new lib.riemball11();
	this.b8rieml2.name = "b8rieml2";
	this.b8rieml2.setTransform(18.4,-5.45,1.0283,1.0436,46.4135);
	this.b8rieml2.filters = [new cjs.ColorFilter(0.75, 0.75, 0.75, 1, 0, 0, 0, 0)];
	this.b8rieml2.cache(-187,-50,356,178);

	this.b9riem1 = new lib.riem13onder();
	this.b9riem1.name = "b9riem1";
	this.b9riem1.setTransform(-25.55,-1.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3riembreed0}]},2).to({state:[{t:this.b4p22}]},1).to({state:[]},1).to({state:[{t:this.b6bloemwit3}]},1).to({state:[{t:this.b7p1}]},1).to({state:[{t:this.b8rieml2}]},1).to({state:[{t:this.b9riem1}]},1).wait(1));

	// mutsboven
	this.b3p18 = new lib.bal3p18();
	this.b3p18.name = "b3p18";
	this.b3p18.setTransform(-18.45,149.1);

	this.b4p21 = new lib.bal5p21();
	this.b4p21.name = "b4p21";
	this.b4p21.setTransform(-18.1,148.75);

	this.b6bloemwit2 = new lib.bloemwit2();
	this.b6bloemwit2.name = "b6bloemwit2";
	this.b6bloemwit2.setTransform(119.35,-15.95);

	this.b7p2 = new lib.ball11p2movn();
	this.b7p2.name = "b7p2";
	this.b7p2.setTransform(51.05,-113.9);

	this.b8p1 = new lib.bal12p1mov();
	this.b8p1.name = "b8p1";
	this.b8p1.setTransform(-52.25,-128.9);

	this.b9p1 = new lib.ball13p1mov();
	this.b9p1.name = "b9p1";
	this.b9p1.setTransform(-115.25,-86.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p18}]},2).to({state:[{t:this.b4p21}]},1).to({state:[]},1).to({state:[{t:this.b6bloemwit2}]},1).to({state:[{t:this.b7p2}]},1).to({state:[{t:this.b8p1}]},1).to({state:[{t:this.b9p1}]},1).wait(1));

	// mutsonder
	this.b3p17 = new lib.bal3p17();
	this.b3p17.name = "b3p17";
	this.b3p17.setTransform(-16.2,144);

	this.b4p20 = new lib.bal5p20();
	this.b4p20.name = "b4p20";
	this.b4p20.setTransform(-87.5,138);

	this.b6bloemwit1 = new lib.bloemwit1();
	this.b6bloemwit1.name = "b6bloemwit1";
	this.b6bloemwit1.setTransform(-40.65,-15.95);

	this.b7p3 = new lib.ball11p3mov();
	this.b7p3.name = "b7p3";
	this.b7p3.setTransform(-102.45,-79.9);

	this.b8p2 = new lib.ball12p2mov();
	this.b8p2.name = "b8p2";
	this.b8p2.setTransform(9.45,-129.15);

	this.b9p2 = new lib.ball13p2mov();
	this.b9p2.name = "b9p2";
	this.b9p2.setTransform(-43.05,-118.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p17}]},2).to({state:[{t:this.b4p20}]},1).to({state:[]},1).to({state:[{t:this.b6bloemwit1}]},1).to({state:[{t:this.b7p3}]},1).to({state:[{t:this.b8p2}]},1).to({state:[{t:this.b9p2}]},1).wait(1));

	// helm
	this.b3p16 = new lib.bal3p16();
	this.b3p16.name = "b3p16";
	this.b3p16.setTransform(2.5,121.7);

	this.b4p19 = new lib.bal5p19();
	this.b4p19.name = "b4p19";
	this.b4p19.setTransform(84.35,119.55);

	this.b6gras04 = new lib.gras04();
	this.b6gras04.name = "b6gras04";
	this.b6gras04.setTransform(-84.05,97.5);

	this.b7p4 = new lib.ball11p4mov();
	this.b7p4.name = "b7p4";
	this.b7p4.setTransform(60.35,-81.5);

	this.b8p3 = new lib.bal12p3mov();
	this.b8p3.name = "b8p3";
	this.b8p3.setTransform(-100,-72.75);

	this.b9p3 = new lib.ball13p3mov();
	this.b9p3.name = "b9p3";
	this.b9p3.setTransform(1.05,-118.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p16}]},2).to({state:[{t:this.b4p19}]},1).to({state:[]},1).to({state:[{t:this.b6gras04}]},1).to({state:[{t:this.b7p4}]},1).to({state:[{t:this.b8p3}]},1).to({state:[{t:this.b9p3}]},1).wait(1));

	// riemvbreed2
	this.b3p15 = new lib.bal3p15();
	this.b3p15.name = "b3p15";
	this.b3p15.setTransform(-36.9,102.05);

	this.b4p18 = new lib.bal5p18();
	this.b4p18.name = "b4p18";
	this.b4p18.setTransform(-30.8,111,1,1,0,0,0,0,-28.1);

	this.b6gras03 = new lib.gras03();
	this.b6gras03.name = "b6gras03";
	this.b6gras03.setTransform(83.45,90.75);

	this.b7p5 = new lib.ball11p5mov();
	this.b7p5.name = "b7p5";
	this.b7p5.setTransform(-108.95,-25.55);

	this.b8p4 = new lib.ball12p4mov();
	this.b8p4.name = "b8p4";
	this.b8p4.setTransform(53.35,-78.25);

	this.b9p4 = new lib.ball13p4mov();
	this.b9p4.name = "b9p4";
	this.b9p4.setTransform(93.85,-87.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p15}]},2).to({state:[{t:this.b4p18}]},1).to({state:[]},1).to({state:[{t:this.b6gras03}]},1).to({state:[{t:this.b7p5}]},1).to({state:[{t:this.b8p4}]},1).to({state:[{t:this.b9p4}]},1).wait(1));

	// riemv2
	this.b3p14 = new lib.bal3p14();
	this.b3p14.name = "b3p14";
	this.b3p14.setTransform(-31.15,98.05);

	this.b4p17 = new lib.bal5p17();
	this.b4p17.name = "b4p17";
	this.b4p17.setTransform(-114.2,115);

	this.b6gras02 = new lib.gras02();
	this.b6gras02.name = "b6gras02";
	this.b6gras02.setTransform(83.2,-74.25);

	this.b7p6 = new lib.ball11p6mov();
	this.b7p6.name = "b7p6";
	this.b7p6.setTransform(65,-25.45);

	this.b8p5 = new lib.ball12p5mov();
	this.b8p5.name = "b8p5";
	this.b8p5.setTransform(-144.55,-35.9);

	this.b9p5 = new lib.ball13p5mov();
	this.b9p5.name = "b9p5";
	this.b9p5.setTransform(-127.9,-39.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p14}]},2).to({state:[{t:this.b4p17}]},1).to({state:[]},1).to({state:[{t:this.b6gras02}]},1).to({state:[{t:this.b7p6}]},1).to({state:[{t:this.b8p5}]},1).to({state:[{t:this.b9p5}]},1).wait(1));

	// riembreed2
	this.b3p13 = new lib.bal3p13();
	this.b3p13.name = "b3p13";
	this.b3p13.setTransform(0.4,83.35);

	this.b4p16 = new lib.ball5p16();
	this.b4p16.name = "b4p16";
	this.b4p16.setTransform(98.7,63.2);

	this.b6gras01 = new lib.gras01();
	this.b6gras01.name = "b6gras01";
	this.b6gras01.setTransform(-94.25,-72.7);

	this.b7p7 = new lib.ball11p7mov();
	this.b7p7.name = "b7p7";
	this.b7p7.setTransform(-115.5,-12.3);

	this.b8p6 = new lib.ball12p6mov();
	this.b8p6.name = "b8p6";
	this.b8p6.setTransform(-77.5,-33);

	this.b9p6 = new lib.ball13p6mov();
	this.b9p6.name = "b9p6";
	this.b9p6.setTransform(-64,-32.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p13}]},2).to({state:[{t:this.b4p16}]},1).to({state:[]},1).to({state:[{t:this.b6gras01}]},1).to({state:[{t:this.b7p7}]},1).to({state:[{t:this.b8p6}]},1).to({state:[{t:this.b9p6}]},1).wait(1));

	// riem
	this.b3p12 = new lib.bal3p12();
	this.b3p12.name = "b3p12";
	this.b3p12.setTransform(-45.05,66.3);

	this.b4p15 = new lib.ball5p15();
	this.b4p15.name = "b4p15";
	this.b4p15.setTransform(86.15,67.05);

	this.b6p4 = new lib.bal8p4();
	this.b6p4.name = "b6p4";
	this.b6p4.setTransform(-98,98.5);

	this.b7p8 = new lib.ball11p8mov();
	this.b7p8.name = "b7p8";
	this.b7p8.setTransform(-112.75,-4.25);

	this.b8p7 = new lib.ball12p7mov();
	this.b8p7.name = "b8p7";
	this.b8p7.setTransform(-4.8,-33.2);

	this.b9p7 = new lib.ball13p7mov();
	this.b9p7.name = "b9p7";
	this.b9p7.setTransform(-16.55,-29.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p12}]},2).to({state:[{t:this.b4p15}]},1).to({state:[]},1).to({state:[{t:this.b6p4}]},1).to({state:[{t:this.b7p8}]},1).to({state:[{t:this.b8p7}]},1).to({state:[{t:this.b9p7}]},1).wait(1));

	// riembreed1
	this.b3p11 = new lib.bal3p11();
	this.b3p11.name = "b3p11";
	this.b3p11.setTransform(-39.1,61.9);

	this.b4p14 = new lib.bal5p14();
	this.b4p14.name = "b4p14";
	this.b4p14.setTransform(-36.6,84.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AAAAGIAAgMIAAANg");
	this.shape_2.setTransform(-82.2,-43.1375);

	this.b6p3 = new lib.bal8p3();
	this.b6p3.name = "b6p3";
	this.b6p3.setTransform(96,93);

	this.b7p9 = new lib.ball11p9mov();
	this.b7p9.name = "b7p9";
	this.b7p9.setTransform(44,-9.25);

	this.b8p8 = new lib.ball12p8mov();
	this.b8p8.name = "b8p8";
	this.b8p8.setTransform(105.45,-42);

	this.b9p8 = new lib.ball13p8mov();
	this.b9p8.name = "b9p8";
	this.b9p8.setTransform(82.25,-39.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p11}]},2).to({state:[{t:this.shape_2},{t:this.b4p14}]},1).to({state:[]},1).to({state:[{t:this.b6p3}]},1).to({state:[{t:this.b7p9}]},1).to({state:[{t:this.b8p8}]},1).to({state:[{t:this.b9p8}]},1).wait(1));

	// oorrechts2
	this.b3p6 = new lib.bal3p6();
	this.b3p6.name = "b3p6";
	this.b3p6.setTransform(-49.65,-15.45);

	this.b4p13 = new lib.ball5p13();
	this.b4p13.name = "b4p13";
	this.b4p13.setTransform(-116.35,79.2);

	this.b6p2 = new lib.bal8p2();
	this.b6p2.name = "b6p2";
	this.b6p2.setTransform(96,3);

	this.b7p10 = new lib.ball11p10mov();
	this.b7p10.name = "b7p10";
	this.b7p10.setTransform(32,-3.4);

	this.b8p9 = new lib.ball12p9mov();
	this.b8p9.name = "b8p9";
	this.b8p9.setTransform(-144.25,42.7);

	this.b9p9 = new lib.ball13p9mov();
	this.b9p9.name = "b9p9";
	this.b9p9.setTransform(-131.15,-20.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p6}]},2).to({state:[{t:this.b4p13}]},1).to({state:[]},1).to({state:[{t:this.b6p2}]},1).to({state:[{t:this.b7p10}]},1).to({state:[{t:this.b8p9}]},1).to({state:[{t:this.b9p9}]},1).wait(1));

	// oorrechts1
	this.b3p5 = new lib.bal3p5();
	this.b3p5.name = "b3p5";
	this.b3p5.setTransform(-44.6,-36.75,1,1,0,0,0,-0.1,-17.4);

	this.b4p12 = new lib.ball5p12();
	this.b4p12.name = "b4p12";
	this.b4p12.setTransform(-138.5,47.75);

	this.b6p1 = new lib.bal8p1();
	this.b6p1.name = "b6p1";
	this.b6p1.setTransform(-98,2.5);

	this.b7p12 = new lib.ball11p12mov();
	this.b7p12.name = "b7p12";
	this.b7p12.setTransform(-115.5,30.15);

	this.b8p10 = new lib.ball12p10mov();
	this.b8p10.name = "b8p10";
	this.b8p10.setTransform(-71.9,57.55);

	this.b9p10 = new lib.ball13p10mov();
	this.b9p10.name = "b9p10";
	this.b9p10.setTransform(65.1,-21.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p5}]},2).to({state:[{t:this.b4p12}]},1).to({state:[]},1).to({state:[{t:this.b6p1}]},1).to({state:[{t:this.b7p12}]},1).to({state:[{t:this.b8p10}]},1).to({state:[{t:this.b9p10}]},1).wait(1));

	// Layer_3
	this.b3p2 = new lib.bal3p2();
	this.b3p2.name = "b3p2";
	this.b3p2.setTransform(-21.4,-105.85);

	this.b4p11 = new lib.ball5p11();
	this.b4p11.name = "b4p11";
	this.b4p11.setTransform(97.65,5.65);

	this.b7p11 = new lib.ball11p11mov();
	this.b7p11.name = "b7p11";
	this.b7p11.setTransform(-113.1,25.35);

	this.b8p11 = new lib.ball12p11mov();
	this.b8p11.name = "b8p11";
	this.b8p11.setTransform(-5.9,57.55);

	this.b9p13 = new lib.ball13p13mov();
	this.b9p13.name = "b9p13";
	this.b9p13.setTransform(-129.7,45.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AAAACIgBgGIADAJg");
	this.shape_3.setTransform(-173.2375,39.9125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p2}]},2).to({state:[{t:this.b4p11}]},1).to({state:[]},1).to({state:[{t:this.b7p11}]},2).to({state:[{t:this.b8p11}]},1).to({state:[{t:this.shape_3},{t:this.b9p13}]},1).wait(1));

	// p22
	this.b3p1 = new lib.bal3p1();
	this.b3p1.name = "b3p1";
	this.b3p1.setTransform(-1.2,-99.85);

	this.b4p6 = new lib.bal5p6();
	this.b4p6.name = "b4p6";
	this.b4p6.setTransform(75.95,-72.7);

	this.b7p14 = new lib.ball11p14mov();
	this.b7p14.name = "b7p14";
	this.b7p14.setTransform(43.95,38.5);

	this.b8p12 = new lib.ball12p12mov();
	this.b8p12.name = "b8p12";
	this.b8p12.setTransform(107.25,35.1);

	this.b9p14 = new lib.ball13p14mov();
	this.b9p14.name = "b9p14";
	this.b9p14.setTransform(-65.45,49.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p1}]},2).to({state:[{t:this.b4p6}]},1).to({state:[]},1).to({state:[{t:this.b7p14}]},2).to({state:[{t:this.b8p12}]},1).to({state:[{t:this.b9p14}]},1).wait(1));

	// p21
	this.b3p8 = new lib.bal3p8();
	this.b3p8.name = "b3p8";
	this.b3p8.setTransform(-43.05,24.45);

	this.b4p5 = new lib.bal5p5();
	this.b4p5.name = "b4p5";
	this.b4p5.setTransform(-47.95,-67.85,1,1,0,0,0,-0.1,-4.9);

	this.b7p13 = new lib.ball11p13mov();
	this.b7p13.name = "b7p13";
	this.b7p13.setTransform(32.05,34.3);

	this.b8p13 = new lib.ball12p13mov();
	this.b8p13.name = "b8p13";
	this.b8p13.setTransform(-90.75,88.5);

	this.b9p11 = new lib.ball13p11mov();
	this.b9p11.name = "b9p11";
	this.b9p11.setTransform(-131.2,29.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p8}]},2).to({state:[{t:this.b4p5}]},1).to({state:[]},1).to({state:[{t:this.b7p13}]},2).to({state:[{t:this.b8p13}]},1).to({state:[{t:this.b9p11}]},1).wait(1));

	// p20
	this.b3p7 = new lib.bal3p7();
	this.b3p7.name = "b3p7";
	this.b3p7.setTransform(0,10.3);

	this.b4p2 = new lib.bal5p2();
	this.b4p2.name = "b4p2";
	this.b4p2.setTransform(-26.3,-105.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FFFFFF","#EEEEEE","#8D8D8D","#888888"],[0,0.173,0.741,0.898],188.5,15.8,0,188.5,15.8,281).s().p("AgaEDIAAAMIAAABgAk7AWIgQAfIgCACIASghgAFLihIAAgBIAAABIACACIgCgCgAgkkJIACgCQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAgBAAIAAADIgCACg");
	this.shape_4.setTransform(-128.45,-85.75);

	this.b7p15 = new lib.ball11p15mov();
	this.b7p15.name = "b7p15";
	this.b7p15.setTransform(-107.4,39.9);

	this.b8p14 = new lib.ball12p14mov();
	this.b8p14.name = "b8p14";
	this.b8p14.setTransform(61.5,86.85);

	this.b9p15 = new lib.ball13p15mov();
	this.b9p15.name = "b9p15";
	this.b9p15.setTransform(-17.75,49.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p7}]},2).to({state:[{t:this.shape_4},{t:this.b4p2}]},1).to({state:[]},1).to({state:[{t:this.b7p15}]},2).to({state:[{t:this.b8p14}]},1).to({state:[{t:this.b9p15}]},1).wait(1));

	// p19
	this.b3p4 = new lib.bal3p4();
	this.b3p4.name = "b3p4";
	this.b3p4.setTransform(-0.3,-34.3,1,1,0,0,0,0,-1.4);

	this.b4p1 = new lib.bal5p1();
	this.b4p1.name = "b4p1";
	this.b4p1.setTransform(-103.25,-108.6);

	this.b7p16 = new lib.ball11p16mov();
	this.b7p16.name = "b7p16";
	this.b7p16.setTransform(65.1,40.45);

	this.b8p15 = new lib.ball12p15mov();
	this.b8p15.name = "b8p15";
	this.b8p15.setTransform(-28.9,139.75);

	this.b9p16 = new lib.ball13p16mov();
	this.b9p16.name = "b9p16";
	this.b9p16.setTransform(82.5,51.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p4}]},2).to({state:[{t:this.b4p1}]},1).to({state:[]},1).to({state:[{t:this.b7p16}]},2).to({state:[{t:this.b8p15}]},1).to({state:[{t:this.b9p16}]},1).wait(1));

	// p18
	this.b3p3 = new lib.bal3p3();
	this.b3p3.name = "b3p3";
	this.b3p3.setTransform(-25.3,-107.05);

	this.b4p8 = new lib.ball5p8();
	this.b4p8.name = "b4p8";
	this.b4p8.setTransform(-127.35,-13.9);

	this.b7p17 = new lib.ball11p17mov();
	this.b7p17.name = "b7p17";
	this.b7p17.setTransform(-103.5,92.4);

	this.b8p16 = new lib.ball12p16mov();
	this.b8p16.name = "b8p16";
	this.b8p16.setTransform(18.9,140.65);

	this.b9p12 = new lib.ball13p12mov();
	this.b9p12.name = "b9p12";
	this.b9p12.setTransform(65.35,35.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p3}]},2).to({state:[{t:this.b4p8}]},1).to({state:[]},1).to({state:[{t:this.b7p17}]},2).to({state:[{t:this.b8p16}]},1).to({state:[{t:this.b9p12}]},1).wait(1));

	// p17
	this.b3p10 = new lib.bal3p10();
	this.b3p10.name = "b3p10";
	this.b3p10.setTransform(0.05,48.25);

	this.b4p7 = new lib.ball5p7();
	this.b4p7.name = "b4p7";
	this.b4p7.setTransform(-137.4,-8.3);

	this.b7p18 = new lib.ball11p18mov();
	this.b7p18.name = "b7p18";
	this.b7p18.setTransform(64.75,96.15);

	this.b9p17 = new lib.ball13p17mov();
	this.b9p17.name = "b9p17";
	this.b9p17.setTransform(-116.1,81.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p10}]},2).to({state:[{t:this.b4p7}]},1).to({state:[]},1).to({state:[{t:this.b7p18}]},2).to({state:[]},1).to({state:[{t:this.b9p17}]},1).wait(1));

	// p16
	this.b3p9 = new lib.bal3p9();
	this.b3p9.name = "b3p9";
	this.b3p9.setTransform(-48.9,28.25);

	this.b4p4 = new lib.bal5p4();
	this.b4p4.name = "b4p4";
	this.b4p4.setTransform(-123.3,-77);

	this.b7p19 = new lib.ball11p19mov();
	this.b7p19.name = "b7p19";
	this.b7p19.setTransform(-70.65,129.3);

	this.b9p18 = new lib.ball13p18mov();
	this.b9p18.name = "b9p18";
	this.b9p18.setTransform(-45.2,124.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b3p9}]},2).to({state:[{t:this.b4p4}]},1).to({state:[]},1).to({state:[{t:this.b7p19}]},2).to({state:[]},1).to({state:[{t:this.b9p18}]},1).wait(1));

	// p15
	this.b4p3 = new lib.bal5p3();
	this.b4p3.name = "b4p3";
	this.b4p3.setTransform(63,-104.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#FFFFFF","#EEEEEE","#8D8D8D","#888888"],[0,0.173,0.741,0.898],121.3,-2.1,0,121.3,-2.1,281).s().p("AjRD9IAEAPIAAAAgADPkLIAAAAIADACIgDgCg");
	this.shape_5.setTransform(-61.3,-67.8375);

	this.b7p20 = new lib.ball11p20mov();
	this.b7p20.name = "b7p20";
	this.b7p20.setTransform(56.65,129.4);

	this.b9p19 = new lib.ball13p19mov();
	this.b9p19.name = "b9p19";
	this.b9p19.setTransform(-1.15,124.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.b4p3}]},3).to({state:[]},1).to({state:[{t:this.b7p20}]},2).to({state:[]},1).to({state:[{t:this.b9p19}]},1).wait(1));

	// p14
	this.b4p10 = new lib.ball5p10();
	this.b4p10.name = "b4p10";
	this.b4p10.setTransform(82.9,-9.35);

	this.b9p20 = new lib.ball13p20mov();
	this.b9p20.name = "b9p20";
	this.b9p20.setTransform(92.7,82.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.b4p10}]},3).to({state:[]},1).to({state:[{t:this.b9p20}]},4).wait(1));

	// p9
	this.b4p9 = new lib.bal5p9();
	this.b4p9.name = "b4p9";
	this.b4p9.setTransform(-45.7,6.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("AAAAGIAAgMIAAANg");
	this.shape_6.setTransform(-82.2,-43.1375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6},{t:this.b4p9}]},3).to({state:[]},1).wait(5));

	// Layer_1
	this.bal = new lib.levelbalsymb();
	this.bal.name = "bal";
	this.bal.setTransform(0,0,0.9861,0.9861);

	this.timeline.addTween(cjs.Tween.get(this.bal).to({_off:true},6).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-282.7,-365.5,499.6,580.9);


(lib.buttonrechts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.pijl = new lib.arrowsymb();
	this.pijl.name = "pijl";
	this.pijl.setTransform(8.9,0.05);

	this.timeline.addTween(cjs.Tween.get(this.pijl).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbalmovieyellow();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonrechts, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.buttonlinks = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.pijl = new lib.arrowsymb();
	this.pijl.name = "pijl";
	this.pijl.setTransform(-9.1,0.05,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.pijl).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbalmovieyellow();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.buttonlinks, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.toolsmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{verfgroen:0,verforanje:1,verfblauw:2,verfrood:3,verfzwart:4,verfgeel:5,verfwit:6,verfmagenta:7,verfroze:8,verfgroen2:9,leeg:10,helm:11,helmweg:12,helmrot:13,helmrotweg:14,bril:15,brilweg:16,brilonder:17,brilonderweg:18,brilgroot:19,brilgrootweg:20,brilgrootonder:21,brilgrootonderweg:22,riem:23,riemweg:24,riemv:25,riemvweg:26,riembreed:27,riembreedweg:28,riembreedv:29,riembreedvweg:30,stophor:31,stoplinks:32,stoprechts:33,bin:34,mutsonder:35,mutsonderweg:36,mutsboven:37,mutsbovenweg:38,spin:39,spinweg:40,tang:41,steekmes:42,graszaad:43,gieter:44,phonerechts:45,phonerechtsweg:46,phonelinks:47,phonelinksweg:48,bloemwitzaad:49,bloemblauwzaad:50,mutsrechts:51,mutsrechtsweg:52,mutslinks:53,mutslinksweg:54,bijl:55,mondlap:56,mondlapweg:57,stempel:58,zorro:59,zorroweg:60,riem11:61,riem11weg:62,riemr:63,riemrweg:64,rieml:65,riemlweg:66,skibril:67,skibrilweg:68,skibrilklein:69,skibrilkleinweg:70,skibrilklein11:71,skibrilklein11weg:72,riem13:73,riem13weg:74});

	// timeline functions:
	this.frame_0 = function() {
		this.verfpot.gotoAndStop("groen");
		this.stop();
	}
	this.frame_1 = function() {
		this.verfpot.gotoAndStop("oranje");
		this.stop();
	}
	this.frame_2 = function() {
		this.verfpot.gotoAndStop("blauw");
		this.stop();
	}
	this.frame_3 = function() {
		this.verfpot.gotoAndStop("rood");
		this.stop();
	}
	this.frame_4 = function() {
		this.verfpot.gotoAndStop("zwart");
		this.stop();
	}
	this.frame_5 = function() {
		this.verfpot.gotoAndStop("geel");
		this.stop();
	}
	this.frame_6 = function() {
		this.verfpot.gotoAndStop("wit");
		this.stop();
	}
	this.frame_7 = function() {
		this.verfpot.gotoAndStop("magenta");
		this.stop();
	}
	this.frame_8 = function() {
		this.verfpot.gotoAndStop("roze");
		this.stop();
	}
	this.frame_9 = function() {
		this.verfpot.gotoAndStop("groen2");
		this.stop();
	}
	this.frame_10 = function() {
		this.stop();
	}
	this.frame_11 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}
	this.frame_13 = function() {
		this.stop();
	}
	this.frame_14 = function() {
		this.stop();
	}
	this.frame_15 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
	}
	this.frame_17 = function() {
		this.stop();
	}
	this.frame_18 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_20 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}
	this.frame_22 = function() {
		this.stop();
	}
	this.frame_23 = function() {
		this.stop();
	}
	this.frame_24 = function() {
		this.stop();
	}
	this.frame_25 = function() {
		this.stop();
	}
	this.frame_26 = function() {
		this.stop();
	}
	this.frame_27 = function() {
		this.stop();
	}
	this.frame_28 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_30 = function() {
		this.stop();
	}
	this.frame_31 = function() {
		this.stop();
	}
	this.frame_32 = function() {
		this.stop();
	}
	this.frame_33 = function() {
		this.stop();
	}
	this.frame_34 = function() {
		this.stop();
	}
	this.frame_35 = function() {
		this.stop();
	}
	this.frame_36 = function() {
		this.stop();
	}
	this.frame_37 = function() {
		this.stop();
	}
	this.frame_38 = function() {
		this.stop();
	}
	this.frame_39 = function() {
		this.stop();
	}
	this.frame_40 = function() {
		this.stop();
	}
	this.frame_41 = function() {
		this.stop();
	}
	this.frame_42 = function() {
		this.stop();
	}
	this.frame_43 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}
	this.frame_45 = function() {
		this.stop();
	}
	this.frame_46 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}
	this.frame_48 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}
	this.frame_50 = function() {
		this.stop();
	}
	this.frame_51 = function() {
		this.stop();
	}
	this.frame_52 = function() {
		this.stop();
	}
	this.frame_53 = function() {
		this.stop();
	}
	this.frame_54 = function() {
		this.stop();
	}
	this.frame_55 = function() {
		this.stop();
	}
	this.frame_56 = function() {
		this.stop();
	}
	this.frame_57 = function() {
		this.stop();
	}
	this.frame_58 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}
	this.frame_60 = function() {
		this.stop();
	}
	this.frame_61 = function() {
		this.stop();
	}
	this.frame_62 = function() {
		this.stop();
	}
	this.frame_63 = function() {
		this.stop();
	}
	this.frame_64 = function() {
		this.stop();
	}
	this.frame_65 = function() {
		this.stop();
	}
	this.frame_66 = function() {
		this.stop();
	}
	this.frame_67 = function() {
		this.stop();
	}
	this.frame_68 = function() {
		this.stop();
	}
	this.frame_69 = function() {
		this.stop();
	}
	this.frame_70 = function() {
		this.stop();
	}
	this.frame_71 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}
	this.frame_73 = function() {
		this.stop();
	}
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1).call(this.frame_8).wait(1).call(this.frame_9).wait(1).call(this.frame_10).wait(1).call(this.frame_11).wait(1).call(this.frame_12).wait(1).call(this.frame_13).wait(1).call(this.frame_14).wait(1).call(this.frame_15).wait(1).call(this.frame_16).wait(1).call(this.frame_17).wait(1).call(this.frame_18).wait(1).call(this.frame_19).wait(1).call(this.frame_20).wait(1).call(this.frame_21).wait(1).call(this.frame_22).wait(1).call(this.frame_23).wait(1).call(this.frame_24).wait(1).call(this.frame_25).wait(1).call(this.frame_26).wait(1).call(this.frame_27).wait(1).call(this.frame_28).wait(1).call(this.frame_29).wait(1).call(this.frame_30).wait(1).call(this.frame_31).wait(1).call(this.frame_32).wait(1).call(this.frame_33).wait(1).call(this.frame_34).wait(1).call(this.frame_35).wait(1).call(this.frame_36).wait(1).call(this.frame_37).wait(1).call(this.frame_38).wait(1).call(this.frame_39).wait(1).call(this.frame_40).wait(1).call(this.frame_41).wait(1).call(this.frame_42).wait(1).call(this.frame_43).wait(1).call(this.frame_44).wait(1).call(this.frame_45).wait(1).call(this.frame_46).wait(1).call(this.frame_47).wait(1).call(this.frame_48).wait(1).call(this.frame_49).wait(1).call(this.frame_50).wait(1).call(this.frame_51).wait(1).call(this.frame_52).wait(1).call(this.frame_53).wait(1).call(this.frame_54).wait(1).call(this.frame_55).wait(1).call(this.frame_56).wait(1).call(this.frame_57).wait(1).call(this.frame_58).wait(1).call(this.frame_59).wait(1).call(this.frame_60).wait(1).call(this.frame_61).wait(1).call(this.frame_62).wait(1).call(this.frame_63).wait(1).call(this.frame_64).wait(1).call(this.frame_65).wait(1).call(this.frame_66).wait(1).call(this.frame_67).wait(1).call(this.frame_68).wait(1).call(this.frame_69).wait(1).call(this.frame_70).wait(1).call(this.frame_71).wait(1).call(this.frame_72).wait(1).call(this.frame_73).wait(1).call(this.frame_74).wait(1));

	// Layer_1
	this.verfpot = new lib.verfpot();
	this.verfpot.name = "verfpot";
	this.verfpot.setTransform(-0.05,0.05,0.516,0.516,0,0,0,-1.4,-4.5);

	this.instance = new lib.helmsymb();
	this.instance.setTransform(1,-10,0.2892,0.2892,0,0,0,173.1,121);

	this.instance_1 = new lib.Bitmap902();
	this.instance_1.setTransform(-52,-47);

	this.instance_2 = new lib.Bitmap907();
	this.instance_2.setTransform(-56,-55);

	this.instance_3 = new lib.riemmetachter();
	this.instance_3.setTransform(1,0,0.2623,0.2623);

	this.instance_4 = new lib.Bitmap874();
	this.instance_4.setTransform(-47,-23);

	this.instance_5 = new lib.Bitmap875();
	this.instance_5.setTransform(-24,-48);

	this.instance_6 = new lib.riembreedmetachter();
	this.instance_6.setTransform(1.1,1.15,0.2793,0.2793,0,0,0,-2.7,9.3);

	this.instance_7 = new lib.Bitmap876();
	this.instance_7.setTransform(-49,-32);

	this.instance_8 = new lib.Bitmap877();
	this.instance_8.setTransform(-34,-49);

	this.instance_9 = new lib.trash();
	this.instance_9.setTransform(0,1.45,0.3858,0.3858);

	this.instance_10 = new lib.mutsonder();
	this.instance_10.setTransform(0.45,-4.95,0.218,0.218,0,0,0,0.5,-24.3);

	this.instance_11 = new lib.Bitmap878();
	this.instance_11.setTransform(-40,-63);

	this.instance_12 = new lib.mutsboven();
	this.instance_12.setTransform(-1,-5.9,0.2125,0.2125,0,0,0,-9,-120.2);

	this.instance_13 = new lib.Bitmap879();
	this.instance_13.setTransform(-35,-42);

	this.instance_14 = new lib.steekmessymb();
	this.instance_14.setTransform(4.3,-3.15);

	this.instance_15 = new lib.graszaad();
	this.instance_15.setTransform(0.55,0);

	this.instance_16 = new lib.gieter();
	this.instance_16.setTransform(-4.2,-0.3);

	this.instance_17 = new lib.bloemwitzaad();
	this.instance_17.setTransform(0.55,0);

	this.instance_18 = new lib.bloemblauwzaad();
	this.instance_18.setTransform(0.55,0);

	this.instance_19 = new lib.mutsrechts();
	this.instance_19.setTransform(8.25,-0.6,2.8482,2.8482,0,0,0,10.6,18.2);

	this.instance_20 = new lib.Bitmap905();
	this.instance_20.setTransform(-25,-54);

	this.instance_21 = new lib.mutslinksmetachter();
	this.instance_21.setTransform(-15.9,-0.55);

	this.instance_22 = new lib.Bitmap906();
	this.instance_22.setTransform(-41,-53);

	this.instance_23 = new lib.symbzorrolintjes();
	this.instance_23.setTransform(-5.95,-0.65);

	this.instance_24 = new lib.Bitmap910();
	this.instance_24.setTransform(-56,-32);

	this.instance_25 = new lib.riem11toolb();
	this.instance_25.setTransform(1.55,4.25);

	this.instance_26 = new lib.Bitmap911();
	this.instance_26.setTransform(-53,-27);

	this.instance_27 = new lib.Bitmap912();
	this.instance_27.setTransform(-49,-52);

	this.instance_28 = new lib.Bitmap913();
	this.instance_28.setTransform(-52,-49);

	this.instance_29 = new lib.symbskibriltoolbal();
	this.instance_29.setTransform(-1.2,1.5);

	this.instance_30 = new lib.Bitmap914();
	this.instance_30.setTransform(-58,-31);

	this.instance_31 = new lib.symbskibrilkleintools();
	this.instance_31.setTransform(-2.65,1.5);

	this.instance_32 = new lib.Bitmap915();
	this.instance_32.setTransform(-58,-20);

	this.instance_33 = new lib.symbskibrilklein12tools();
	this.instance_33.setTransform(-2.65,1.5);

	this.instance_34 = new lib.Bitmap916();
	this.instance_34.setTransform(-56,-19);

	this.instance_35 = new lib.riem13tool();
	this.instance_35.setTransform(-5,-0.65);

	this.instance_36 = new lib.Bitmap917();
	this.instance_36.setTransform(-25,-54);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.verfpot}]}).to({state:[]},10).to({state:[{t:this.instance,p:{regX:173.1,regY:121,rotation:0,x:1,y:-10}}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance,p:{regX:173.3,regY:120.9,rotation:6.1302,x:0,y:-13.75}}]},1).to({state:[{t:this.instance_2}]},1).to({state:[]},1).to({state:[{t:this.instance_3,p:{rotation:0}}]},8).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_3,p:{rotation:90}}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6,p:{rotation:0,x:1.1}}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_6,p:{rotation:90,x:-1.4}}]},1).to({state:[{t:this.instance_8}]},1).to({state:[]},1).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[]},1).to({state:[{t:this.instance_14}]},3).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[]},1).to({state:[{t:this.instance_17}]},4).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[]},1).to({state:[{t:this.instance_23}]},4).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25,p:{rotation:0,x:1.55,y:4.25}}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_25,p:{rotation:131.544,x:-3.45,y:-3.75}}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_25,p:{rotation:42.8556,x:-3.95,y:4.25}}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-63,121,123.7);


(lib.toolbal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.toolsmovie = new lib.toolsmovie();
	this.toolsmovie.name = "toolsmovie";
	this.toolsmovie.setTransform(-1,1.05);

	this.timeline.addTween(cjs.Tween.get(this.toolsmovie).wait(1));

	// Layer_1
	this.toolbalmovie = new lib.toolbal_movie();
	this.toolbalmovie.name = "toolbalmovie";

	this.timeline.addTween(cjs.Tween.get(this.toolbalmovie).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.toolbal, new cjs.Rectangle(-62.5,-62.5,125,125), null);


(lib.swc_doos3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"open":0,"toe":1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_21 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(21).call(this.frame_21).wait(1));

	// bladbal
	this.doosbal = new lib.levelbal();
	this.doosbal.name = "doosbal";
	this.doosbal.setTransform(-37.1,25.75,0.1625,0.1671,0,-2.905,0.4466);

	this.timeline.addTween(cjs.Tween.get(this.doosbal).wait(22));

	// blad
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AktDpIgjrcIKiDSIgKMVg");
	this.shape.setTransform(-38,26.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(22));

	// flaprechts
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F6D4A1").s().p("ApAByILTkxIGuAtIqjFSg");
	this.shape_1.setTransform(59.175,-21.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EFCD9A").s().p("ACyiJIFwgeIqjE5ImfAWg");
	this.shape_2.setTransform(56.05,-26.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EBCB97").s().p("ACshdIF8h1IqjE4ImsBug");
	this.shape_3.setTransform(56.675,-31.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EBC996").s().p("ACshKIF8ibIqjE4ImsCTg");
	this.shape_4.setTransform(56.675,-33.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C8A673").s().p("AjSAyILAkhIkLClIrQE6g");
	this.shape_5.setTransform(50.875,-32.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#BF9F6B").s().p("AjlgLILmkiIkxEiIrPE6g");
	this.shape_6.setTransform(52.75,-39);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C5A571").s().p("AkjhKILlkiIi0GeIrPE7g");
	this.shape_7.setTransform(46.5,-45.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C2A06D").s().p("AmVhKILlkiIBGGeIrPE7g");
	this.shape_8.setTransform(32.9,-45.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C3A16E").s().p("AntgYILlkiID2E6IrPE7g");
	this.shape_9.setTransform(24.15,-40.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#C19F6C").s().p("AoTAMILmkhIFADxIrPE6g");
	this.shape_10.setTransform(20.4,-36.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C6A672").s().p("AorAyILlkhIFyClIrPE6g");
	this.shape_11.setTransform(17.9,-32.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C6A672").s().p("AorBLILlkhIFyBzIrPE6g");
	this.shape_12.setTransform(17.9,-30.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},11).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).wait(1));

	// flapvoor
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D3B17E").s().p("AlRArIhrk6IMkC3IBVFog");
	this.shape_13.setTransform(-42.85,-36.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D2B07D").s().p("AmnArIArk6IMkC3IhBFog");
	this.shape_14.setTransform(-34.25,-36.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CAAA76").s().p("AnZArICPk6IMkC3IilFog");
	this.shape_15.setTransform(-29.25,-36.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D1B17D").s().p("AokASIElkIIMkC3Ik7E2g");
	this.shape_16.setTransform(-21.75,-34.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#DCBA87").s().p("ApWgGIGJjXIMkC3ImfEEg");
	this.shape_17.setTransform(-16.75,-31.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CDAB78").s().p("ApWg0IGlh7IMICbImfDDg");
	this.shape_18.setTransform(-16.75,-26.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13}]}).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).wait(17));

	// Layer_1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E8C894").s().p("AFbJEIjyheInAjGQgGgFgBgFIgBgIIgBgIIgmtQIMNDiIgSOzg");
	this.shape_19.setTransform(-37.675,26.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#C19F6C").s().p("AlflCILQkvIgwMeIgSATIqgGyg");
	this.shape_20.setTransform(36.6,22.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19}]}).wait(22));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.3,-81.7,204.2,166.5);


(lib.instructiemov1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6
	this.klik2 = new lib.snklik2();
	this.klik2.name = "klik2";
	this.klik2.setTransform(1.95,24.2,0.8568,0.8571);

	this.timeline.addTween(cjs.Tween.get(this.klik2).wait(1));

	// Layer_7
	this.klik = new lib.sncli();
	this.klik.name = "klik";
	this.klik.setTransform(-0.65,-25.6);

	this.timeline.addTween(cjs.Tween.get(this.klik).wait(1));

	// Layer_3
	this.instance = new lib.symb_muis();
	this.instance.setTransform(10.1,13.75,1,1,-39.7261);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.bal2 = new lib.levelbal();
	this.bal2.name = "bal2";
	this.bal2.setTransform(44.25,-1.75,0.0569,0.0572,0,0,0,-30.8,-30.6);

	this.bal1 = new lib.levelbal();
	this.bal1.name = "bal1";
	this.bal1.setTransform(-47.75,-1.75,0.0569,0.0572,0,0,0,-30.8,-30.6);

	this.tool = new lib.toolbal();
	this.tool.name = "tool";
	this.tool.setTransform(0,0,0.288,0.288);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.tool},{t:this.bal1},{t:this.bal2}]}).wait(1));

	// Layer_4
	this.instance_1 = new lib.ppijlplay();
	this.instance_1.setTransform(26,0,0.2188,0.2195);

	this.instance_2 = new lib.ppijlplay();
	this.instance_2.setTransform(-26,0,0.2188,0.2195);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339999").s().p("Am5G6Qi3i3AAkDQAAkCC3i3QC3i3ECAAQEDAAC3C3QC3C3AAECQAAEDi3C3Qi3C3kDAAQkCAAi3i3g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.instructiemov1, new cjs.Rectangle(-62.5,-62.5,125,125), null);


// stage content:
(lib.factoryballsforever = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{preintro:1,menu:2,game:3,einde:4,veryend:5});

	// timeline functions:
	this.frame_0 = function() {
		this.theplaybuttonsound.cursor="pointer";
		this.theplaybuttonsound.addEventListener("click",theplayClickEvent);
		this.stop();
		stage.enableMouseOver(20);
		var sceneScherm=this;
		
		function theplayClickEvent(e) {
			sceneScherm.theplaybuttonsound.removeEventListener("click",theplayClickEvent);
			sceneScherm.gotoAndStop("preintro");
		}
	}
	this.frame_1 = function() {
		var sceneScherm=this;
		var itel=0;
		this.mysong;
		this.hoogste=1;
		this.soundon=true;
		this.musicon=true;
		
		this.stop();
		stage.enableMouseOver(20);
		createjs.Ticker.addEventListener("tick",preintroChecker);
		
		function preintroChecker(e) {
			itel++;
			if (itel==1) {
		
				try {
				if (localStorage['thefblevel']) {
					if (localStorage['thefblevel']==1) sceneScherm.hoogste=1;
					else if (localStorage['thefblevel']==2) sceneScherm.hoogste=2;
					else if (localStorage['thefblevel']==3) sceneScherm.hoogste=3;
					else if (localStorage['thefblevel']==4) sceneScherm.hoogste=4;
					else if (localStorage['thefblevel']==5) sceneScherm.hoogste=5;
					else if (localStorage['thefblevel']==6) sceneScherm.hoogste=6;
					else if (localStorage['thefblevel']==7) sceneScherm.hoogste=7;
					else if (localStorage['thefblevel']==8) sceneScherm.hoogste=8;
					else if (localStorage['thefblevel']==9) sceneScherm.hoogste=9;
					else if (localStorage['thefblevel']==10) sceneScherm.hoogste=10;
					else if (localStorage['thefblevel']==11) sceneScherm.hoogste=11;
					else if (localStorage['thefblevel']==12) sceneScherm.hoogste=12;
					else if (localStorage['thefblevel']==13) sceneScherm.hoogste=13;
					else if (localStorage['thefblevel']==14) sceneScherm.hoogste=14;
					else if (localStorage['thefblevel']==15) sceneScherm.hoogste=15;
					else if (localStorage['thefblevel']==16) sceneScherm.hoogste=16;
					else if (localStorage['thefblevel']==17) sceneScherm.hoogste=17;
					else if (localStorage['thefblevel']==18) sceneScherm.hoogste=18;
					else if (localStorage['thefblevel']==19) sceneScherm.hoogste=19;
					else if (localStorage['thefblevel']==20) sceneScherm.hoogste=20;
					else if (localStorage['thefblevel']==21) sceneScherm.hoogste=21;
					else if (localStorage['thefblevel']==22) sceneScherm.hoogste=22;
					else if (localStorage['thefblevel']==23) sceneScherm.hoogste=23;
					else if (localStorage['thefblevel']==24) sceneScherm.hoogste=24;
					else if (localStorage['thefblevel']==25) sceneScherm.hoogste=25;
					else if (localStorage['thefblevel']==26) sceneScherm.hoogste=26;
					else if (localStorage['thefblevel']==27) sceneScherm.hoogste=27;
					else if (localStorage['thefblevel']==28) sceneScherm.hoogste=28;
					else if (localStorage['thefblevel']==29) sceneScherm.hoogste=29;
					else if (localStorage['thefblevel']==30) sceneScherm.hoogste=30;
				}
				} catch(err) {}
				
			}
			if (itel==2) {
				createjs.Ticker.removeEventListener("tick",preintroChecker);
				sceneScherm.gotoAndStop("menu");
			}
			
		}
	}
	this.frame_2 = function() {
		var sceneScherm=this;
		var pauzetel=44;
		var animteller=0;
		this.lvl=1;
		this.aantallevels=25;
		
		this.spr_buttonnewplay.playtxt.visible = false;
		this.spr_buttonnewplay.visible = false;
		this.spr_buttoncontinue.visible = false;
		this.spr_buttonlinks.visible = false;
		this.spr_buttonrechts.visible = false;
		
		this.spr_buttonmusic.ontxt.visible = true;
		this.spr_buttonmusic.offtxt.visible = false;
		this.spr_buttonsound.ontxt.visible = true;
		this.spr_buttonsound.offtxt.visible = false;
		
		this.stop();
		stage.enableMouseOver(20);
		this.spr_buttonnewplay.cursor="pointer";
		this.spr_buttonnewplay.addEventListener("click",onNewPlayClickEvent);
		this.spr_buttonmusic.cursor="pointer";
		this.spr_buttonmusic.addEventListener("click",onMusicClickEvent);
		this.spr_buttonsound.cursor="pointer";
		this.spr_buttonsound.addEventListener("click",onSoundClickEvent);
		this.buttonwww.cursor="pointer";
		this.buttonwww.addEventListener("click",onWwwClickEvent);
		this.buttontwitter.cursor="pointer";
		this.buttontwitter.addEventListener("click",onTwitterClickEvent);
		this.buttoninstagram.cursor="pointer";
		this.buttoninstagram.addEventListener("click",onInstagramClickEvent);
		this.buttonfacebook.cursor="pointer";
		this.buttonfacebook.addEventListener("click",onFacebookClickEvent);
		this.bolsteam.cursor="pointer";
		this.bolsteam.addEventListener("click",onSteamClickEvent);
		this.bolitchio.cursor="pointer";
		this.bolitchio.addEventListener("click",onItchioClickEvent);
		this.bolkartridge.cursor="pointer";
		this.bolkartridge.addEventListener("click",onKartridgeClickEvent);
		this.bolapple.cursor="pointer";
		this.bolapple.addEventListener("click",onAppleClickEvent);
		this.bolgoogle.cursor="pointer";
		this.bolgoogle.addEventListener("click",onGoogleClickEvent);
		createjs.Ticker.addEventListener("tick",menuChecker);
		
		function menuChecker(e) {
			pauzetel--;
			if (pauzetel==43) {
				if (sceneScherm.musicon) {
					sceneScherm.spr_buttonmusic.ontxt.visible = true;
					sceneScherm.spr_buttonmusic.offtxt.visible = false;
				} else {
					sceneScherm.spr_buttonmusic.ontxt.visible = false;
					sceneScherm.spr_buttonmusic.offtxt.visible = true;
				}
				if (sceneScherm.soundon) {
					sceneScherm.spr_buttonsound.ontxt.visible = true;
					sceneScherm.spr_buttonsound.offtxt.visible = false;
				} else {
					sceneScherm.spr_buttonsound.ontxt.visible = false;
					sceneScherm.spr_buttonsound.offtxt.visible = true;
				}
				sceneScherm.spr_buttonmusic.visible=true;
				sceneScherm.spr_buttonsound.visible=true;
				sceneScherm.buttonwww.visible=true;
				sceneScherm.buttontwitter.visible=true;
				sceneScherm.buttoninstagram.visible=true;
				sceneScherm.buttonfacebook.visible=true;
				sceneScherm.abbgam.visible=true;
				sceneScherm.makeyours.visible=true;
				sceneScherm.bolsteam.visible=true;
				sceneScherm.bolitchio.visible=true;
				sceneScherm.bolkartridge.visible=true;
				sceneScherm.bolapple.visible=true;
				sceneScherm.bolgoogle.visible=true;
				if (sceneScherm.musicon) sceneScherm.mysong=createjs.Sound.play ("fbSong",{interrupt: createjs.Sound.INTERRUPT_ANY,loop: -1});
			} else if (pauzetel=42) {
				createjs.Ticker.removeEventListener("tick",menuChecker);
				animteller = 8;
				createjs.Ticker.addEventListener("tick",menuLoop);
			}
		}
		
		function menuLoop(e) {
			if (animteller == 10) {
				sceneScherm.spr_buttonnewplay.visible=true;
				sceneScherm.spr_buttonnewplay.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 18) {
				sceneScherm.spr_buttonnewplay.playtxt.visible = true;
				createjs.Ticker.removeEventListener("tick",menuLoop);
			}
			animteller++;
		}
		
		function onNewPlayClickEvent(e) {
			if (animteller>18) {
				sceneScherm.spr_buttonnewplay.removeEventListener("click",onNewPlayClickEvent);
				sceneScherm.spr_buttonmusic.removeEventListener("click",onMusicClickEvent);
				sceneScherm.spr_buttonsound.removeEventListener("click",onSoundClickEvent);
				sceneScherm.spr_buttonmusic.visible=false;
				sceneScherm.spr_buttonsound.visible=false;
				sceneScherm.buttonwww.removeEventListener("click",onWwwClickEvent);
				sceneScherm.buttontwitter.removeEventListener("click",onTwitterClickEvent);
				sceneScherm.buttoninstagram.removeEventListener("click",onInstagramClickEvent);
				sceneScherm.buttonfacebook.removeEventListener("click",onFacebookClickEvent);
				sceneScherm.buttonwww.visible=false;
				sceneScherm.buttontwitter.visible=false;
				sceneScherm.buttoninstagram.visible=false;
				sceneScherm.buttonfacebook.visible=false;
				sceneScherm.abbgam.visible=false;
				sceneScherm.bolsteam.removeEventListener("click",onSteamClickEvent);
				sceneScherm.bolitchio.removeEventListener("click",onItchioClickEvent);
				sceneScherm.bolkartridge.removeEventListener("click",onKartridgeClickEvent);
				sceneScherm.bolapple.removeEventListener("click",onAppleClickEvent);
				sceneScherm.bolgoogle.removeEventListener("click",onGoogleClickEvent);
				sceneScherm.makeyours.visible=false;
				sceneScherm.bolsteam.visible=false;
				sceneScherm.bolitchio.visible=false;
				sceneScherm.bolkartridge.visible=false;
				sceneScherm.bolapple.visible=false;
				sceneScherm.bolgoogle.visible=false;
				animteller = 0;
				createjs.Ticker.addEventListener("tick",endMenuLoopPackSelect);
			}
		}
		function onMusicClickEvent(e) {
			if (sceneScherm.musicon) {
				sceneScherm.musicon = false;
				sceneScherm.mysong.stop();
				sceneScherm.mysong=null;
				sceneScherm.spr_buttonmusic.ontxt.visible = false;
				sceneScherm.spr_buttonmusic.offtxt.visible = true;
			} else {
				sceneScherm.musicon = true;
				sceneScherm.mysong=createjs.Sound.play ("fbSong",{interrupt: createjs.Sound.INTERRUPT_ANY,loop: -1});
				sceneScherm.spr_buttonmusic.ontxt.visible = true;
				sceneScherm.spr_buttonmusic.offtxt.visible = false;
			}
		}
		function onSoundClickEvent(e) {
			if (sceneScherm.soundon) {
				sceneScherm.soundon = false;
				sceneScherm.spr_buttonsound.ontxt.visible = false;
				sceneScherm.spr_buttonsound.offtxt.visible = true;
			} else {
				sceneScherm.soundon = true;
				sceneScherm.spr_buttonsound.ontxt.visible = true;
				sceneScherm.spr_buttonsound.offtxt.visible = false;
			}
		}
		function onWwwClickEvent(e) {
			window.open("https://www.engineering.com");
		}
		function onTwitterClickEvent(e) {
			window.open("https://twitter.com/engineeringcom");
		}
		function onInstagramClickEvent(e) {
			window.open("https://www.instagram.com/engineeringdotcom/");
		}
		function onFacebookClickEvent(e) {
			window.open("https://www.facebook.com/engineeringcom/");
		}
		function onSteamClickEvent(e) {
			window.open("https://store.steampowered.com/app/1054660/Factory_Balls");
		}
		function onItchioClickEvent(e) {
			window.open("https://bartbonte.itch.io/factory-balls");
		}
		function onKartridgeClickEvent(e) {
			window.open("https://www.kartridge.com/games/bontegames/factory-balls");
		}
		function onAppleClickEvent(e) {
			window.open("https://itunes.apple.com/us/app/factory-balls-official/id641519483");
		}
		function onGoogleClickEvent(e) {
			window.open("https://play.google.com/store/apps/details?id=air.air.FactoryBalls");
		}
			
		function endMenuLoopPackSelect(e) {
			if (animteller == 0) {
				sceneScherm.spr_buttonnewplay.playtxt.visible = false;
				sceneScherm.spr_buttonnewplay.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 6) {
				sceneScherm.spr_buttonnewplay.visible=false;
			} else if (animteller == 12) {
				createjs.Ticker.removeEventListener("tick",endMenuLoopPackSelect);
				animteller = -2;
				if (sceneScherm.hoogste > 1) {
					createjs.Ticker.addEventListener("tick",doosDownLoop);
				} else {
					createjs.Ticker.addEventListener("tick",noLevelSelect);
				}
			}
			animteller++;
		}
		
		function noLevelSelect(e) {
			createjs.Ticker.removeEventListener("tick",noLevelSelect);
			sceneScherm.gotoAndStop("game");
		}
		
		function doosDownLoop(e) {
			createjs.Ticker.removeEventListener("tick",doosDownLoop);
			animteller=0;
			createjs.Ticker.addEventListener("tick",initLevelSelect);
		}
		
		function initLevelSelect(e) {
			if (animteller==0) {
				sceneScherm.spr_buttoncontinue.leveltxt.visible = false;
				sceneScherm.spr_buttoncontinue.leveltxt.gotoAndStop(45 - sceneScherm.hoogste -1);
				sceneScherm.spr_buttoncontinue.cursor="pointer";
				sceneScherm.spr_buttoncontinue.addEventListener("click",onContinueClickEvent);
				sceneScherm.spr_buttonlinks.pijl.visible = false;
				sceneScherm.spr_buttonlinks.cursor="pointer";
				sceneScherm.spr_buttonlinks.addEventListener("click",onLinksClickEvent);
				sceneScherm.spr_buttonrechts.pijl.visible = false;
				sceneScherm.spr_buttonrechts.cursor="pointer";
				sceneScherm.spr_buttonrechts.addEventListener("click",onRechtsClickEvent);
				sceneScherm.spr_buttonlinks.visible=true;
				sceneScherm.spr_buttonlinks.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 6) {
				sceneScherm.spr_buttoncontinue.visible=true;
				sceneScherm.spr_buttoncontinue.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 8) {
				sceneScherm.spr_buttonlinks.pijl.visible = true;
			} else if (animteller == 12) {
				sceneScherm.spr_buttonrechts.visible=true;
				sceneScherm.spr_buttonrechts.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 16) {
				sceneScherm.spr_buttoncontinue.leveltxt.visible = true;
			} else if (animteller == 24) {
				sceneScherm.spr_buttonrechts.pijl.visible = true;
			}
			animteller++;
		}
		
		function onLinksClickEvent(e) {
			if (sceneScherm.spr_buttoncontinue.leveltxt.currentFrame < (44-1)) {
				sceneScherm.spr_buttoncontinue.leveltxt.gotoAndStop(sceneScherm.spr_buttoncontinue.leveltxt.currentFrame + 1);
			}
		}
		function onRechtsClickEvent(e) {
			if (sceneScherm.spr_buttoncontinue.leveltxt.currentFrame > (1-1) && sceneScherm.spr_buttoncontinue.leveltxt.currentFrame > (45 - sceneScherm.hoogste -1)) {
				sceneScherm.spr_buttoncontinue.leveltxt.gotoAndStop(sceneScherm.spr_buttoncontinue.leveltxt.currentFrame-1);
			}
		}
		function onContinueClickEvent(e) {
			if (animteller>24) {
				sceneScherm.lvl = 45 - sceneScherm.spr_buttoncontinue.leveltxt.currentFrame -1;
				sceneScherm.spr_buttoncontinue.removeEventListener("click",onContinueClickEvent);
				sceneScherm.spr_buttonlinks.removeEventListener("click",onLinksClickEvent);
				sceneScherm.spr_buttonrechts.removeEventListener("click",onRechtsClickEvent);
				createjs.Ticker.removeEventListener("tick",initLevelSelect);
				animteller = -1;
				createjs.Ticker.addEventListener("tick",endLevelSelect);
			}
		}
		
		function endLevelSelect() {
			if (animteller == 0) {
				sceneScherm.spr_buttonlinks.pijl.visible = false;
				sceneScherm.spr_buttonlinks.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 6) {
				sceneScherm.spr_buttonlinks.visible=false;
				sceneScherm.spr_buttoncontinue.leveltxt.visible = false;
				sceneScherm.spr_buttoncontinue.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 12) {
				sceneScherm.spr_buttoncontinue.visible=false;
				sceneScherm.spr_buttonrechts.pijl.visible = false;
				sceneScherm.spr_buttonrechts.toolbalmovie.gotoAndPlay(1);
			} else if (animteller == 18) {
				sceneScherm.spr_buttonrechts.visible=false;
			} else if (animteller == 20) {
				createjs.Ticker.removeEventListener("tick",endLevelSelect);
				sceneScherm.gotoAndStop("game");
			}
			animteller++;
		}
	}
	this.frame_3 = function() {
		var sceneScherm=this;
		var pauzetel=0;
		var nrlevelbal=0;
		var nbrtools=0;
		var tool1="";
		var tool2="";
		var tool3="";
		var tool4="";
		var tool5="";
		var tool6="";
		var tool7="";
		var tool8="";
		var tool9="";
		var tool10="";
		var tool11="";
		var toolbalx1;
		var toolbaly1;
		var toolbalx2;
		var toolbaly2;
		var toolbalx3;
		var toolbaly3;
		var toolbalx4;
		var toolbaly4;
		var toolbalx5;
		var toolbaly5;
		var toolbalx6;
		var toolbaly6;
		var toolbalx7;
		var toolbaly7;
		var toolbalx8;
		var toolbaly8;
		var toolbalx9;
		var toolbaly9;
		var toolbalx10;
		var toolbaly10;
		var toolbalx11;
		var toolbaly11;
		var toolstack;
		var laag1="";
		var laag2="";
		var laag3="";
		var rechtsvoor=false;
		var riemiserl = false;
		var riemiserr = false;
		var riemiser = false;
		var linksvoor = false;
		var toolupdated;
		var balorigx;
		var balorigy;
		var balschuifteller = 0;
		var toolusednow;
		var toolxnow;
		var toolynow;
		var tweenlenxnow;
		var tweenlenynow;
		var kleur="";
		var stateLevelLoop=false;
		var instructieteller = 0;
		var animinstr = 0;
		
		var balcentraalx = 480;
		var balcentraaly = 468;
		var tweenarray11=[1180,1084,994,912,837,769,709,655,609,569,537,512,494,484,480];
		var tweenarray1=[1180,1084,994,912,837,769,709,655,609,569,537,512,494,484,480];
		var tweenarray22=[1026,949,878,812,753,699,650,607,570,539,514,494,479,471,468];
		var tweenarray2=[1026,949,878,812,753,699,650,607,570,539,514,494,479,471,468];
		var tweenarray3=[882,831,786,747,714,687,666,651,642,639];
		
		this.stop();
		stage.enableMouseOver(20);
		this.toolbal1.cursor="pointer";this.toolbal1.addEventListener("click",onTool1ClickEvent);
		this.toolbal2.cursor="pointer";this.toolbal2.addEventListener("click",onTool2ClickEvent);
		this.toolbal3.cursor="pointer";this.toolbal3.addEventListener("click",onTool3ClickEvent);
		this.toolbal4.cursor="pointer";this.toolbal4.addEventListener("click",onTool4ClickEvent);
		this.toolbal5.cursor="pointer";this.toolbal5.addEventListener("click",onTool5ClickEvent);
		this.toolbal6.cursor="pointer";this.toolbal6.addEventListener("click",onTool6ClickEvent);
		this.toolbal7.cursor="pointer";this.toolbal7.addEventListener("click",onTool7ClickEvent);
		this.toolbal8.cursor="pointer";this.toolbal8.addEventListener("click",onTool8ClickEvent);
		this.toolbal9.cursor="pointer";this.toolbal9.addEventListener("click",onTool9ClickEvent);
		this.toolbal10.cursor="pointer";this.toolbal10.addEventListener("click",onTool10ClickEvent);
		this.toolbal11.cursor="pointer";this.toolbal11.addEventListener("click",onTool11ClickEvent);
		this.spr_buttonquit.cursor="pointer";this.spr_buttonquit.addEventListener("click",onQuitgameClickEvent);
		createjs.Ticker.addEventListener("tick",gameLoop);
		
		function gameLoop(e) {
			if (sceneScherm.lvl == 1) instructieLogic();
			if (pauzetel==0) {
				sceneScherm.spr_fblevel.leveltxt.gotoAndStop(45 - sceneScherm.lvl -1);
				sceneScherm.spr_bal.x=1180;
				sceneScherm.spr_bal.y=536;
				sceneScherm.spr_doosvoor.x=1180;
				sceneScherm.spr_doosvoor.y=536;
				sceneScherm.spr_doos.x=1180;
				sceneScherm.spr_doos.y=536;
				sceneScherm.balcentraal.x=480;
				sceneScherm.balcentraal.y=1026;
				toolstack = new Array();
				sceneScherm.spr_instructie.visible=false;
				if (sceneScherm.lvl==1) {
					sceneScherm.spr_instructie.y = 882;
					sceneScherm.spr_instructie.visible=true;
					sceneScherm.spr_instructie.klik2.visible=false;
					nrlevelbal = 1;
					nbrtools = 3;
					tool1 = "verforanje";
					tool2 = "verfblauw";
					tool3 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(0);
					sceneScherm.spr_doosvoor.doosbal.helm.visible = false;
					sceneScherm.spr_doosvoor.doosbal.p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.p2.gotoAndStop("oranje");
				} else if (sceneScherm.lvl==2) {
					nrlevelbal = 9;
					nbrtools = 3;
					tool1 = "verfgeel";
					tool2 = "verfzwart";
					tool3 = "skibrilklein";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(8);
					sceneScherm.spr_doosvoor.doosbal.b9helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b9skibril.visible = false;sceneScherm.spr_doosvoor.doosbal.b9skibrilklein.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b9riem1.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem2.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem3.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem4.visible=false;
					sceneScherm.spr_doosvoor.doosbal.b9p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b9p2.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b9p3.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b9p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p6.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b9p7.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p8.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p11.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p13.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p14.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p15.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b9p16.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b9p17.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b9p18.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b9p19.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p20.gotoAndStop("geel");
				} else if (sceneScherm.lvl==3) {
					nrlevelbal = 3;
					nbrtools = 5;
					tool1 = "verfgeel";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "riembreed";
					tool5 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(2);
					sceneScherm.spr_doosvoor.doosbal.b3helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed0.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv2.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b3p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p3.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b3p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p6.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p7.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p8.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p9.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p10.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p11.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p12.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p13.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p14.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p15.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p16.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p17.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p18.gotoAndStop("zwart");
				} else if (sceneScherm.lvl==4) {
					nrlevelbal = 9;
					nbrtools = 4;
					tool1 = "verfrood";
					tool2 = "verfzwart";
					tool3 = "skibril";
					tool4 = "skibrilklein";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(8);
					sceneScherm.spr_doosvoor.doosbal.b9helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b9skibril.visible = false;sceneScherm.spr_doosvoor.doosbal.b9skibrilklein.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b9riem1.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem2.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem3.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem4.visible=false;
					sceneScherm.spr_doosvoor.doosbal.b9p1.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b9p2.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b9p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p4.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p5.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p6.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b9p7.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p8.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p11.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p13.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p14.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p15.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b9p16.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b9p17.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b9p18.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p19.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p20.gotoAndStop("zwart");
				} else if (sceneScherm.lvl==5) {
					nrlevelbal = 8;
					nbrtools = 5;
					tool1 = "verfrood";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "rieml";
					tool5 = "riemr";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(7);
					sceneScherm.spr_doosvoor.doosbal.b8riemr.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2.visible = false;sceneScherm.spr_doosvoor.doosbal.b8helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b8riemrboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1boven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2boven.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b8p1.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p2.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p3.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b8p4.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p5.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p6.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b8p7.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p8.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p10.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p11.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p13.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p14.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p15.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p16.gotoAndStop("zwart");
				} else if (sceneScherm.lvl==6) {
					nrlevelbal = 4;
					nbrtools = 5;
					tool1 = "verfgeel";
					tool2 = "verfrood";
					tool3 = "verfblauw";
					tool4 = "mutsonder";
					tool5 = "mutsboven";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(3);
					sceneScherm.spr_doosvoor.doosbal.b4helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b4mutsonder.visible = false;sceneScherm.spr_doosvoor.doosbal.b4mutsboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b4phonelinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b4phonerechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riemvoor.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riemv.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b4p1.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b4p2.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b4p3.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b4p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p6.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p7.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p8.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p9.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b4p10.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p11.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p12.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p13.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p14.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p15.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p16.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p17.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b4p18.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b4p19.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p20.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p21.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p22.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==7) {
					nrlevelbal = 3;
					nbrtools = 6;
					tool1 = "verfgeel";
					tool2 = "verfzwart";
					tool3 = "verforanje";
					tool4 = "verfblauw";
					tool5 = "riembreed";
					tool6 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(2);
					sceneScherm.spr_doosvoor.doosbal.b3helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed0.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv2.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b3p1.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p2.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b3p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p6.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p7.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p8.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p9.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p10.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p11.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p12.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b3p13.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p14.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p15.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b3p16.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p17.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p18.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==8) {
					nrlevelbal = 7;
					nbrtools = 5;
					tool1 = "verfrood";
					tool2 = "verfgeel";
					tool3 = "verfzwart";
					tool4 = "zorro";
					tool5 = "riem11";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(6);
					sceneScherm.spr_doosvoor.doosbal.b7zorro.visible = false;sceneScherm.spr_doosvoor.doosbal.b7helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein3.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b7p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p2.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p3.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b7p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b7p5.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b7p6.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b7p7.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p8.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p11.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p13.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p14.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p15.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b7p16.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b7p17.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p18.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b7p19.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p20.gotoAndStop("geel");
				} else if (sceneScherm.lvl==9) {
					nrlevelbal = 8;
					nbrtools = 6;
					tool1 = "verforanje";
					tool2 = "verfmagenta";
					tool3 = "verfblauw";
					tool4 = "rieml";
					tool5 = "riemr";
					tool6 = "bin";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(7);
					sceneScherm.spr_doosvoor.doosbal.b8riemr.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2.visible = false;sceneScherm.spr_doosvoor.doosbal.b8helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b8riemrboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1boven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2boven.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b8p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b8p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b8p3.gotoAndStop("paars");
					sceneScherm.spr_doosvoor.doosbal.b8p4.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b8p5.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p6.gotoAndStop("wit");
					sceneScherm.spr_doosvoor.doosbal.b8p7.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b8p8.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p9.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b8p10.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b8p11.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b8p12.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b8p13.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b8p14.gotoAndStop("paars"); sceneScherm.spr_doosvoor.doosbal.b8p15.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b8p16.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==10) {
					nrlevelbal = 9;
					nbrtools = 6;
					tool1 = "verfrood";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "skibril";
					tool5 = "skibrilklein";
					tool6 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(8);
					sceneScherm.spr_doosvoor.doosbal.b9helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b9skibril.visible = false;sceneScherm.spr_doosvoor.doosbal.b9skibrilklein.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b9riem1.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem2.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem3.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem4.visible=false;
					sceneScherm.spr_doosvoor.doosbal.b9p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b9p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b9p3.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b9p4.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b9p5.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p6.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b9p7.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p8.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p11.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b9p12.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b9p13.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p14.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b9p15.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b9p16.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b9p17.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b9p18.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b9p19.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b9p20.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==11) {
					nrlevelbal = 3;
					nbrtools = 5;
					tool1 = "verfblauw";
					tool2 = "verforanje";
					tool3 = "riem";
					tool4 = "riembreed";
					tool5 = "riemv";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(2);
					sceneScherm.spr_doosvoor.doosbal.b3helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed0.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv2.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b3p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p3.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b3p4.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p5.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p6.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b3p7.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p8.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p9.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b3p10.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p11.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p12.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b3p13.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p14.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b3p15.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b3p16.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p17.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b3p18.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==12) {
					nrlevelbal = 6;
					nbrtools = 5;
					tool1 = "graszaad";
					tool2 = "bloemwitzaad";
					tool3 = "gieter";
					tool4 = "helm";
					tool5 = "bin";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(5);
					sceneScherm.spr_doosvoor.doosbal.b6helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b6mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b6mutsrechts.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras01.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras02.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras03.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras04.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6bloemwit1.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemwit2.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemwit3.visible = true; sceneScherm.spr_doosvoor.doosbal.b6bloemwit4.visible = true;
					sceneScherm.spr_doosvoor.doosbal.b6bloemwit3.gotoAndStop("bloem3");sceneScherm.spr_doosvoor.doosbal.b6bloemwit4.gotoAndStop("bloem3");
					sceneScherm.spr_doosvoor.doosbal.b6bloemblauw1.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw2.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw3.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6p1.gotoAndStop("gras2"); sceneScherm.spr_doosvoor.doosbal.b6p2.gotoAndStop("gras2");
					sceneScherm.spr_doosvoor.doosbal.b6p3.gotoAndStop("gras3");sceneScherm.spr_doosvoor.doosbal.b6p4.gotoAndStop("gras3");
				} else if (sceneScherm.lvl==13) {
					nrlevelbal = 7;
					nbrtools = 7;
					tool1 = "verfgeel";
					tool2 = "verfzwart";
					tool3 = "skibrilklein11";
					tool4 = "zorro";
					tool5 = "riem11";
					tool6 = "helm";
					tool7 = "bin";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(6);
					sceneScherm.spr_doosvoor.doosbal.b7zorro.visible = false;sceneScherm.spr_doosvoor.doosbal.b7helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein3.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b7p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p2.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p4.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b7p6.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b7p7.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p8.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b7p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p10.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b7p11.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b7p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p13.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b7p14.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b7p15.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b7p16.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p17.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p18.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b7p19.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b7p20.gotoAndStop("geel");
				} else if (sceneScherm.lvl==14) {
					nrlevelbal = 8;
					nbrtools = 6;
					tool1 = "verfgeel";
					tool2 = "verfrood";
					tool3 = "verfblauw";
					tool4 = "rieml";
					tool5 = "riemr";
					tool6 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(7);
					sceneScherm.spr_doosvoor.doosbal.b8riemr.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2.visible = false;sceneScherm.spr_doosvoor.doosbal.b8helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b8riemrboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1boven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2boven.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b8p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b8p2.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b8p3.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b8p4.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b8p6.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b8p7.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p8.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b8p9.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b8p10.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p11.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p12.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b8p13.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b8p14.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p15.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b8p16.gotoAndStop("geel");
				} else if (sceneScherm.lvl==15) {
					nrlevelbal = 4;
					nbrtools = 6;
					tool1 = "verfrood";
					tool2 = "verfgeel";
					tool3 = "riemv";
					tool4 = "helmrot";
					tool5 = "mutsonder";
					tool6 = "mutsboven";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(3);
					sceneScherm.spr_doosvoor.doosbal.b4helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b4mutsonder.visible = false;sceneScherm.spr_doosvoor.doosbal.b4mutsboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b4phonelinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b4phonerechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riemvoor.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riemv.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b4p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b4p2.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b4p3.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p5.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b4p6.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p7.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p8.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p9.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b4p10.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p11.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b4p12.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b4p13.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b4p14.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b4p15.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b4p16.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b4p17.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b4p18.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b4p19.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b4p20.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b4p21.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b4p22.gotoAndStop("rood");
				} else if (sceneScherm.lvl==16) {
					nrlevelbal = 8;
					nbrtools = 6;
					tool1 = "verfrood";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "rieml";
					tool5 = "riemr";
					tool6 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(7);
					sceneScherm.spr_doosvoor.doosbal.b8riemr.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2.visible = false;sceneScherm.spr_doosvoor.doosbal.b8helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b8riemrboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1boven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2boven.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b8p1.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p2.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p3.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b8p4.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p5.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p6.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p7.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p8.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p11.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p13.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p14.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p15.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p16.gotoAndStop("zwart");
				} else if (sceneScherm.lvl==17) {
					nrlevelbal = 6;
					nbrtools = 6;
					tool1 = "graszaad";
					tool2 = "bloemwitzaad";
					tool3 = "bloemblauwzaad";
					tool4 = "gieter";
					tool5 = "helm";
					tool6 = "bin";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(5);
					sceneScherm.spr_doosvoor.doosbal.b6helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b6mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b6mutsrechts.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras01.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras02.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras03.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras04.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6bloemwit1.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemwit2.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemwit3.visible = true; sceneScherm.spr_doosvoor.doosbal.b6bloemwit4.visible = true;
					sceneScherm.spr_doosvoor.doosbal.b6bloemwit3.gotoAndStop("bloem2"); sceneScherm.spr_doosvoor.doosbal.b6bloemwit4.gotoAndStop("bloem2");
					sceneScherm.spr_doosvoor.doosbal.b6bloemblauw1.visible = true; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw2.visible = true; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw3.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6bloemblauw1.gotoAndStop("bloem3");sceneScherm.spr_doosvoor.doosbal.b6bloemblauw2.gotoAndStop("bloem3");
					sceneScherm.spr_doosvoor.doosbal.b6p1.gotoAndStop("gras1"); sceneScherm.spr_doosvoor.doosbal.b6p2.gotoAndStop("gras1");
					sceneScherm.spr_doosvoor.doosbal.b6p3.gotoAndStop("gras2");sceneScherm.spr_doosvoor.doosbal.b6p4.gotoAndStop("gras2");
				} else if (sceneScherm.lvl==18) {
					nrlevelbal = 7;
					nbrtools = 8;
					tool1 = "verfrood";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "skibrilklein11";
					tool5 = "zorro";
					tool6 = "riem11";
					tool7 = "helm";
					tool8 = "steekmes";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(6);
					sceneScherm.spr_doosvoor.doosbal.b7zorro.visible = false;sceneScherm.spr_doosvoor.doosbal.b7helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein3.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b7p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p4.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p5.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p6.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b7p7.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b7p8.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b7p9.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b7p10.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b7p11.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p12.gotoAndStop("wit");
					sceneScherm.spr_doosvoor.doosbal.b7p13.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p14.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p15.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b7p16.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p17.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b7p18.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b7p19.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p20.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==19) {
					nrlevelbal = 8;
					nbrtools = 9;
					tool1 = "verfgeel";
					tool2 = "verforanje";
					tool3 = "verfmagenta";
					tool4 = "verfzwart";
					tool5 = "mutslinks";
					tool6 = "mutsrechts";
					tool7 = "rieml";
					tool8 = "riemr";
					tool9 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(7);
					sceneScherm.spr_doosvoor.doosbal.b8riemr.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2.visible = false;sceneScherm.spr_doosvoor.doosbal.b8helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b8riemrboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1boven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2boven.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b8p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b8p2.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b8p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p4.gotoAndStop("paars");sceneScherm.spr_doosvoor.doosbal.b8p5.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b8p6.gotoAndStop("paars");
					sceneScherm.spr_doosvoor.doosbal.b8p7.gotoAndStop("paars");sceneScherm.spr_doosvoor.doosbal.b8p8.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b8p9.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b8p10.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p11.gotoAndStop("paars");sceneScherm.spr_doosvoor.doosbal.b8p12.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b8p13.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p14.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p15.gotoAndStop("oranje");
					sceneScherm.spr_doosvoor.doosbal.b8p16.gotoAndStop("oranje");
				} else if (sceneScherm.lvl==20) {
					nrlevelbal = 9;
					nbrtools = 10;
					tool1 = "verfgeel";
					tool2 = "verforanje";
					tool3 = "verfblauw";
					tool4 = "verfzwart";
					tool5 = "mutslinks";
					tool6 = "mutsrechts";
					tool7 = "skibril";
					tool8 = "skibrilklein";
					tool9 = "riem13";
					tool10 = "helm";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(8);
					sceneScherm.spr_doosvoor.doosbal.b9helm.visible = false; sceneScherm.spr_doosvoor.doosbal.b9skibril.visible = false; sceneScherm.spr_doosvoor.doosbal.b9skibrilklein.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b9mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b9riem1.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem2.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem3.visible=false;sceneScherm.spr_doosvoor.doosbal.b9riem4.visible=false;
					sceneScherm.spr_doosvoor.doosbal.b9p1.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b9p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b9p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p4.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b9p5.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b9p6.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p7.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b9p8.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b9p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p11.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b9p12.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p13.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b9p14.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b9p15.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p16.gotoAndStop("oranje");sceneScherm.spr_doosvoor.doosbal.b9p17.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b9p18.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b9p19.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b9p20.gotoAndStop("geel");
				} else if (sceneScherm.lvl==21) {
					nrlevelbal = 4;
					nbrtools = 6;
					tool1 = "verfblauw";
					tool2 = "verforanje";
					tool3 = "riembreed";
					tool4 = "riemv";
					tool5 = "mutsonder";
					tool6 = "mutsboven";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(3);
					sceneScherm.spr_doosvoor.doosbal.b4helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b4mutsonder.visible = false;sceneScherm.spr_doosvoor.doosbal.b4mutsboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b4phonelinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b4phonerechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riemvoor.visible = false;sceneScherm.spr_doosvoor.doosbal.b4riemv.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b4p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p2.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p3.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b4p4.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p5.gotoAndStop("oranje"); sceneScherm.spr_doosvoor.doosbal.b4p6.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b4p7.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p8.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p9.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p10.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p11.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b4p12.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p13.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p14.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p15.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b4p16.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b4p17.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p18.gotoAndStop("oranje");sceneScherm.spr_doosvoor.doosbal.b4p19.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b4p20.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p21.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b4p22.gotoAndStop("blauw");
				} else if (sceneScherm.lvl==22) {
					nrlevelbal = 7;
					nbrtools = 8;
					tool1 = "verfrood";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "skibrilklein11";
					tool5 = "zorro";
					tool6 = "riem11";
					tool7 = "helm";
					tool8 = "steekmes";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(6);
					sceneScherm.spr_doosvoor.doosbal.b7zorro.visible = false;sceneScherm.spr_doosvoor.doosbal.b7helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7riem2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein1.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein2.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein3.visible = false;sceneScherm.spr_doosvoor.doosbal.b7skibrilklein4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b7p1.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p2.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b7p4.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p5.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p6.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b7p7.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p8.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p9.gotoAndStop("wit");
					sceneScherm.spr_doosvoor.doosbal.b7p10.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p11.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p12.gotoAndStop("blauw");
					sceneScherm.spr_doosvoor.doosbal.b7p13.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p14.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b7p15.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b7p16.gotoAndStop("rood");sceneScherm.spr_doosvoor.doosbal.b7p17.gotoAndStop("wit");sceneScherm.spr_doosvoor.doosbal.b7p18.gotoAndStop("wit");
					sceneScherm.spr_doosvoor.doosbal.b7p19.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b7p20.gotoAndStop("zwart");
				} else if (sceneScherm.lvl==23) {
					nrlevelbal = 6;
					nbrtools = 7;
					tool1 = "graszaad";
					tool2 = "bloemwitzaad";
					tool3 = "gieter";
					tool4 = "helm";
					tool5 = "mutslinks";
					tool6 = "mutsrechts";
					tool7 = "bin";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(5);
					sceneScherm.spr_doosvoor.doosbal.b6helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b6mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b6mutsrechts.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras01.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras02.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras03.visible = false; sceneScherm.spr_doosvoor.doosbal.b6gras04.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6bloemwit1.visible = true; sceneScherm.spr_doosvoor.doosbal.b6bloemwit2.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemwit3.visible = true; sceneScherm.spr_doosvoor.doosbal.b6bloemwit4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6bloemwit1.gotoAndStop("bloem3");sceneScherm.spr_doosvoor.doosbal.b6bloemwit3.gotoAndStop("bloem2");
					sceneScherm.spr_doosvoor.doosbal.b6bloemblauw1.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw2.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw3.visible = false; sceneScherm.spr_doosvoor.doosbal.b6bloemblauw4.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b6p1.gotoAndStop("gras1");sceneScherm.spr_doosvoor.doosbal.b6p2.gotoAndStop("gras2");
					sceneScherm.spr_doosvoor.doosbal.b6p3.gotoAndStop("gras3");sceneScherm.spr_doosvoor.doosbal.b6p4.gotoAndStop("gras2");
				} else if (sceneScherm.lvl==24) {
					nrlevelbal = 3;
					nbrtools = 7;
					tool1 = "verfgeel";
					tool2 = "verfmagenta";
					tool3 = "verfzwart";
					tool4 = "helm";
					tool5 = "riem";
					tool6 = "riembreed";
					tool7 = "riemv";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(2);
					sceneScherm.spr_doosvoor.doosbal.b3helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riem.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed0.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreed2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riemv2.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv1.visible = false;sceneScherm.spr_doosvoor.doosbal.b3riembreedv2.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b3p1.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p2.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p3.gotoAndStop("magenta");
					sceneScherm.spr_doosvoor.doosbal.b3p4.gotoAndStop("geel");sceneScherm.spr_doosvoor.doosbal.b3p5.gotoAndStop("geel"); sceneScherm.spr_doosvoor.doosbal.b3p6.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b3p7.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b3p8.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b3p9.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b3p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b3p11.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b3p12.gotoAndStop("magenta");
					sceneScherm.spr_doosvoor.doosbal.b3p13.gotoAndStop("magenta"); sceneScherm.spr_doosvoor.doosbal.b3p14.gotoAndStop("magenta"); sceneScherm.spr_doosvoor.doosbal.b3p15.gotoAndStop("geel");
					sceneScherm.spr_doosvoor.doosbal.b3p16.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p17.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b3p18.gotoAndStop("magenta");
				} else if (sceneScherm.lvl==25) {
					nrlevelbal = 8;
					nbrtools = 9;
					tool1 = "verfrood";
					tool2 = "verfblauw";
					tool3 = "verfzwart";
					tool4 = "mutslinks";
					tool5 = "mutsrechts";
					tool6 = "rieml";
					tool7 = "riemr";
					tool8 = "helm";
					tool9 = "steekmes";
					sceneScherm.spr_doosvoor.doosbal.gotoAndStop(7);
					sceneScherm.spr_doosvoor.doosbal.b8riemr.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2.visible = false;sceneScherm.spr_doosvoor.doosbal.b8helm.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutslinks.visible = false;sceneScherm.spr_doosvoor.doosbal.b8mutsrechts.visible = false;sceneScherm.spr_doosvoor.doosbal.b8riemrboven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml1boven.visible = false;sceneScherm.spr_doosvoor.doosbal.b8rieml2boven.visible = false;
					sceneScherm.spr_doosvoor.doosbal.b8p1.gotoAndStop("blauw");sceneScherm.spr_doosvoor.doosbal.b8p2.gotoAndStop("zwart");sceneScherm.spr_doosvoor.doosbal.b8p3.gotoAndStop("zwart");
					sceneScherm.spr_doosvoor.doosbal.b8p4.gotoAndStop("wit"); sceneScherm.spr_doosvoor.doosbal.b8p5.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p6.gotoAndStop("wit");
					sceneScherm.spr_doosvoor.doosbal.b8p7.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p8.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p9.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b8p10.gotoAndStop("zwart"); sceneScherm.spr_doosvoor.doosbal.b8p11.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p12.gotoAndStop("wit");
					sceneScherm.spr_doosvoor.doosbal.b8p13.gotoAndStop("blauw"); sceneScherm.spr_doosvoor.doosbal.b8p14.gotoAndStop("rood"); sceneScherm.spr_doosvoor.doosbal.b8p15.gotoAndStop("rood");
					sceneScherm.spr_doosvoor.doosbal.b8p16.gotoAndStop("wit");
				}
				sceneScherm.toolbal1.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal2.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal3.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal4.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal5.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal6.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal7.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal8.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal9.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal10.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal11.toolsmovie.gotoAndStop("leeg");
				myradius = 387;
				if (nbrtools == 3) {
					toolbalx1 = balcentraalx - myradius*Math.sin(40*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(40*Math.PI/180);
					toolbalx2 = balcentraalx + myradius*Math.sin(0*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(0*Math.PI/180);
					toolbalx3 = balcentraalx + myradius*Math.sin(40*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(40*Math.PI/180);
				} else if (nbrtools == 4) {
					toolbalx1 = balcentraalx - myradius*Math.sin(60*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(60*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(20*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(20*Math.PI/180);
					toolbalx3 = balcentraalx + myradius*Math.sin(20*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(20*Math.PI/180);
					toolbalx4 = balcentraalx + myradius*Math.sin(60*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(60*Math.PI/180);
				} else if (nbrtools == 5) {
					toolbalx1 = balcentraalx - myradius*Math.sin(80*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(80*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(40*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(40*Math.PI/180);
					toolbalx3 = balcentraalx + myradius*Math.sin(0*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(0*Math.PI/180);
					toolbalx4 = balcentraalx + myradius*Math.sin(40*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(40*Math.PI/180);
					toolbalx5 = balcentraalx + myradius*Math.sin(80*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(80*Math.PI/180);
				} else if (nbrtools == 6) {
					toolbalx1 = balcentraalx - myradius*Math.sin(100*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(100*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(60*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(60*Math.PI/180);
					toolbalx3 = balcentraalx - myradius*Math.sin(20*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(20*Math.PI/180);
					toolbalx4 = balcentraalx + myradius*Math.sin(20*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(20*Math.PI/180);
					toolbalx5 = balcentraalx + myradius*Math.sin(60*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(60*Math.PI/180);
					toolbalx6 = balcentraalx + myradius*Math.sin(100*Math.PI/180); toolbaly6 = balcentraaly - myradius*Math.cos(100*Math.PI/180);
				} else if (nbrtools == 7) {
					toolbalx1 = balcentraalx - myradius*Math.sin(90*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(90*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(60*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(60*Math.PI/180);
					toolbalx3 = balcentraalx - myradius*Math.sin(30*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(30*Math.PI/180);
					toolbalx4 = balcentraalx + myradius*Math.sin(0*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(0*Math.PI/180);
					toolbalx5 = balcentraalx + myradius*Math.sin(30*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(30*Math.PI/180);
					toolbalx6 = balcentraalx + myradius*Math.sin(60*Math.PI/180); toolbaly6 = balcentraaly - myradius*Math.cos(60*Math.PI/180);
					toolbalx7 = balcentraalx + myradius*Math.sin(90*Math.PI/180); toolbaly7 = balcentraaly - myradius*Math.cos(90*Math.PI/180);
				} else if (nbrtools == 8) {
					toolbalx1 = balcentraalx - myradius*Math.sin(91*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(91*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(65*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(65*Math.PI/180);
					toolbalx3 = balcentraalx - myradius*Math.sin(39*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(39*Math.PI/180);
					toolbalx4 = balcentraalx - myradius*Math.sin(13*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(13*Math.PI/180);
					toolbalx5 = balcentraalx + myradius*Math.sin(13*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(13*Math.PI/180);
					toolbalx6 = balcentraalx + myradius*Math.sin(39*Math.PI/180); toolbaly6 = balcentraaly - myradius*Math.cos(39*Math.PI/180);
					toolbalx7 = balcentraalx + myradius*Math.sin(65*Math.PI/180); toolbaly7 = balcentraaly - myradius*Math.cos(65*Math.PI/180);
					toolbalx8 = balcentraalx + myradius*Math.sin(91*Math.PI/180); toolbaly8 = balcentraaly - myradius*Math.cos(91*Math.PI/180);
				} else if (nbrtools == 9) {
					toolbalx1 = balcentraalx - myradius*Math.sin(104*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(104*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(78*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(78*Math.PI/180);
					toolbalx3 = balcentraalx - myradius*Math.sin(52*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(52*Math.PI/180);
					toolbalx4 = balcentraalx - myradius*Math.sin(26*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(26*Math.PI/180);
					toolbalx5 = balcentraalx + myradius*Math.sin(0*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(0*Math.PI/180);
					toolbalx6 = balcentraalx + myradius*Math.sin(26*Math.PI/180); toolbaly6 = balcentraaly - myradius*Math.cos(26*Math.PI/180);
					toolbalx7 = balcentraalx + myradius*Math.sin(52*Math.PI/180); toolbaly7 = balcentraaly - myradius*Math.cos(52*Math.PI/180);
					toolbalx8 = balcentraalx + myradius*Math.sin(78*Math.PI/180); toolbaly8 = balcentraaly - myradius*Math.cos(78*Math.PI/180);
					toolbalx9 = balcentraalx + myradius*Math.sin(104*Math.PI/180); toolbaly9 = balcentraaly - myradius*Math.cos(104*Math.PI/180);
				} else if (nbrtools == 10) {
					toolbalx1 = balcentraalx - myradius*Math.sin(117*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(117*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(91*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(91*Math.PI/180);
					toolbalx3 = balcentraalx - myradius*Math.sin(65*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(65*Math.PI/180);
					toolbalx4 = balcentraalx - myradius*Math.sin(39*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(39*Math.PI/180);
					toolbalx5 = balcentraalx - myradius*Math.sin(13*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(13*Math.PI/180);
					toolbalx6 = balcentraalx + myradius*Math.sin(13*Math.PI/180); toolbaly6 = balcentraaly - myradius*Math.cos(13*Math.PI/180);
					toolbalx7 = balcentraalx + myradius*Math.sin(39*Math.PI/180); toolbaly7 = balcentraaly - myradius*Math.cos(39*Math.PI/180);
					toolbalx8 = balcentraalx + myradius*Math.sin(65*Math.PI/180); toolbaly8 = balcentraaly - myradius*Math.cos(65*Math.PI/180);
					toolbalx9 = balcentraalx + myradius*Math.sin(91*Math.PI/180); toolbaly9 = balcentraaly - myradius*Math.cos(91*Math.PI/180);
					toolbalx10 = balcentraalx + myradius*Math.sin(117*Math.PI/180); toolbaly10 = balcentraaly - myradius*Math.cos(117*Math.PI/180);
				} else if (nbrtools == 11) {
					toolbalx1 = balcentraalx - myradius*Math.sin(115*Math.PI/180); toolbaly1 = balcentraaly - myradius*Math.cos(115*Math.PI/180);
					toolbalx2 = balcentraalx - myradius*Math.sin(92*Math.PI/180); toolbaly2 = balcentraaly - myradius*Math.cos(92*Math.PI/180);
					toolbalx3 = balcentraalx - myradius*Math.sin(69*Math.PI/180); toolbaly3 = balcentraaly - myradius*Math.cos(69*Math.PI/180);
					toolbalx4 = balcentraalx - myradius*Math.sin(46*Math.PI/180); toolbaly4 = balcentraaly - myradius*Math.cos(46*Math.PI/180);
					toolbalx5 = balcentraalx - myradius*Math.sin(23*Math.PI/180); toolbaly5 = balcentraaly - myradius*Math.cos(23*Math.PI/180);
					toolbalx6 = balcentraalx - myradius*Math.sin(0*Math.PI/180); toolbaly6 = balcentraaly - myradius*Math.cos(0*Math.PI/180);
					toolbalx7 = balcentraalx + myradius*Math.sin(23*Math.PI/180); toolbaly7 = balcentraaly - myradius*Math.cos(23*Math.PI/180);
					toolbalx8 = balcentraalx + myradius*Math.sin(46*Math.PI/180); toolbaly8 = balcentraaly - myradius*Math.cos(46*Math.PI/180);
					toolbalx9 = balcentraalx + myradius*Math.sin(69*Math.PI/180); toolbaly9 = balcentraaly - myradius*Math.cos(69*Math.PI/180);
					toolbalx10 = balcentraalx + myradius*Math.sin(92*Math.PI/180); toolbaly10 = balcentraaly - myradius*Math.cos(92*Math.PI/180);
					toolbalx11 = balcentraalx + myradius*Math.sin(115*Math.PI/180); toolbaly11 = balcentraaly - myradius*Math.cos(115*Math.PI/180);
				}
				switch(nrlevelbal) {
					case 1:
						sceneScherm.spr_bal.gotoAndStop(0);
						sceneScherm.spr_bal.helm.visible = false;
						sceneScherm.spr_bal.p1.gotoAndStop("wit"); sceneScherm.spr_bal.p2.gotoAndStop("wit");
						break;
					case 3:
						sceneScherm.spr_bal.gotoAndStop(2);
						sceneScherm.spr_bal.b3helm.visible = false;sceneScherm.spr_bal.b3riem.visible = false;sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false;sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.spr_bal.b3riembreedv1.visible = false;sceneScherm.spr_bal.b3riembreedv2.visible = false;
						sceneScherm.spr_bal.b3p1.gotoAndStop("wit"); sceneScherm.spr_bal.b3p2.gotoAndStop("wit"); sceneScherm.spr_bal.b3p3.gotoAndStop("wit"); sceneScherm.spr_bal.b3p4.gotoAndStop("wit"); sceneScherm.spr_bal.b3p5.gotoAndStop("wit"); sceneScherm.spr_bal.b3p6.gotoAndStop("wit");
						sceneScherm.spr_bal.b3p7.gotoAndStop("wit"); sceneScherm.spr_bal.b3p8.gotoAndStop("wit"); sceneScherm.spr_bal.b3p9.gotoAndStop("wit"); sceneScherm.spr_bal.b3p10.gotoAndStop("wit"); sceneScherm.spr_bal.b3p11.gotoAndStop("wit"); sceneScherm.spr_bal.b3p12.gotoAndStop("wit");
						sceneScherm.spr_bal.b3p13.gotoAndStop("wit"); sceneScherm.spr_bal.b3p14.gotoAndStop("wit"); sceneScherm.spr_bal.b3p15.gotoAndStop("wit"); sceneScherm.spr_bal.b3p16.gotoAndStop("wit"); sceneScherm.spr_bal.b3p17.gotoAndStop("wit"); sceneScherm.spr_bal.b3p18.gotoAndStop("wit");
						laag1 = ""; laag2 = ""; laag3 = "";
						break;
					case 4:
						rechtsvoor = false;
						sceneScherm.spr_bal.gotoAndStop(3);
						sceneScherm.spr_bal.b4helm.visible = false;sceneScherm.spr_bal.b4mutsonder.visible = false;sceneScherm.spr_bal.b4mutsboven.visible = false;sceneScherm.spr_bal.b4phonelinks.visible = false;sceneScherm.spr_bal.b4phonerechts.visible = false;sceneScherm.spr_bal.b4riem.visible = false;sceneScherm.spr_bal.b4riemvoor.visible = false;sceneScherm.spr_bal.b4riemv.visible = false;
						sceneScherm.spr_bal.b4p1.gotoAndStop("wit"); sceneScherm.spr_bal.b4p2.gotoAndStop("wit"); sceneScherm.spr_bal.b4p3.gotoAndStop("wit"); sceneScherm.spr_bal.b4p4.gotoAndStop("wit"); sceneScherm.spr_bal.b4p5.gotoAndStop("wit"); sceneScherm.spr_bal.b4p6.gotoAndStop("wit");
						sceneScherm.spr_bal.b4p7.gotoAndStop("wit"); sceneScherm.spr_bal.b4p8.gotoAndStop("wit"); sceneScherm.spr_bal.b4p9.gotoAndStop("wit"); sceneScherm.spr_bal.b4p10.gotoAndStop("wit"); sceneScherm.spr_bal.b4p11.gotoAndStop("wit"); sceneScherm.spr_bal.b4p12.gotoAndStop("wit");
						sceneScherm.spr_bal.b4p13.gotoAndStop("wit"); sceneScherm.spr_bal.b4p14.gotoAndStop("wit"); sceneScherm.spr_bal.b4p15.gotoAndStop("wit"); sceneScherm.spr_bal.b4p16.gotoAndStop("wit"); sceneScherm.spr_bal.b4p17.gotoAndStop("wit"); sceneScherm.spr_bal.b4p18.gotoAndStop("wit");
						sceneScherm.spr_bal.b4p19.gotoAndStop("wit"); sceneScherm.spr_bal.b4p20.gotoAndStop("wit"); sceneScherm.spr_bal.b4p21.gotoAndStop("wit"); sceneScherm.spr_bal.b4p22.gotoAndStop("wit");
						break;
					case 6:
						sceneScherm.spr_bal.gotoAndStop(5);
						sceneScherm.spr_bal.b6helm.visible = false;sceneScherm.spr_bal.b6mutslinks.visible = false;sceneScherm.spr_bal.b6mutsrechts.visible = false; sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6gras04.visible = false;
						sceneScherm.spr_bal.b6bloemwit1.visible = false;sceneScherm.spr_bal.b6bloemwit2.visible = false;sceneScherm.spr_bal.b6bloemwit3.visible = false;sceneScherm.spr_bal.b6bloemwit4.visible = false;
						sceneScherm.spr_bal.b6bloemblauw1.visible = false;sceneScherm.spr_bal.b6bloemblauw2.visible = false;sceneScherm.spr_bal.b6bloemblauw3.visible = false;sceneScherm.spr_bal.b6bloemblauw4.visible = false;
						sceneScherm.spr_bal.b6p1.visible = false;sceneScherm.spr_bal.b6p2.visible = false;sceneScherm.spr_bal.b6p3.visible = false;sceneScherm.spr_bal.b6p4.visible = false;
						break;
					case 7:
						sceneScherm.spr_bal.gotoAndStop(6);
						sceneScherm.spr_bal.b7zorro.visible = false;sceneScherm.spr_bal.b7helm.visible = false;sceneScherm.spr_bal.b7riem1.visible = false;sceneScherm.spr_bal.b7riem2.visible = false;sceneScherm.spr_bal.b7skibrilklein1.visible = false;sceneScherm.spr_bal.b7skibrilklein2.visible = false;sceneScherm.spr_bal.b7skibrilklein3.visible = false;sceneScherm.spr_bal.b7skibrilklein4.visible = false;
						sceneScherm.spr_bal.b7p1.gotoAndStop("wit"); sceneScherm.spr_bal.b7p2.gotoAndStop("wit"); sceneScherm.spr_bal.b7p3.gotoAndStop("wit"); sceneScherm.spr_bal.b7p4.gotoAndStop("wit"); sceneScherm.spr_bal.b7p5.gotoAndStop("wit"); sceneScherm.spr_bal.b7p6.gotoAndStop("wit");
						sceneScherm.spr_bal.b7p7.gotoAndStop("wit"); sceneScherm.spr_bal.b7p8.gotoAndStop("wit"); sceneScherm.spr_bal.b7p9.gotoAndStop("wit"); sceneScherm.spr_bal.b7p10.gotoAndStop("wit"); sceneScherm.spr_bal.b7p11.gotoAndStop("wit"); sceneScherm.spr_bal.b7p12.gotoAndStop("wit");
						sceneScherm.spr_bal.b7p13.gotoAndStop("wit"); sceneScherm.spr_bal.b7p14.gotoAndStop("wit"); sceneScherm.spr_bal.b7p15.gotoAndStop("wit"); sceneScherm.spr_bal.b7p16.gotoAndStop("wit"); sceneScherm.spr_bal.b7p17.gotoAndStop("wit"); sceneScherm.spr_bal.b7p18.gotoAndStop("wit");
						sceneScherm.spr_bal.b7p19.gotoAndStop("wit"); sceneScherm.spr_bal.b7p20.gotoAndStop("wit");
						break;
					case 8:
						riemiserl = false;
						riemiserr = false;
						sceneScherm.spr_bal.gotoAndStop(7);
						sceneScherm.spr_bal.b8riemr.visible = false;sceneScherm.spr_bal.b8rieml1.visible = false;sceneScherm.spr_bal.b8rieml2.visible = false;sceneScherm.spr_bal.b8helm.visible = false;sceneScherm.spr_bal.b8mutslinks.visible = false;sceneScherm.spr_bal.b8mutsrechts.visible = false;sceneScherm.spr_bal.b8riemrboven.visible = false;sceneScherm.spr_bal.b8rieml1boven.visible = false;sceneScherm.spr_bal.b8rieml2boven.visible = false;
						sceneScherm.spr_bal.b8p1.gotoAndStop("wit"); sceneScherm.spr_bal.b8p2.gotoAndStop("wit"); sceneScherm.spr_bal.b8p3.gotoAndStop("wit"); sceneScherm.spr_bal.b8p4.gotoAndStop("wit"); sceneScherm.spr_bal.b8p5.gotoAndStop("wit"); sceneScherm.spr_bal.b8p6.gotoAndStop("wit");
						sceneScherm.spr_bal.b8p7.gotoAndStop("wit"); sceneScherm.spr_bal.b8p8.gotoAndStop("wit"); sceneScherm.spr_bal.b8p9.gotoAndStop("wit"); sceneScherm.spr_bal.b8p10.gotoAndStop("wit"); sceneScherm.spr_bal.b8p11.gotoAndStop("wit"); sceneScherm.spr_bal.b8p12.gotoAndStop("wit");
						sceneScherm.spr_bal.b8p13.gotoAndStop("wit"); sceneScherm.spr_bal.b8p14.gotoAndStop("wit"); sceneScherm.spr_bal.b8p15.gotoAndStop("wit"); sceneScherm.spr_bal.b8p16.gotoAndStop("wit");
						break;
					case 9:
						riemiser = false;
						linksvoor = false;
						rechtsvoor = false;
						sceneScherm.spr_bal.gotoAndStop(8);
						sceneScherm.spr_bal.b9helm.visible = false; sceneScherm.spr_bal.b9skibril.visible = false; sceneScherm.spr_bal.b9skibrilklein.visible = false;sceneScherm.spr_bal.b9mutsrechts.visible = false;sceneScherm.spr_bal.b9mutslinks.visible = false;sceneScherm.spr_bal.b9riem1.visible=false;sceneScherm.spr_bal.b9riem2.visible=false;sceneScherm.spr_bal.b9riem3.visible=false;sceneScherm.spr_bal.b9riem4.visible=false;
						sceneScherm.spr_bal.b9p1.gotoAndStop("wit"); sceneScherm.spr_bal.b9p2.gotoAndStop("wit"); sceneScherm.spr_bal.b9p3.gotoAndStop("wit"); sceneScherm.spr_bal.b9p4.gotoAndStop("wit"); sceneScherm.spr_bal.b9p5.gotoAndStop("wit"); sceneScherm.spr_bal.b9p6.gotoAndStop("wit");
						sceneScherm.spr_bal.b9p7.gotoAndStop("wit"); sceneScherm.spr_bal.b9p8.gotoAndStop("wit"); sceneScherm.spr_bal.b9p9.gotoAndStop("wit"); sceneScherm.spr_bal.b9p10.gotoAndStop("wit"); sceneScherm.spr_bal.b9p11.gotoAndStop("wit"); sceneScherm.spr_bal.b9p12.gotoAndStop("wit");
						sceneScherm.spr_bal.b9p13.gotoAndStop("wit"); sceneScherm.spr_bal.b9p14.gotoAndStop("wit"); sceneScherm.spr_bal.b9p15.gotoAndStop("wit"); sceneScherm.spr_bal.b9p16.gotoAndStop("wit");
						sceneScherm.spr_bal.b9p17.gotoAndStop("wit"); sceneScherm.spr_bal.b9p18.gotoAndStop("wit"); sceneScherm.spr_bal.b9p19.gotoAndStop("wit"); sceneScherm.spr_bal.b9p20.gotoAndStop("wit");
						break;
				}
				sceneScherm.toolbal1.x = toolbalx1; sceneScherm.toolbal1.y = toolbaly1;
				sceneScherm.toolbal1.toolbalmovie.gotoAndPlay(1);
				toolupdated = 1;
			}
			if (pauzetel<21) {
				sceneScherm.spr_doos.gotoAndStop(20 - pauzetel-1);
				sceneScherm.spr_doosvoor.gotoAndStop(20 - pauzetel-1);
			}
			if (pauzetel == 21) {
				if (sceneScherm.lvl == 1 && instructieteller == 0) {
					sceneScherm.spr_instructie.klik2.visible=false;
					sceneScherm.spr_instructie.bal1.gotoAndStop(0);
					sceneScherm.spr_instructie.bal1.helm.visible = false;
					sceneScherm.spr_instructie.bal1.p1.gotoAndStop("wit");
					sceneScherm.spr_instructie.bal1.p2.gotoAndStop("wit");
					sceneScherm.spr_instructie.bal2.gotoAndStop(0);
					sceneScherm.spr_instructie.bal2.helm.visible = false;
					sceneScherm.spr_instructie.bal2.p1.gotoAndStop("blauw");
					sceneScherm.spr_instructie.bal2.p2.gotoAndStop("blauw");
					sceneScherm.spr_instructie.tool.toolsmovie.gotoAndStop("verfblauw");
					sceneScherm.spr_instructie.y = 882;
					instructieteller = 1;
				}
			}
			if (pauzetel == 26) {
				balorigx = sceneScherm.spr_bal.x; balorigy = sceneScherm.spr_bal.y;
				stateLevelLoop=true;
				sceneScherm.spr_bal.cursor="pointer";
				sceneScherm.spr_bal.addEventListener("click",ballPress);
			}
			if (pauzetel < 32 && pauzetel > 21 && instructieteller == 1) {
				if (sceneScherm.lvl == 1) {
					sceneScherm.spr_instructie.y = tweenarray3[pauzetel-22];
				}
			}
			if ((nbrtools >= toolupdated) && (pauzetel == (toolupdated * 6))) {
				if (toolupdated==1) sceneScherm.toolbal1.toolsmovie.gotoAndStop(tool1);
				else if (toolupdated==2) sceneScherm.toolbal2.toolsmovie.gotoAndStop(tool2);
				else if (toolupdated==3) sceneScherm.toolbal3.toolsmovie.gotoAndStop(tool3);
				else if (toolupdated==4) sceneScherm.toolbal4.toolsmovie.gotoAndStop(tool4);
				else if (toolupdated==5) sceneScherm.toolbal5.toolsmovie.gotoAndStop(tool5);
				else if (toolupdated==6) sceneScherm.toolbal6.toolsmovie.gotoAndStop(tool6);
				else if (toolupdated==7) sceneScherm.toolbal7.toolsmovie.gotoAndStop(tool7);
				else if (toolupdated==8) sceneScherm.toolbal8.toolsmovie.gotoAndStop(tool8);
				else if (toolupdated==9) sceneScherm.toolbal9.toolsmovie.gotoAndStop(tool9);
				else if (toolupdated==10) sceneScherm.toolbal10.toolsmovie.gotoAndStop(tool10);
				else if (toolupdated==11) sceneScherm.toolbal11.toolsmovie.gotoAndStop(tool11);
				if ((toolupdated + 1) <= nbrtools) {
					if (toolupdated==1) {sceneScherm.toolbal2.x=toolbalx2;sceneScherm.toolbal2.y=toolbaly2;sceneScherm.toolbal2.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==2) {sceneScherm.toolbal3.x=toolbalx3;sceneScherm.toolbal3.y=toolbaly3;sceneScherm.toolbal3.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==3) {sceneScherm.toolbal4.x=toolbalx4;sceneScherm.toolbal4.y=toolbaly4;sceneScherm.toolbal4.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==4) {sceneScherm.toolbal5.x=toolbalx5;sceneScherm.toolbal5.y=toolbaly5;sceneScherm.toolbal5.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==5) {sceneScherm.toolbal6.x=toolbalx6;sceneScherm.toolbal6.y=toolbaly6;sceneScherm.toolbal6.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==6) {sceneScherm.toolbal7.x=toolbalx7;sceneScherm.toolbal7.y=toolbaly7;sceneScherm.toolbal7.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==7) {sceneScherm.toolbal8.x=toolbalx8;sceneScherm.toolbal8.y=toolbaly8;sceneScherm.toolbal8.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==8) {sceneScherm.toolbal9.x=toolbalx9;sceneScherm.toolbal9.y=toolbaly9;sceneScherm.toolbal9.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==9) {sceneScherm.toolbal10.x=toolbalx10;sceneScherm.toolbal10.y=toolbaly10;sceneScherm.toolbal10.toolbalmovie.gotoAndPlay(1);}
					else if (toolupdated==10) {sceneScherm.toolbal11.x=toolbalx11;sceneScherm.toolbal11.y=toolbaly11;sceneScherm.toolbal11.toolbalmovie.gotoAndPlay(1);}
				}
				toolupdated++;
			}
			if (pauzetel < 15 && pauzetel>-1) {
				sceneScherm.balcentraal.visible = true;
				sceneScherm.spr_doos.visible = true;
				sceneScherm.spr_doosvoor.visible = true;
				sceneScherm.spr_bal.visible = true;
				sceneScherm.spr_doos.x = tweenarray11[pauzetel];
				sceneScherm.spr_bal.x = sceneScherm.spr_doos.x;
				sceneScherm.spr_doosvoor.x = sceneScherm.spr_doos.x;
				sceneScherm.balcentraal.y = tweenarray22[pauzetel];
			} else if (pauzetel == 15) {
		sceneScherm.spr_bal.x=470;
				tweenlen = (sceneScherm.spr_bal.y - 274);
				for (i = 0; i < 10; i++) {
					tweenarray1[i] = sceneScherm.spr_bal.y-myEaseOut(i, 0, tweenlen, 9);
				}
			} else if (pauzetel > 15 && pauzetel < 26) {
				sceneScherm.spr_bal.y = tweenarray1[pauzetel - 16];
			}
			pauzetel++;
		}
		
		function instructieLogic() {
			if (instructieteller == 1 && !sceneScherm.spr_bal.helm.visible && sceneScherm.spr_bal.p1.currentFrame == 3 && sceneScherm.spr_bal.p2.currentFrame == 3) {
				sceneScherm.spr_instructie.visible=true;
				sceneScherm.spr_instructie.klik2.visible=false;
				instructieteller = 2;
				animinstr = 0;
			} else if (instructieteller == 2) {
				sceneScherm.spr_instructie.y = tweenarray3[(9-animinstr)];
				animinstr++;
				if (animinstr == 10) instructieteller = 3;
			} else if (instructieteller == 3) {
				sceneScherm.spr_instructie.bal1.p1.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal1.p2.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal2.helm.visible = true;
				sceneScherm.spr_instructie.bal2.p1.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal2.p2.gotoAndStop("blauw");
				sceneScherm.spr_instructie.tool.toolsmovie.gotoAndStop("helm");
				instructieteller = 4;
				animinstr = 0;
			} else if (instructieteller == 4) {
				sceneScherm.spr_instructie.y = tweenarray3[animinstr];
				animinstr++;
				if (animinstr == 10) instructieteller = 5;
			} else if (instructieteller == 5 && sceneScherm.spr_bal.helm.visible && sceneScherm.spr_bal.p1.currentFrame == 3 && sceneScherm.spr_bal.p2.currentFrame == 3) {
				instructieteller = 6;
				animinstr = 0;
			} else if (instructieteller == 6) {
				sceneScherm.spr_instructie.y = tweenarray3[(9-animinstr)];
				animinstr++;
				if (animinstr == 10) instructieteller = 7;
			} else if (instructieteller == 7) {
				sceneScherm.spr_instructie.bal1.helm.visible = true;
				sceneScherm.spr_instructie.bal1.p1.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal1.p2.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal2.helm.visible = true;
				sceneScherm.spr_instructie.bal2.p1.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal2.p2.gotoAndStop("oranje");
				sceneScherm.spr_instructie.tool.toolsmovie.gotoAndStop("verforanje");
				instructieteller = 8;
				animinstr = 0;
			} else if (instructieteller == 8) {
				sceneScherm.spr_instructie.y = tweenarray3[animinstr];
				animinstr++;
				if (animinstr == 10) instructieteller = 9;
			} else if (instructieteller == 9 && sceneScherm.spr_bal.helm.visible && sceneScherm.spr_bal.p1.currentFrame == 3 && sceneScherm.spr_bal.p2.currentFrame == 2) {
				instructieteller = 10;
				animinstr = 0;
			} else if (instructieteller == 10) {
				sceneScherm.spr_instructie.y = tweenarray3[(9-animinstr)];
				animinstr++;
				if (animinstr == 10) instructieteller = 11;
			} else if (instructieteller == 11) {
				sceneScherm.spr_instructie.bal1.helm.visible = true;
				sceneScherm.spr_instructie.bal1.p1.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal1.p2.gotoAndStop("oranje");
				sceneScherm.spr_instructie.bal2.helm.visible = false;
				sceneScherm.spr_instructie.bal2.p1.gotoAndStop("blauw");
				sceneScherm.spr_instructie.bal2.p2.gotoAndStop("oranje");
				sceneScherm.spr_instructie.tool.toolsmovie.gotoAndStop("helmweg");
				sceneScherm.spr_instructie.klik2.visible=true;
				instructieteller = 12;
				animinstr = 0;
			} else if (instructieteller == 12) {
				sceneScherm.spr_instructie.y = tweenarray3[animinstr];
				animinstr++;
				if (animinstr == 10) instructieteller = 13;
			} else if (instructieteller == 13 && !sceneScherm.spr_bal.helm.visible && sceneScherm.spr_bal.p1.currentFrame == 3 && sceneScherm.spr_bal.p2.currentFrame == 2) {
				instructieteller = 14;
				animinstr = 0;
			} else if (instructieteller == 14) {
				sceneScherm.spr_instructie.y = tweenarray3[(9-animinstr)];
				animinstr++;
				if (animinstr == 10) instructieteller = 15;
			} else if (instructieteller == 15) {
				sceneScherm.spr_instructie.visible=false;
				instructieteller = 16;
			}
		}
		
		function ballPress(e) {
			if (toolstack != null && toolstack.length > 0) {
				prelogica(toolstack[toolstack.length-1]);
			}
		}
		function prelogica (toolused) {
			balschuifteller = 0;
			toolusednow = toolused;
			switch(toolusednow) {
				case 1: toolxnow = sceneScherm.toolbal1.x; toolynow = sceneScherm.toolbal1.y; break;
				case 2: toolxnow = sceneScherm.toolbal2.x; toolynow = sceneScherm.toolbal2.y; break;
				case 3: toolxnow = sceneScherm.toolbal3.x; toolynow = sceneScherm.toolbal3.y; break;
				case 4: toolxnow = sceneScherm.toolbal4.x; toolynow = sceneScherm.toolbal4.y; break;
				case 5: toolxnow = sceneScherm.toolbal5.x; toolynow = sceneScherm.toolbal5.y; break;
				case 6: toolxnow = sceneScherm.toolbal6.x; toolynow = sceneScherm.toolbal6.y; break;
				case 7: toolxnow = sceneScherm.toolbal7.x; toolynow = sceneScherm.toolbal7.y; break;
				case 8: toolxnow = sceneScherm.toolbal8.x; toolynow = sceneScherm.toolbal8.y; break;
				case 9: toolxnow = sceneScherm.toolbal9.x; toolynow = sceneScherm.toolbal9.y; break;
				case 10: toolxnow = sceneScherm.toolbal10.x; toolynow = sceneScherm.toolbal10.y; break;
				case 11: toolxnow = sceneScherm.toolbal11.x; toolynow = sceneScherm.toolbal11.y; break;
			}
			tweenlenxnow = balorigx - toolxnow;
			tweenlenynow = balorigy - toolynow;
			createjs.Ticker.addEventListener("tick",balSchuif);
		}
		function balSchuif(e)  {  
			if (balschuifteller < 5) {
				sceneScherm.spr_bal.x = balorigx - (myEaseOut(balschuifteller, 0, tweenlenxnow, 5));
				sceneScherm.spr_bal.y = balorigy - (myEaseOut(balschuifteller, 0, tweenlenynow, 5));
				if (balschuifteller == 4) logica(toolusednow);
			} else if (balschuifteller < 10) {
				sceneScherm.spr_bal.x = balorigx - (myEaseIn(10-balschuifteller, 0, tweenlenxnow, 5));
				sceneScherm.spr_bal.y = balorigy - (myEaseIn(10-balschuifteller, 0, tweenlenynow, 5));
			}
			if (balschuifteller == 10) {
				sceneScherm.spr_bal.x = balorigx;
				sceneScherm.spr_bal.y = balorigy;
				createjs.Ticker.removeEventListener("tick",balSchuif);
			}
			balschuifteller++;
		}
		function myEaseOut(t, b, c, d) {
			return -c * (t/=d)*(t-2) + b;
		}
		function myEaseIn(t, b, c, d) {
			return c*(t/=d)*t + b;
		}
		
		
		function logica (toolused) {
			if (sceneScherm.lvl<14) {
				dologica1 (toolused);
			} else if (sceneScherm.lvl<23) {
				dologica2 (toolused);
			} else {
				dologica3 (toolused);
			}
		}
		function dologica1 (toolused) {
			if (sceneScherm.lvl==1) {
				if (toolused == 1) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					kleur = "oranje";
					if (!sceneScherm.spr_bal.helm.visible) sceneScherm.spr_bal.p1.gotoAndStop(kleur);
					sceneScherm.spr_bal.p2.gotoAndStop(kleur);
				} else if (toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					kleur = "blauw";
					if (!sceneScherm.spr_bal.helm.visible) sceneScherm.spr_bal.p1.gotoAndStop(kleur);
					sceneScherm.spr_bal.p2.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.helm.visible) {
						toolstackremove(3);
						sceneScherm.spr_bal.helm.visible = false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("helm");
					} else {
						toolstack.push(3);
						sceneScherm.spr_bal.helm.visible = true;sceneScherm.toolbal3.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.helm.visible && sceneScherm.spr_bal.p1.currentFrame == 3 && sceneScherm.spr_bal.p2.currentFrame == 2) {
					if (instructieteller < 14) {
						instructieteller = 14;
						animinstr = 0;
					}
					leveldone();
				}
			} else if (sceneScherm.lvl==2) {
				if (toolused == 1||toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "geel";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p9.gotoAndStop(kleur);sceneScherm.spr_bal.b9p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {sceneScherm.spr_bal.b9p11.gotoAndStop(kleur); sceneScherm.spr_bal.b9p12.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p5.gotoAndStop(kleur); sceneScherm.spr_bal.b9p6.gotoAndStop(kleur); sceneScherm.spr_bal.b9p7.gotoAndStop(kleur); sceneScherm.spr_bal.b9p8.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible) {sceneScherm.spr_bal.b9p13.gotoAndStop(kleur); sceneScherm.spr_bal.b9p14.gotoAndStop(kleur); sceneScherm.spr_bal.b9p15.gotoAndStop(kleur); sceneScherm.spr_bal.b9p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p1.gotoAndStop(kleur); sceneScherm.spr_bal.b9p2.gotoAndStop(kleur); sceneScherm.spr_bal.b9p3.gotoAndStop(kleur); sceneScherm.spr_bal.b9p4.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b9p17.gotoAndStop(kleur); sceneScherm.spr_bal.b9p18.gotoAndStop(kleur); sceneScherm.spr_bal.b9p19.gotoAndStop(kleur); sceneScherm.spr_bal.b9p20.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible&&!sceneScherm.spr_bal.b9skibril.visible) {
						if (sceneScherm.spr_bal.b9skibrilklein.visible) {
							toolstackremove(3);
							sceneScherm.spr_bal.b9skibrilklein.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein");
						} else {
							toolstack.push(3);
							sceneScherm.spr_bal.b9skibrilklein.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilkleinweg");
						}
					}
				}
				if (!sceneScherm.spr_bal.b9skibrilklein.visible && sceneScherm.spr_bal.b9p1.currentFrame == 6 && sceneScherm.spr_bal.b9p9.currentFrame == 3) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==3) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "geel";} else if (toolused == 2) {kleur = "blauw";} else if (toolused == 3) {kleur = "zwart";}
					if (!sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p4.gotoAndStop(kleur);sceneScherm.spr_bal.b3p5.gotoAndStop(kleur);sceneScherm.spr_bal.b3p6.gotoAndStop(kleur);sceneScherm.spr_bal.b3p7.gotoAndStop(kleur);sceneScherm.spr_bal.b3p8.gotoAndStop(kleur);sceneScherm.spr_bal.b3p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed1.visible) {sceneScherm.spr_bal.b3p10.gotoAndStop(kleur);sceneScherm.spr_bal.b3p11.gotoAndStop(kleur);sceneScherm.spr_bal.b3p12.gotoAndStop(kleur);sceneScherm.spr_bal.b3p13.gotoAndStop(kleur);sceneScherm.spr_bal.b3p14.gotoAndStop(kleur);sceneScherm.spr_bal.b3p15.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p1.gotoAndStop(kleur);sceneScherm.spr_bal.b3p2.gotoAndStop(kleur);sceneScherm.spr_bal.b3p3.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b3p16.gotoAndStop(kleur);sceneScherm.spr_bal.b3p17.gotoAndStop(kleur);sceneScherm.spr_bal.b3p18.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3riembreed1.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreed");
					} else if (!sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3riembreed1.visible=true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreedweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b3helm.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3helm.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b3helm.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3helm.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible && sceneScherm.spr_bal.b3p1.currentFrame == 1 && sceneScherm.spr_bal.b3p4.currentFrame == 3 && sceneScherm.spr_bal.b3p10.currentFrame == 3 && sceneScherm.spr_bal.b3p16.currentFrame == 4) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==4) {
				if (toolused == 1||toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "rood";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p9.gotoAndStop(kleur);sceneScherm.spr_bal.b9p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {sceneScherm.spr_bal.b9p11.gotoAndStop(kleur); sceneScherm.spr_bal.b9p12.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p5.gotoAndStop(kleur); sceneScherm.spr_bal.b9p6.gotoAndStop(kleur); sceneScherm.spr_bal.b9p7.gotoAndStop(kleur); sceneScherm.spr_bal.b9p8.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible) {sceneScherm.spr_bal.b9p13.gotoAndStop(kleur); sceneScherm.spr_bal.b9p14.gotoAndStop(kleur); sceneScherm.spr_bal.b9p15.gotoAndStop(kleur); sceneScherm.spr_bal.b9p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p1.gotoAndStop(kleur); sceneScherm.spr_bal.b9p2.gotoAndStop(kleur); sceneScherm.spr_bal.b9p3.gotoAndStop(kleur); sceneScherm.spr_bal.b9p4.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b9p17.gotoAndStop(kleur); sceneScherm.spr_bal.b9p18.gotoAndStop(kleur); sceneScherm.spr_bal.b9p19.gotoAndStop(kleur); sceneScherm.spr_bal.b9p20.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible) {
						if (sceneScherm.spr_bal.b9skibril.visible) {
							toolstackremove(3);
							sceneScherm.spr_bal.b9skibril.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibril");
						} else {
							toolstack.push(3);
							sceneScherm.spr_bal.b9skibril.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilweg");
						}
					}
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible&&!sceneScherm.spr_bal.b9skibril.visible) {
						if (sceneScherm.spr_bal.b9skibrilklein.visible) {
							toolstackremove(4);
							sceneScherm.spr_bal.b9skibrilklein.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein");
						} else {
							toolstack.push(4);
							sceneScherm.spr_bal.b9skibrilklein.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilkleinweg");
						}
					}
				}
				if (!sceneScherm.spr_bal.b9helm.visible && !sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9skibrilklein.visible && sceneScherm.spr_bal.b9p1.currentFrame == 3 && sceneScherm.spr_bal.b9p5.currentFrame == 4 && sceneScherm.spr_bal.b9p9.currentFrame == 3 && sceneScherm.spr_bal.b9p11.currentFrame == 3 && sceneScherm.spr_bal.b9p13.currentFrame == 4 && sceneScherm.spr_bal.b9p17.currentFrame == 3) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==5) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "rood";
					else if (toolused == 2) kleur = "blauw";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible) {sceneScherm.spr_bal.b8p6.gotoAndStop(kleur);sceneScherm.spr_bal.b8p7.gotoAndStop(kleur);sceneScherm.spr_bal.b8p10.gotoAndStop(kleur);sceneScherm.spr_bal.b8p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8riemr.visible) { sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible) { sceneScherm.spr_bal.b8p3.gotoAndStop(kleur); sceneScherm.spr_bal.b8p14.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8rieml1.visible) {
						toolstackremove(4);
						sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("rieml");
					} else if (!sceneScherm.spr_bal.b8rieml2.visible){
						toolstack.push(4);
						sceneScherm.spr_bal.b8rieml1.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riemlweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8rieml1.visible&&sceneScherm.spr_bal.b8riemr.visible) {
						toolstackremove(5);
						sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemr");
						if (sceneScherm.spr_bal.b8rieml2.visible) {
							sceneScherm.spr_bal.b8rieml2.visible = false;
							sceneScherm.spr_bal.b8rieml1.visible = true;
						}
					} else if (!sceneScherm.spr_bal.b8riemr.visible){
						toolstack.push(5);
						sceneScherm.spr_bal.b8riemr.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemrweg");
						if (sceneScherm.spr_bal.b8rieml1.visible) {
							sceneScherm.spr_bal.b8rieml1.visible = false;
							sceneScherm.spr_bal.b8rieml2.visible = true;
						}
					}
				}
				if (!sceneScherm.spr_bal.b8riemr.visible && !sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible && sceneScherm.spr_bal.b8p1.currentFrame == 3 && sceneScherm.spr_bal.b8p3.currentFrame == 2 && sceneScherm.spr_bal.b8p4.currentFrame == 4 && sceneScherm.spr_bal.b8p6.currentFrame == 4) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==6) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "geel";} else if (toolused == 2) {kleur = "rood";} else kleur="blauw";
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p2.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p1.gotoAndStop(kleur);sceneScherm.spr_bal.b4p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4riemv.visible) { sceneScherm.spr_bal.b4p5.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) { sceneScherm.spr_bal.b4p4.gotoAndStop(kleur);sceneScherm.spr_bal.b4p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p7.gotoAndStop(kleur);sceneScherm.spr_bal.b4p8.gotoAndStop(kleur);sceneScherm.spr_bal.b4p10.gotoAndStop(kleur);sceneScherm.spr_bal.b4p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4riemv.visible) { sceneScherm.spr_bal.b4p14.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible ) { sceneScherm.spr_bal.b4p12.gotoAndStop(kleur); sceneScherm.spr_bal.b4p13.gotoAndStop(kleur); sceneScherm.spr_bal.b4p15.gotoAndStop(kleur); sceneScherm.spr_bal.b4p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible&& !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible) { sceneScherm.spr_bal.b4p17.gotoAndStop(kleur); sceneScherm.spr_bal.b4p19.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p21.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b4p20.gotoAndStop(kleur);sceneScherm.spr_bal.b4p22.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b4mutsonder.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsonder.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("mutsonder");
					} else if (!sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsonder.visible=true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("mutsonderweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsboven.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsboven");
					} else if (!sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsboven.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsbovenweg");
					}
				}
				if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && sceneScherm.spr_bal.b4p1.currentFrame == 3 && sceneScherm.spr_bal.b4p2.currentFrame == 3 && sceneScherm.spr_bal.b4p4.currentFrame == 4 && sceneScherm.spr_bal.b4p5.currentFrame == 4 && sceneScherm.spr_bal.b4p7.currentFrame == 4 && sceneScherm.spr_bal.b4p9.currentFrame == 4 && sceneScherm.spr_bal.b4p12.currentFrame == 4 && sceneScherm.spr_bal.b4p14.currentFrame == 4 && sceneScherm.spr_bal.b4p17.currentFrame == 4 && sceneScherm.spr_bal.b4p18.currentFrame == 4 && sceneScherm.spr_bal.b4p20.currentFrame == 2 && sceneScherm.spr_bal.b4p21.currentFrame == 2) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==7) {
				if (toolused == 1||toolused == 2||toolused == 3||toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "geel";} else if (toolused == 2) {kleur = "zwart";} else if (toolused == 3) {kleur = "oranje";} else if (toolused == 4) {kleur = "blauw";}
					if (!sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p4.gotoAndStop(kleur);sceneScherm.spr_bal.b3p5.gotoAndStop(kleur);sceneScherm.spr_bal.b3p6.gotoAndStop(kleur);sceneScherm.spr_bal.b3p7.gotoAndStop(kleur);sceneScherm.spr_bal.b3p8.gotoAndStop(kleur);sceneScherm.spr_bal.b3p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed1.visible) {sceneScherm.spr_bal.b3p10.gotoAndStop(kleur);sceneScherm.spr_bal.b3p11.gotoAndStop(kleur);sceneScherm.spr_bal.b3p12.gotoAndStop(kleur);sceneScherm.spr_bal.b3p13.gotoAndStop(kleur);sceneScherm.spr_bal.b3p14.gotoAndStop(kleur);sceneScherm.spr_bal.b3p15.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p1.gotoAndStop(kleur);sceneScherm.spr_bal.b3p2.gotoAndStop(kleur);sceneScherm.spr_bal.b3p3.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b3p16.gotoAndStop(kleur);sceneScherm.spr_bal.b3p17.gotoAndStop(kleur);sceneScherm.spr_bal.b3p18.gotoAndStop(kleur);
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3riembreed1.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riembreed");
					} else if (!sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3riembreed1.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riembreedweg");
					}
				} else if (toolused == 6) {
					if (sceneScherm.spr_bal.b3helm.visible) {
						toolstackremove(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3helm.visible=false;sceneScherm.toolbal6.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b3helm.visible) {
						toolstack.push(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3helm.visible=true;sceneScherm.toolbal6.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3helm.visible && sceneScherm.spr_bal.b3p1.currentFrame == 4 && sceneScherm.spr_bal.b3p4.currentFrame == 3 && sceneScherm.spr_bal.b3p10.currentFrame == 5 && sceneScherm.spr_bal.b3p16.currentFrame == 1) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==8) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "rood";
					else if (toolused == 2) kleur = "geel";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b7zorro.visible&&!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p5.gotoAndStop(kleur);sceneScherm.spr_bal.b7p6.gotoAndStop(kleur);sceneScherm.spr_bal.b7p15.gotoAndStop(kleur);sceneScherm.spr_bal.b7p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible) {sceneScherm.spr_bal.b7p3.gotoAndStop(kleur);sceneScherm.spr_bal.b7p4.gotoAndStop(kleur);sceneScherm.spr_bal.b7p17.gotoAndStop(kleur);sceneScherm.spr_bal.b7p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p7.gotoAndStop(kleur);sceneScherm.spr_bal.b7p8.gotoAndStop(kleur);sceneScherm.spr_bal.b7p9.gotoAndStop(kleur);sceneScherm.spr_bal.b7p10.gotoAndStop(kleur);sceneScherm.spr_bal.b7p11.gotoAndStop(kleur);sceneScherm.spr_bal.b7p12.gotoAndStop(kleur);sceneScherm.spr_bal.b7p13.gotoAndStop(kleur);sceneScherm.spr_bal.b7p14.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b7p1.gotoAndStop(kleur);sceneScherm.spr_bal.b7p2.gotoAndStop(kleur);sceneScherm.spr_bal.b7p19.gotoAndStop(kleur);sceneScherm.spr_bal.b7p20.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b7zorro.visible) {
						if (!sceneScherm.spr_bal.b7riem1.visible) {
							toolstackremove(4);
							sceneScherm.spr_bal.b7zorro.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("zorro");
						}
					} else {
						toolstack.push(4);
						sceneScherm.spr_bal.b7zorro.visible = true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("zorroweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b7riem1.visible) {
						toolstackremove(5);
						sceneScherm.spr_bal.b7riem1.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11");
					} else if (sceneScherm.spr_bal.b7riem2.visible) {
						if (!sceneScherm.spr_bal.b7zorro.visible) {
							toolstackremove(5);
							sceneScherm.spr_bal.b7riem2.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11");
						}
					} else {
						if (!sceneScherm.spr_bal.b7zorro.visible) {
							toolstack.push(5);
							sceneScherm.spr_bal.b7riem2.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11weg");
						} else {
							toolstack.push(5);
							sceneScherm.spr_bal.b7riem1.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11weg");
						}
					}
				}
				if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && sceneScherm.spr_bal.b7p1.currentFrame == 6 && sceneScherm.spr_bal.b7p3.currentFrame == 6 && sceneScherm.spr_bal.b7p5.currentFrame == 4 && sceneScherm.spr_bal.b7p7.currentFrame == 3) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==9) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "oranje";
					else if (toolused == 2) kleur = "paars";
					else kleur = "blauw";
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible) {sceneScherm.spr_bal.b8p6.gotoAndStop(kleur);sceneScherm.spr_bal.b8p7.gotoAndStop(kleur);sceneScherm.spr_bal.b8p10.gotoAndStop(kleur);sceneScherm.spr_bal.b8p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8riemr.visible) { sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible) { sceneScherm.spr_bal.b8p3.gotoAndStop(kleur); sceneScherm.spr_bal.b8p14.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8rieml1.visible) {
						toolstackremove(4);
						sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("rieml");
					} else if (!sceneScherm.spr_bal.b8rieml2.visible){
						toolstack.push(4);
						sceneScherm.spr_bal.b8rieml1.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riemlweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8rieml1.visible&&sceneScherm.spr_bal.b8riemr.visible) {
						toolstackremove(5);
						sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemr");
						if (sceneScherm.spr_bal.b8rieml2.visible) {
							sceneScherm.spr_bal.b8rieml2.visible = false;
							sceneScherm.spr_bal.b8rieml1.visible = true;
						}
					} else if (!sceneScherm.spr_bal.b8riemr.visible){
						toolstack.push(5);
						sceneScherm.spr_bal.b8riemr.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemrweg");
						if (sceneScherm.spr_bal.b8rieml1.visible) {
							sceneScherm.spr_bal.b8rieml1.visible = false;
							sceneScherm.spr_bal.b8rieml2.visible = true;
						}
					}
				} else if (toolused == 6) {
					toolstack = new Array();
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8rieml1.visible) { sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("rieml"); }
					if (sceneScherm.spr_bal.b8rieml2.visible) { sceneScherm.spr_bal.b8rieml2.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("rieml"); }
					if (sceneScherm.spr_bal.b8riemr.visible) { sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemr"); }
					kleur = "wit";
					sceneScherm.spr_bal.b8p6.gotoAndStop(kleur);sceneScherm.spr_bal.b8p7.gotoAndStop(kleur);sceneScherm.spr_bal.b8p10.gotoAndStop(kleur);sceneScherm.spr_bal.b8p11.gotoAndStop(kleur);
					sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);
					sceneScherm.spr_bal.b8p3.gotoAndStop(kleur); sceneScherm.spr_bal.b8p14.gotoAndStop(kleur);
					sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur);
				}
				if (!sceneScherm.spr_bal.b8riemr.visible && !sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible && sceneScherm.spr_bal.b8p1.currentFrame == 2 && sceneScherm.spr_bal.b8p3.currentFrame == 5 && sceneScherm.spr_bal.b8p4.currentFrame == 1 && sceneScherm.spr_bal.b8p6.currentFrame == 0) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==10) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "rood";
					else if (toolused == 2) kleur = "blauw";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p9.gotoAndStop(kleur);sceneScherm.spr_bal.b9p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {sceneScherm.spr_bal.b9p11.gotoAndStop(kleur); sceneScherm.spr_bal.b9p12.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p5.gotoAndStop(kleur); sceneScherm.spr_bal.b9p6.gotoAndStop(kleur); sceneScherm.spr_bal.b9p7.gotoAndStop(kleur); sceneScherm.spr_bal.b9p8.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible) {sceneScherm.spr_bal.b9p13.gotoAndStop(kleur); sceneScherm.spr_bal.b9p14.gotoAndStop(kleur); sceneScherm.spr_bal.b9p15.gotoAndStop(kleur); sceneScherm.spr_bal.b9p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p1.gotoAndStop(kleur); sceneScherm.spr_bal.b9p2.gotoAndStop(kleur); sceneScherm.spr_bal.b9p3.gotoAndStop(kleur); sceneScherm.spr_bal.b9p4.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b9p17.gotoAndStop(kleur); sceneScherm.spr_bal.b9p18.gotoAndStop(kleur); sceneScherm.spr_bal.b9p19.gotoAndStop(kleur); sceneScherm.spr_bal.b9p20.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible) {
						if (sceneScherm.spr_bal.b9skibril.visible) {
							toolstackremove(4);
							sceneScherm.spr_bal.b9skibril.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibril");
						} else {
							toolstack.push(4);
							sceneScherm.spr_bal.b9skibril.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilweg");
						}
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible&&!sceneScherm.spr_bal.b9skibril.visible) {
						if (sceneScherm.spr_bal.b9skibrilklein.visible) {
							toolstackremove(5);
							sceneScherm.spr_bal.b9skibrilklein.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("skibrilklein");
						} else {
							toolstack.push(5);
							sceneScherm.spr_bal.b9skibrilklein.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("skibrilkleinweg");
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b9helm.visible) {
						toolstackremove(6);
						sceneScherm.spr_bal.b9helm.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helm");
					} else {
						toolstack.push(6);
						sceneScherm.spr_bal.b9helm.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.b9helm.visible && !sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9skibrilklein.visible && sceneScherm.spr_bal.b9p1.currentFrame == 2 && sceneScherm.spr_bal.b9p5.currentFrame == 4 && sceneScherm.spr_bal.b9p9.currentFrame == 3 && sceneScherm.spr_bal.b9p11.currentFrame == 2 && sceneScherm.spr_bal.b9p13.currentFrame == 4 && sceneScherm.spr_bal.b9p17.currentFrame == 2) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==11) {
				if (toolused == 1||toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "blauw";} else if (toolused == 2) {kleur = "oranje";}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible) {sceneScherm.spr_bal.b3p3.gotoAndStop(kleur);sceneScherm.spr_bal.b3p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible) {sceneScherm.spr_bal.b3p6.gotoAndStop(kleur);sceneScherm.spr_bal.b3p15.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible&& !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3riem.visible) {sceneScherm.spr_bal.b3p9.gotoAndStop(kleur);sceneScherm.spr_bal.b3p12.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible) {sceneScherm.spr_bal.b3p4.gotoAndStop(kleur);sceneScherm.spr_bal.b3p5.gotoAndStop(kleur);sceneScherm.spr_bal.b3p13.gotoAndStop(kleur);sceneScherm.spr_bal.b3p14.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3riem.visible) {sceneScherm.spr_bal.b3p7.gotoAndStop(kleur);sceneScherm.spr_bal.b3p8.gotoAndStop(kleur);sceneScherm.spr_bal.b3p10.gotoAndStop(kleur);sceneScherm.spr_bal.b3p11.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b3p1.gotoAndStop(kleur);sceneScherm.spr_bal.b3p2.gotoAndStop(kleur);sceneScherm.spr_bal.b3p16.gotoAndStop(kleur);sceneScherm.spr_bal.b3p17.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (laag1 == "riem" || laag2 == "riem" || laag3 == "riem") {
						if (laag3 == "riem") {
							toolstackremove(3);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag3 = ""; sceneScherm.spr_bal.b3riem.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("riem");
							if (laag2 == "v") {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; }
							else {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = true;sceneScherm.spr_bal.b3riembreed2.visible = false;}
						} else if (laag2 == "riem" && laag3=="") {
							toolstackremove(3);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag2 = ""; sceneScherm.spr_bal.b3riem.visible=false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riem");							
							if (laag1 == "v") {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;}
							else {sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false;}
						} else if (laag1 == "riem" && laag2=="" && laag3=="") {
							toolstackremove(3);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = ""; sceneScherm.spr_bal.b3riem.visible=false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riem");							
						}
					} else if (laag1 != "riem" && laag2 != "riem" && laag3 != "riem") {
						if (laag1 == "" && laag2 == "" && laag3 == "") {
							toolstack.push(3);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = "riem"; sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemweg");
						} else if (laag2 == "" && laag3 == "") {
							laag2 = "riem";
							if (laag1 == "breed") {
								toolstack.push(3);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemweg");
							} else if (laag1 == "v") {
								toolstack.push(3);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemweg");
							}
						} else if (laag3 == "") {
							laag3 = "riem";
							if (laag1 == "breed" && laag2 == "v") {
								toolstack.push(3);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemweg");
							} else if (laag1 == "v" && laag2 == "breed") {
								toolstack.push(3);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemweg");
							}
						}
					}
				} else if (toolused == 4) {
					if (laag1 == "breed" || laag2 == "breed" || laag3 == "breed") {
						if (laag3 == "breed") {
							toolstackremove(4);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag3 = ""; sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreed");
							if (laag2 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false; }
							else {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = true; }
						} else if (laag2 == "breed" && laag3=="") {
							toolstackremove(4);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag2 = ""; sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreed");							
							if (laag1 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;}
							else {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false; }
						} else if (laag1 == "breed" && laag2=="" && laag3=="") {
							toolstackremove(4);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = ""; sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreed");							
						}
					} else if (laag1 != "breed" && laag2 != "breed" && laag3 != "breed") {
						if (laag1 == "" && laag2 == "" && laag3 == "") {
							toolstack.push(4);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = "breed"; sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreedweg");
						} else if (laag2 == "" && laag3 == "") {
							laag2 = "breed";
							if (laag1 == "riem") {
								toolstack.push(4);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = true; 
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = true;
								sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreedweg");
							} else if (laag1 == "v") {
								toolstack.push(4);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreedweg");
							}
						} else if (laag3 == "") {
							laag3 = "breed";
							if (laag1 == "riem" && laag2 == "v") {
								toolstack.push(4);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreedweg");
							} else if (laag1 == "v" && laag2 == "riem") {
								toolstack.push(4);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.toolbal4.toolsmovie.gotoAndStop("riembreedweg");
							}
						}
					}
				} else if (toolused == 5) {
					if (laag1 == "v" || laag2 == "v" || laag3 == "v") {
						if (laag3 == "v") {
							toolstackremove(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag3 = ""; sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemv");
							if (laag2 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; }
							else {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = true;}
						} else if (laag2 == "v" && laag3=="") {
							toolstackremove(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag2 = ""; sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemv");						
							if (laag1 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;}
							else {sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false;}
						} else if (laag1 == "v" && laag2=="" && laag3=="") {
							toolstackremove(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = ""; sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemv");							
						}
					} else if (laag1 != "v" && laag2 != "v" && laag3 != "v") {
						if (laag1 == "" && laag2 == "" && laag3 == "") {
							toolstack.push(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = "v"; sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemvweg");
						} else if (laag2 == "" && laag3 == "") {
							laag2 = "v";
							if (laag1 == "breed") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemvweg");
							} else if (laag1 == "riem") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = true; 
								sceneScherm.spr_bal.b3riemv1.visible = false; sceneScherm.spr_bal.b3riemv2.visible = true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemvweg");
							}
						} else if (laag3 == "") {
							laag3 = "v";
							if (laag1 == "breed" && laag2 == "riem") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true;
								sceneScherm.spr_bal.b3riemv1.visible = false; sceneScherm.spr_bal.b3riemv2.visible = true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemvweg");
							} else if (laag1 == "riem" && laag2 == "breed") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemvweg");
							}
						}
					}
				}
				if (!sceneScherm.spr_bal.b3riem.visible && !sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && sceneScherm.spr_bal.b3p1.currentFrame == 1 && sceneScherm.spr_bal.b3p3.currentFrame == 1 && sceneScherm.spr_bal.b3p4.currentFrame == 5 && sceneScherm.spr_bal.b3p6.currentFrame == 5 && sceneScherm.spr_bal.b3p7.currentFrame == 5 && sceneScherm.spr_bal.b3p9.currentFrame == 1 && sceneScherm.spr_bal.b3p13.currentFrame == 5 && sceneScherm.spr_bal.b3p15.currentFrame == 5 && sceneScherm.spr_bal.b3p16.currentFrame == 1 && sceneScherm.spr_bal.b3p18.currentFrame == 1) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==12) {
				if (toolused == 1) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6p1.visible && !sceneScherm.spr_bal.b6helm.visible) sceneScherm.spr_bal.b6gras01.visible = true;
					if (!sceneScherm.spr_bal.b6p2.visible && !sceneScherm.spr_bal.b6helm.visible) sceneScherm.spr_bal.b6gras02.visible = true;
					if (!sceneScherm.spr_bal.b6p3.visible) sceneScherm.spr_bal.b6gras03.visible = true;
					if (!sceneScherm.spr_bal.b6p4.visible) sceneScherm.spr_bal.b6gras04.visible = true;
				} else if (toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6bloemwit1.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6bloemwit1.visible = true; sceneScherm.spr_bal.b6bloemwit1.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit2.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6bloemwit2.visible = true; sceneScherm.spr_bal.b6bloemwit2.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit3.visible) { sceneScherm.spr_bal.b6bloemwit3.visible = true; sceneScherm.spr_bal.b6bloemwit3.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit4.visible) { sceneScherm.spr_bal.b6bloemwit4.visible = true; sceneScherm.spr_bal.b6bloemwit4.gotoAndStop(0);}
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndwater");
					if (sceneScherm.spr_bal.b6p1.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6p1.currentFrame == 0) sceneScherm.spr_bal.b6p1.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p1.currentFrame == 1) sceneScherm.spr_bal.b6p1.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p2.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6p2.currentFrame == 0) sceneScherm.spr_bal.b6p2.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p2.currentFrame == 1) sceneScherm.spr_bal.b6p2.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p3.visible) { 
						if (sceneScherm.spr_bal.b6p3.currentFrame == 0) sceneScherm.spr_bal.b6p3.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p3.currentFrame == 1) sceneScherm.spr_bal.b6p3.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p4.visible) { 
						if (sceneScherm.spr_bal.b6p4.currentFrame == 0) sceneScherm.spr_bal.b6p4.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p4.currentFrame == 1) sceneScherm.spr_bal.b6p4.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6gras01.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6p1.visible = true; sceneScherm.spr_bal.b6p1.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras02.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6p2.visible = true; sceneScherm.spr_bal.b6p2.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras03.visible) { sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6p3.visible = true; sceneScherm.spr_bal.b6p3.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras04.visible) { sceneScherm.spr_bal.b6gras04.visible = false; sceneScherm.spr_bal.b6p4.visible = true; sceneScherm.spr_bal.b6p4.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6bloemwit1.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit1.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit1.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit1.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit2.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit2.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit2.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit2.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit3.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit3.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit3.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit3.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit4.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit4.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit4.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit4.visible=false;
					}
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b6helm.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6helm.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b6helm.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6helm.visible=true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helmweg");
					}
				} else if (toolused == 5) {
					toolstack = new Array();
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b6helm.visible) {sceneScherm.spr_bal.b6helm.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helm");}
					sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6gras04.visible = false;
					sceneScherm.spr_bal.b6p1.visible = false;sceneScherm.spr_bal.b6p2.visible = false;sceneScherm.spr_bal.b6p3.visible = false;sceneScherm.spr_bal.b6p4.visible = false;
					sceneScherm.spr_bal.b6bloemwit1.visible = false; sceneScherm.spr_bal.b6bloemwit2.visible = false; sceneScherm.spr_bal.b6bloemwit3.visible = false; sceneScherm.spr_bal.b6bloemwit4.visible = false;
					sceneScherm.spr_bal.b6bloemblauw1.visible = false; sceneScherm.spr_bal.b6bloemblauw2.visible = false; sceneScherm.spr_bal.b6bloemblauw3.visible = false; sceneScherm.spr_bal.b6bloemblauw4.visible = false;
				}
				if (!sceneScherm.spr_bal.b6helm.visible && sceneScherm.spr_bal.b6p1.visible && sceneScherm.spr_bal.b6p1.currentFrame==1 && !sceneScherm.spr_bal.b6bloemwit1.visible && sceneScherm.spr_bal.b6p4.visible && sceneScherm.spr_bal.b6p4.currentFrame==2 && sceneScherm.spr_bal.b6bloemwit4.visible && sceneScherm.spr_bal.b6bloemwit4.currentFrame == 2) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==13) {
				if (toolused == 1||toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "geel";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7helm.visible) { sceneScherm.spr_bal.b7p5.gotoAndStop(kleur); sceneScherm.spr_bal.b7p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p15.gotoAndStop(kleur); sceneScherm.spr_bal.b7p16.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p3.gotoAndStop(kleur);sceneScherm.spr_bal.b7p4.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible) {sceneScherm.spr_bal.b7p17.gotoAndStop(kleur);sceneScherm.spr_bal.b7p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible&&!sceneScherm.spr_bal.b7skibrilklein4.visible && !sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p8.gotoAndStop(kleur);sceneScherm.spr_bal.b7p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible&&!sceneScherm.spr_bal.b7skibrilklein4.visible) {sceneScherm.spr_bal.b7p11.gotoAndStop(kleur);sceneScherm.spr_bal.b7p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7helm.visible) { sceneScherm.spr_bal.b7p7.gotoAndStop(kleur); sceneScherm.spr_bal.b7p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p12.gotoAndStop(kleur); sceneScherm.spr_bal.b7p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p1.gotoAndStop(kleur);sceneScherm.spr_bal.b7p2.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b7p19.gotoAndStop(kleur);sceneScherm.spr_bal.b7p20.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b7helm.visible) {
						if (sceneScherm.spr_bal.b7skibrilklein1.visible) {
							toolstackremove(3);
							sceneScherm.spr_bal.b7skibrilklein1.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11");
						} else if (sceneScherm.spr_bal.b7skibrilklein2.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible) {
								toolstackremove(3);
								sceneScherm.spr_bal.b7skibrilklein2.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11");
							}
						} else if (sceneScherm.spr_bal.b7skibrilklein3.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7zorro.visible) {
								toolstackremove(3);
								sceneScherm.spr_bal.b7skibrilklein3.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11");
							}
						} else if (sceneScherm.spr_bal.b7skibrilklein4.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem2.visible) {
								toolstackremove(3);
								sceneScherm.spr_bal.b7skibrilklein4.visible = false; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11");
							}
						} else {
							if (sceneScherm.spr_bal.b7riem1.visible) {
								toolstack.push(3);
								sceneScherm.spr_bal.b7skibrilklein1.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11weg");
							} else if (sceneScherm.spr_bal.b7zorro.visible) {
								toolstack.push(3);
								sceneScherm.spr_bal.b7skibrilklein2.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11weg");
							} else if (sceneScherm.spr_bal.b7riem2.visible) {
								toolstack.push(3);
								sceneScherm.spr_bal.b7skibrilklein3.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11weg");
							} else {
								toolstack.push(3);
								sceneScherm.spr_bal.b7skibrilklein4.visible = true; sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11weg");
							}
						}
					}
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b7helm.visible) {
						if (sceneScherm.spr_bal.b7zorro.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7skibrilklein1.visible && !sceneScherm.spr_bal.b7skibrilklein2.visible) {
								toolstackremove(4);
								sceneScherm.spr_bal.b7zorro.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("zorro");
							}
						} else {
							toolstack.push(4);
							sceneScherm.spr_bal.b7zorro.visible = true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("zorroweg");
						}
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b7helm.visible) {
						if (sceneScherm.spr_bal.b7riem1.visible) {
							if (!sceneScherm.spr_bal.b7skibrilklein1.visible) {
								toolstackremove(5);
								sceneScherm.spr_bal.b7riem1.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11");
							}
						} else if (sceneScherm.spr_bal.b7riem2.visible) {
							if (!sceneScherm.spr_bal.b7zorro.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible) {
								toolstackremove(5);
								sceneScherm.spr_bal.b7riem2.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11");
							}
						} else {
							if (sceneScherm.spr_bal.b7skibrilklein2.visible||sceneScherm.spr_bal.b7zorro.visible||sceneScherm.spr_bal.b7skibrilklein3.visible) {
								toolstack.push(5);
								sceneScherm.spr_bal.b7riem1.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11weg");
							} else {
								toolstack.push(5);
								sceneScherm.spr_bal.b7riem2.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11weg");
							}
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b7helm.visible) {
						toolstackremove(6);
						sceneScherm.spr_bal.b7helm.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helm");
					} else {
						toolstack.push(6);
						sceneScherm.spr_bal.b7helm.visible = true;sceneScherm.toolbal6.toolsmovie.gotoAndStop("helmweg");
					}
				} else if (toolused == 7) {
					toolstack = new Array();
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b7skibrilklein1.visible) { sceneScherm.spr_bal.b7skibrilklein1.visible = false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11") }
					if (sceneScherm.spr_bal.b7skibrilklein2.visible) { sceneScherm.spr_bal.b7skibrilklein2.visible = false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11") }
					if (sceneScherm.spr_bal.b7skibrilklein3.visible) { sceneScherm.spr_bal.b7skibrilklein3.visible = false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11") }
					if (sceneScherm.spr_bal.b7skibrilklein4.visible) { sceneScherm.spr_bal.b7skibrilklein4.visible = false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("skibrilklein11") }
					if (sceneScherm.spr_bal.b7zorro.visible) { sceneScherm.spr_bal.b7zorro.visible = false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("zorro") }
					if (sceneScherm.spr_bal.b7riem1.visible) { sceneScherm.spr_bal.b7riem1.visible = false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11") }
					if (sceneScherm.spr_bal.b7riem2.visible) { sceneScherm.spr_bal.b7riem2.visible = false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem11") }
					if (sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7helm.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helm");}
					kleur = "wit";
					sceneScherm.spr_bal.b7p5.gotoAndStop(kleur);sceneScherm.spr_bal.b7p6.gotoAndStop(kleur);sceneScherm.spr_bal.b7p15.gotoAndStop(kleur);sceneScherm.spr_bal.b7p16.gotoAndStop(kleur);
					sceneScherm.spr_bal.b7p3.gotoAndStop(kleur);sceneScherm.spr_bal.b7p4.gotoAndStop(kleur);sceneScherm.spr_bal.b7p17.gotoAndStop(kleur);sceneScherm.spr_bal.b7p18.gotoAndStop(kleur);
					sceneScherm.spr_bal.b7p8.gotoAndStop(kleur);sceneScherm.spr_bal.b7p10.gotoAndStop(kleur);sceneScherm.spr_bal.b7p11.gotoAndStop(kleur);sceneScherm.spr_bal.b7p13.gotoAndStop(kleur);
					sceneScherm.spr_bal.b7p7.gotoAndStop(kleur);sceneScherm.spr_bal.b7p9.gotoAndStop(kleur);sceneScherm.spr_bal.b7p12.gotoAndStop(kleur);sceneScherm.spr_bal.b7p14.gotoAndStop(kleur);
					sceneScherm.spr_bal.b7p1.gotoAndStop(kleur);sceneScherm.spr_bal.b7p2.gotoAndStop(kleur);sceneScherm.spr_bal.b7p19.gotoAndStop(kleur);sceneScherm.spr_bal.b7p20.gotoAndStop(kleur);
				}
				if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7skibrilklein1.visible && !sceneScherm.spr_bal.b7skibrilklein2.visible && !sceneScherm.spr_bal.b7skibrilklein3.visible && !sceneScherm.spr_bal.b7skibrilklein4.visible && !sceneScherm.spr_bal.b7helm.visible && sceneScherm.spr_bal.b7p1.currentFrame == 6 && sceneScherm.spr_bal.b7p3.currentFrame == 3 && sceneScherm.spr_bal.b7p5.currentFrame == 6 && sceneScherm.spr_bal.b7p7.currentFrame == 3 && sceneScherm.spr_bal.b7p8.currentFrame == 0 && sceneScherm.spr_bal.b7p11.currentFrame == 0 && sceneScherm.spr_bal.b7p12.currentFrame == 3 && sceneScherm.spr_bal.b7p15.currentFrame == 6 && sceneScherm.spr_bal.b7p17.currentFrame == 6 && sceneScherm.spr_bal.b7p19.currentFrame == 6) {
					leveldone ();
				}
			}
		}
		
		function dologica2 (toolused) {
			if (sceneScherm.lvl==14) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "geel";
					else if (toolused == 2) kleur = "rood";
					else kleur = "blauw";
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible&&!sceneScherm.spr_bal.b8helm.visible) {sceneScherm.spr_bal.b8p6.gotoAndStop(kleur);sceneScherm.spr_bal.b8p7.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible) {sceneScherm.spr_bal.b8p10.gotoAndStop(kleur);sceneScherm.spr_bal.b8p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8helm.visible) { sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8riemr.visible) {sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible&&!sceneScherm.spr_bal.b8helm.visible) { sceneScherm.spr_bal.b8p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible) { sceneScherm.spr_bal.b8p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8helm.visible) {sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); }
					sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8rieml1.visible) {
							toolstackremove(4);
							sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("rieml");
						} else if (!sceneScherm.spr_bal.b8rieml2.visible){
							toolstack.push(4);
							sceneScherm.spr_bal.b8rieml1.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riemlweg");
						}
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (!sceneScherm.spr_bal.b8rieml1.visible&&sceneScherm.spr_bal.b8riemr.visible) {
							toolstackremove(5);
							sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemr");
							if (sceneScherm.spr_bal.b8rieml2.visible) {
								sceneScherm.spr_bal.b8rieml2.visible = false;
								sceneScherm.spr_bal.b8rieml1.visible = true;
							}
						} else if (!sceneScherm.spr_bal.b8riemr.visible){
							toolstack.push(5);
							sceneScherm.spr_bal.b8riemr.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemrweg");
							if (sceneScherm.spr_bal.b8rieml1.visible) {
								sceneScherm.spr_bal.b8rieml1.visible = false;
								sceneScherm.spr_bal.b8rieml2.visible = true;
							}
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8helm.visible) {
						toolstackremove(6);
						sceneScherm.spr_bal.b8helm.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b8helm.visible){
						toolstack.push(6);
						sceneScherm.spr_bal.b8helm.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.b8riemr.visible && !sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible && !sceneScherm.spr_bal.b8helm.visible && sceneScherm.spr_bal.b8p1.currentFrame == 6 && sceneScherm.spr_bal.b8p3.currentFrame == 6 && sceneScherm.spr_bal.b8p4.currentFrame == 4 && sceneScherm.spr_bal.b8p5.currentFrame == 6 && sceneScherm.spr_bal.b8p6.currentFrame == 4 && sceneScherm.spr_bal.b8p7.currentFrame == 4 && sceneScherm.spr_bal.b8p9.currentFrame == 6 && sceneScherm.spr_bal.b8p10.currentFrame == 2 && sceneScherm.spr_bal.b8p11.currentFrame == 2 && sceneScherm.spr_bal.b8p13.currentFrame == 6 && sceneScherm.spr_bal.b8p14.currentFrame == 2 && sceneScherm.spr_bal.b8p15.currentFrame == 6) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==15) {
				if (toolused == 1||toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "rood";} else if (toolused == 2) {kleur = "geel";}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p2.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p1.gotoAndStop(kleur);sceneScherm.spr_bal.b4p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4riemv.visible) { sceneScherm.spr_bal.b4p5.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) { sceneScherm.spr_bal.b4p4.gotoAndStop(kleur);sceneScherm.spr_bal.b4p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p7.gotoAndStop(kleur);sceneScherm.spr_bal.b4p8.gotoAndStop(kleur);sceneScherm.spr_bal.b4p10.gotoAndStop(kleur);sceneScherm.spr_bal.b4p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4riemv.visible) { sceneScherm.spr_bal.b4p14.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible ) { sceneScherm.spr_bal.b4p12.gotoAndStop(kleur); sceneScherm.spr_bal.b4p13.gotoAndStop(kleur); sceneScherm.spr_bal.b4p15.gotoAndStop(kleur); sceneScherm.spr_bal.b4p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible&& !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible) { sceneScherm.spr_bal.b4p17.gotoAndStop(kleur); sceneScherm.spr_bal.b4p19.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p21.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b4p20.gotoAndStop(kleur);sceneScherm.spr_bal.b4p22.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstackremove(3);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riemv.visible=false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemv");
					} else if (!sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstack.push(3);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riemv.visible=true;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riemvweg");
					}
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b4helm.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4helm.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helmrot");
					} else if (!sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4helm.visible=true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helmrotweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b4mutsonder.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsonder.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsonder");
					} else if (!sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsonder.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsonderweg");
					}
				} else if (toolused == 6) {
					if (sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstackremove(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsboven.visible=false;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsboven");
					} else if (!sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible) {
						toolstack.push(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsboven.visible=true;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsbovenweg");
					}
				}
				if (!sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible && sceneScherm.spr_bal.b4p1.currentFrame == 4 && sceneScherm.spr_bal.b4p2.currentFrame == 4 && sceneScherm.spr_bal.b4p4.currentFrame == 4 && sceneScherm.spr_bal.b4p5.currentFrame == 3 && sceneScherm.spr_bal.b4p7.currentFrame == 4 && sceneScherm.spr_bal.b4p9.currentFrame == 3 && sceneScherm.spr_bal.b4p12.currentFrame == 3 && sceneScherm.spr_bal.b4p14.currentFrame == 4 && sceneScherm.spr_bal.b4p17.currentFrame == 3 && sceneScherm.spr_bal.b4p18.currentFrame == 4 && sceneScherm.spr_bal.b4p20.currentFrame == 3 && sceneScherm.spr_bal.b4p21.currentFrame == 3) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==16) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "rood";
					else if (toolused == 2) kleur = "blauw";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible&&!sceneScherm.spr_bal.b8helm.visible) {sceneScherm.spr_bal.b8p6.gotoAndStop(kleur);sceneScherm.spr_bal.b8p7.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible) {sceneScherm.spr_bal.b8p10.gotoAndStop(kleur);sceneScherm.spr_bal.b8p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8helm.visible) { sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8riemr.visible) {sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8rieml2.visible&&!sceneScherm.spr_bal.b8helm.visible) { sceneScherm.spr_bal.b8p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible) { sceneScherm.spr_bal.b8p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8helm.visible) {sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); }
					sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8rieml1.visible) {
							toolstackremove(4);
							sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("rieml");
						} else if (!sceneScherm.spr_bal.b8rieml2.visible){
							toolstack.push(4);
							sceneScherm.spr_bal.b8rieml1.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("riemlweg");
						}
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (!sceneScherm.spr_bal.b8rieml1.visible&&sceneScherm.spr_bal.b8riemr.visible) {
							toolstackremove(5);
							sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemr");
							if (sceneScherm.spr_bal.b8rieml2.visible) {
								sceneScherm.spr_bal.b8rieml2.visible = false;
								sceneScherm.spr_bal.b8rieml1.visible = true;
							}
						} else if (!sceneScherm.spr_bal.b8riemr.visible){
							toolstack.push(5);
							sceneScherm.spr_bal.b8riemr.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemrweg");
							if (sceneScherm.spr_bal.b8rieml1.visible) {
								sceneScherm.spr_bal.b8rieml1.visible = false;
								sceneScherm.spr_bal.b8rieml2.visible = true;
							}
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8helm.visible) {
						toolstackremove(6);
						sceneScherm.spr_bal.b8helm.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b8helm.visible){
						toolstack.push(6);
						sceneScherm.spr_bal.b8helm.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.b8riemr.visible && !sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible && !sceneScherm.spr_bal.b8helm.visible && sceneScherm.spr_bal.b8p1.currentFrame == 3 && sceneScherm.spr_bal.b8p3.currentFrame == 4 && sceneScherm.spr_bal.b8p4.currentFrame == 2 && sceneScherm.spr_bal.b8p5.currentFrame == 3 && sceneScherm.spr_bal.b8p6.currentFrame == 3 && sceneScherm.spr_bal.b8p7.currentFrame == 3 && sceneScherm.spr_bal.b8p9.currentFrame == 3 && sceneScherm.spr_bal.b8p10.currentFrame == 3 && sceneScherm.spr_bal.b8p11.currentFrame == 3 && sceneScherm.spr_bal.b8p13.currentFrame == 3 && sceneScherm.spr_bal.b8p14.currentFrame == 3 && sceneScherm.spr_bal.b8p15.currentFrame == 3) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==17) {
				if (toolused == 1) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6p1.visible && !sceneScherm.spr_bal.b6helm.visible) sceneScherm.spr_bal.b6gras01.visible = true;
					if (!sceneScherm.spr_bal.b6p2.visible && !sceneScherm.spr_bal.b6helm.visible) sceneScherm.spr_bal.b6gras02.visible = true;
					if (!sceneScherm.spr_bal.b6p3.visible) sceneScherm.spr_bal.b6gras03.visible = true;
					if (!sceneScherm.spr_bal.b6p4.visible) sceneScherm.spr_bal.b6gras04.visible = true;
				} else if (toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6bloemwit1.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6bloemwit1.visible = true; sceneScherm.spr_bal.b6bloemwit1.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit2.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6bloemwit2.visible = true; sceneScherm.spr_bal.b6bloemwit2.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit3.visible) { sceneScherm.spr_bal.b6bloemwit3.visible = true; sceneScherm.spr_bal.b6bloemwit3.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit4.visible) { sceneScherm.spr_bal.b6bloemwit4.visible = true; sceneScherm.spr_bal.b6bloemwit4.gotoAndStop(0);}
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6bloemblauw1.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6bloemblauw1.visible = true; sceneScherm.spr_bal.b6bloemblauw1.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemblauw2.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6bloemblauw2.visible = true; sceneScherm.spr_bal.b6bloemblauw2.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemblauw3.visible) { sceneScherm.spr_bal.b6bloemblauw3.visible = true; sceneScherm.spr_bal.b6bloemblauw3.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemblauw4.visible) { sceneScherm.spr_bal.b6bloemblauw4.visible = true; sceneScherm.spr_bal.b6bloemblauw4.gotoAndStop(0);}
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndwater");
					if (sceneScherm.spr_bal.b6p1.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6p1.currentFrame == 0) sceneScherm.spr_bal.b6p1.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p1.currentFrame == 1) sceneScherm.spr_bal.b6p1.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p2.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6p2.currentFrame == 0) sceneScherm.spr_bal.b6p2.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p2.currentFrame == 1) sceneScherm.spr_bal.b6p2.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p3.visible) { 
						if (sceneScherm.spr_bal.b6p3.currentFrame == 0) sceneScherm.spr_bal.b6p3.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p3.currentFrame == 1) sceneScherm.spr_bal.b6p3.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p4.visible) { 
						if (sceneScherm.spr_bal.b6p4.currentFrame == 0) sceneScherm.spr_bal.b6p4.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p4.currentFrame == 1) sceneScherm.spr_bal.b6p4.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6gras01.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6p1.visible = true; sceneScherm.spr_bal.b6p1.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras02.visible && !sceneScherm.spr_bal.b6helm.visible) { sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6p2.visible = true; sceneScherm.spr_bal.b6p2.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras03.visible) { sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6p3.visible = true; sceneScherm.spr_bal.b6p3.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras04.visible) { sceneScherm.spr_bal.b6gras04.visible = false; sceneScherm.spr_bal.b6p4.visible = true; sceneScherm.spr_bal.b6p4.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6bloemwit1.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit1.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit1.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit1.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit2.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit2.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit2.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit2.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit3.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit3.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit3.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit3.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit4.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit4.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit4.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit4.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemblauw1.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6bloemblauw1.currentFrame == 0) sceneScherm.spr_bal.b6bloemblauw1.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemblauw1.currentFrame == 1) sceneScherm.spr_bal.b6bloemblauw1.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemblauw1.currentFrame == 2) sceneScherm.spr_bal.b6bloemblauw1.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemblauw2.visible && !sceneScherm.spr_bal.b6helm.visible) { 
						if (sceneScherm.spr_bal.b6bloemblauw2.currentFrame == 0) sceneScherm.spr_bal.b6bloemblauw2.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemblauw2.currentFrame == 1) sceneScherm.spr_bal.b6bloemblauw2.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemblauw2.currentFrame == 2) sceneScherm.spr_bal.b6bloemblauw2.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemblauw3.visible) { 
						if (sceneScherm.spr_bal.b6bloemblauw3.currentFrame == 0) sceneScherm.spr_bal.b6bloemblauw3.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemblauw3.currentFrame == 1) sceneScherm.spr_bal.b6bloemblauw3.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemblauw3.currentFrame == 2) sceneScherm.spr_bal.b6bloemblauw3.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemblauw4.visible) { 
						if (sceneScherm.spr_bal.b6bloemblauw4.currentFrame == 0) sceneScherm.spr_bal.b6bloemblauw4.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemblauw4.currentFrame == 1) sceneScherm.spr_bal.b6bloemblauw4.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemblauw4.currentFrame == 2) sceneScherm.spr_bal.b6bloemblauw4.visible=false;
					}
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b6helm.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6helm.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b6helm.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6helm.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("helmweg");
					}
				} else if (toolused == 6) {
					toolstack = new Array();
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b6helm.visible) {sceneScherm.spr_bal.b6helm.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("helm");}
					sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6gras04.visible = false;
					sceneScherm.spr_bal.b6p1.visible = false;sceneScherm.spr_bal.b6p2.visible = false;sceneScherm.spr_bal.b6p3.visible = false;sceneScherm.spr_bal.b6p4.visible = false;
					sceneScherm.spr_bal.b6bloemwit1.visible = false; sceneScherm.spr_bal.b6bloemwit2.visible = false; sceneScherm.spr_bal.b6bloemwit3.visible = false; sceneScherm.spr_bal.b6bloemwit4.visible = false;
					sceneScherm.spr_bal.b6bloemblauw1.visible = false; sceneScherm.spr_bal.b6bloemblauw2.visible = false; sceneScherm.spr_bal.b6bloemblauw3.visible = false; sceneScherm.spr_bal.b6bloemblauw4.visible = false;
				}
				if (!sceneScherm.spr_bal.b6helm.visible && sceneScherm.spr_bal.b6p1.visible && sceneScherm.spr_bal.b6p1.currentFrame==0 && sceneScherm.spr_bal.b6bloemblauw1.visible && sceneScherm.spr_bal.b6bloemblauw1.currentFrame == 2 && !sceneScherm.spr_bal.b6bloemwit1.visible && sceneScherm.spr_bal.b6p4.visible && sceneScherm.spr_bal.b6p4.currentFrame==1 && sceneScherm.spr_bal.b6bloemwit4.visible && sceneScherm.spr_bal.b6bloemwit4.currentFrame == 1 && !sceneScherm.spr_bal.b6bloemblauw4.visible) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==18||sceneScherm.lvl==22) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "rood";
					else if (toolused == 2) kleur = "blauw";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7helm.visible) { sceneScherm.spr_bal.b7p5.gotoAndStop(kleur); sceneScherm.spr_bal.b7p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p15.gotoAndStop(kleur); sceneScherm.spr_bal.b7p16.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p3.gotoAndStop(kleur);sceneScherm.spr_bal.b7p4.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible) {sceneScherm.spr_bal.b7p17.gotoAndStop(kleur);sceneScherm.spr_bal.b7p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible&&!sceneScherm.spr_bal.b7skibrilklein4.visible && !sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p8.gotoAndStop(kleur);sceneScherm.spr_bal.b7p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible&&!sceneScherm.spr_bal.b7skibrilklein4.visible) {sceneScherm.spr_bal.b7p11.gotoAndStop(kleur);sceneScherm.spr_bal.b7p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7helm.visible) { sceneScherm.spr_bal.b7p7.gotoAndStop(kleur); sceneScherm.spr_bal.b7p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p12.gotoAndStop(kleur); sceneScherm.spr_bal.b7p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p1.gotoAndStop(kleur);sceneScherm.spr_bal.b7p2.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b7p19.gotoAndStop(kleur);sceneScherm.spr_bal.b7p20.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b7helm.visible) {
						if (sceneScherm.spr_bal.b7skibrilklein1.visible) {
							toolstackremove(4);
							sceneScherm.spr_bal.b7skibrilklein1.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11");
						} else if (sceneScherm.spr_bal.b7skibrilklein2.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible) {
								toolstackremove(4);
								sceneScherm.spr_bal.b7skibrilklein2.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11");
							}
						} else if (sceneScherm.spr_bal.b7skibrilklein3.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7zorro.visible) {
								toolstackremove(4);
								sceneScherm.spr_bal.b7skibrilklein3.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11");
							}
						} else if (sceneScherm.spr_bal.b7skibrilklein4.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem2.visible) {
								toolstackremove(4);
								sceneScherm.spr_bal.b7skibrilklein4.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11");
							}
						} else {
							if (sceneScherm.spr_bal.b7riem1.visible) {
								toolstack.push(4);
								sceneScherm.spr_bal.b7skibrilklein1.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11weg");
							} else if (sceneScherm.spr_bal.b7zorro.visible) {
								toolstack.push(4);
								sceneScherm.spr_bal.b7skibrilklein2.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11weg");
							} else if (sceneScherm.spr_bal.b7riem2.visible) {
								toolstack.push(4);
								sceneScherm.spr_bal.b7skibrilklein3.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11weg");
							} else {
								toolstack.push(4);
								sceneScherm.spr_bal.b7skibrilklein4.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("skibrilklein11weg");
							}
						}
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b7helm.visible) {
						if (sceneScherm.spr_bal.b7zorro.visible) {
							if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7skibrilklein1.visible && !sceneScherm.spr_bal.b7skibrilklein2.visible) {
								toolstackremove(5);
								sceneScherm.spr_bal.b7zorro.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("zorro");
							}
						} else {
							toolstack.push(5);
							sceneScherm.spr_bal.b7zorro.visible = true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("zorroweg");
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b7helm.visible) {
						if (sceneScherm.spr_bal.b7riem1.visible) {
							if (!sceneScherm.spr_bal.b7skibrilklein1.visible) {
								toolstackremove(6);
								sceneScherm.spr_bal.b7riem1.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riem11");
							}
						} else if (sceneScherm.spr_bal.b7riem2.visible) {
							if (!sceneScherm.spr_bal.b7zorro.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible) {
								toolstackremove(6);
								sceneScherm.spr_bal.b7riem2.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riem11");
							}
						} else {
							if (sceneScherm.spr_bal.b7skibrilklein2.visible||sceneScherm.spr_bal.b7zorro.visible||sceneScherm.spr_bal.b7skibrilklein3.visible) {
								toolstack.push(6);
								sceneScherm.spr_bal.b7riem1.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riem11weg");
							} else {
								toolstack.push(6);
								sceneScherm.spr_bal.b7riem2.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riem11weg");
							}
						}
					}
				} else if (toolused == 7) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b7helm.visible) {
						toolstackremove(7);
						sceneScherm.spr_bal.b7helm.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("helm");
					} else {
						toolstack.push(7);
						sceneScherm.spr_bal.b7helm.visible = true;sceneScherm.toolbal7.toolsmovie.gotoAndStop("helmweg");
					}
				} else if (toolused == 8) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndshovel");
					kleur = "wit";
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7helm.visible) { sceneScherm.spr_bal.b7p5.gotoAndStop(kleur); sceneScherm.spr_bal.b7p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p15.gotoAndStop(kleur); sceneScherm.spr_bal.b7p16.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p3.gotoAndStop(kleur);sceneScherm.spr_bal.b7p4.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7zorro.visible) {sceneScherm.spr_bal.b7p17.gotoAndStop(kleur);sceneScherm.spr_bal.b7p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible&&!sceneScherm.spr_bal.b7skibrilklein4.visible && !sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p8.gotoAndStop(kleur);sceneScherm.spr_bal.b7p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible&&!sceneScherm.spr_bal.b7riem2.visible&&!sceneScherm.spr_bal.b7skibrilklein1.visible&&!sceneScherm.spr_bal.b7skibrilklein2.visible&&!sceneScherm.spr_bal.b7skibrilklein3.visible&&!sceneScherm.spr_bal.b7skibrilklein4.visible) {sceneScherm.spr_bal.b7p11.gotoAndStop(kleur);sceneScherm.spr_bal.b7p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7helm.visible) { sceneScherm.spr_bal.b7p7.gotoAndStop(kleur); sceneScherm.spr_bal.b7p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible) {sceneScherm.spr_bal.b7p12.gotoAndStop(kleur); sceneScherm.spr_bal.b7p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b7helm.visible) {sceneScherm.spr_bal.b7p1.gotoAndStop(kleur);sceneScherm.spr_bal.b7p2.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b7p19.gotoAndStop(kleur);sceneScherm.spr_bal.b7p20.gotoAndStop(kleur);
				}
				if (sceneScherm.lvl==18) {
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7skibrilklein1.visible && !sceneScherm.spr_bal.b7skibrilklein2.visible && !sceneScherm.spr_bal.b7skibrilklein3.visible && !sceneScherm.spr_bal.b7skibrilklein4.visible && !sceneScherm.spr_bal.b7helm.visible && sceneScherm.spr_bal.b7p1.currentFrame == 2 && sceneScherm.spr_bal.b7p3.currentFrame == 3 && sceneScherm.spr_bal.b7p5.currentFrame == 2 && sceneScherm.spr_bal.b7p7.currentFrame == 4 && sceneScherm.spr_bal.b7p8.currentFrame == 4 && sceneScherm.spr_bal.b7p11.currentFrame == 3 && sceneScherm.spr_bal.b7p12.currentFrame == 0 && sceneScherm.spr_bal.b7p15.currentFrame == 2 && sceneScherm.spr_bal.b7p17.currentFrame == 4 && sceneScherm.spr_bal.b7p19.currentFrame == 2) {
						leveldone ();
					}
				} else if (sceneScherm.lvl==22) {
					if (!sceneScherm.spr_bal.b7zorro.visible && !sceneScherm.spr_bal.b7riem1.visible && !sceneScherm.spr_bal.b7riem2.visible && !sceneScherm.spr_bal.b7skibrilklein1.visible && !sceneScherm.spr_bal.b7skibrilklein2.visible && !sceneScherm.spr_bal.b7skibrilklein3.visible && !sceneScherm.spr_bal.b7skibrilklein4.visible && !sceneScherm.spr_bal.b7helm.visible && sceneScherm.spr_bal.b7p1.currentFrame == 0 && sceneScherm.spr_bal.b7p3.currentFrame == 3 && sceneScherm.spr_bal.b7p5.currentFrame == 2 && sceneScherm.spr_bal.b7p7.currentFrame == 0 && sceneScherm.spr_bal.b7p8.currentFrame == 3 && sceneScherm.spr_bal.b7p11.currentFrame == 0 && sceneScherm.spr_bal.b7p12.currentFrame == 2 && sceneScherm.spr_bal.b7p15.currentFrame == 4 && sceneScherm.spr_bal.b7p17.currentFrame == 0 && sceneScherm.spr_bal.b7p19.currentFrame == 3) {
						leveldone ();
					}
				}
			} else if (sceneScherm.lvl==19) {
				if (toolused == 1||toolused == 2||toolused == 3||toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "geel";
					else if (toolused == 2) kleur = "oranje";
					else if (toolused == 3) kleur = "paars";
					else kleur = "zwart";
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p6.gotoAndStop(kleur); }
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p7.gotoAndStop(kleur); }
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p10.gotoAndStop(kleur); }
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p11.gotoAndStop(kleur); }
					if (!riemiserr && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); }
					if (!riemiserr && !sceneScherm.spr_bal.b8mutslinks.visible) {sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);}
					if (!riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p3.gotoAndStop(kleur); }
					if (!riemiserl && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur); }
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8mutslinks.visible) {
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstackremove(5);
								sceneScherm.spr_bal.b8mutslinks.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinks");
							}
						} else if (!sceneScherm.spr_bal.b8mutslinks.visible){
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstack.push(5);
								sceneScherm.spr_bal.b8mutslinks.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinksweg");
							}
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8mutsrechts.visible) {
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstackremove(6);
								sceneScherm.spr_bal.b8mutsrechts.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechts");
							}
						} else if (!sceneScherm.spr_bal.b8mutsrechts.visible){
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstack.push(6);
								sceneScherm.spr_bal.b8mutsrechts.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechtsweg");
							}
						}
					}
				} else if (toolused == 7) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
							toolstackremove(7);
							sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("rieml"); riemiserl = false;
						} else if (sceneScherm.spr_bal.b8rieml1boven.visible){
							toolstackremove(7);
							sceneScherm.spr_bal.b8rieml1boven.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("rieml"); riemiserl = false;
						} else if (!sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible && !sceneScherm.spr_bal.b8rieml1boven.visible && !sceneScherm.spr_bal.b8rieml2boven.visible) {
							if (!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
								toolstack.push(7);
								sceneScherm.spr_bal.b8rieml1.visible = true; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemlweg"); riemiserl = true;
							} else {
								toolstack.push(7);
								sceneScherm.spr_bal.b8rieml1boven.visible = true; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemlweg"); riemiserl = true;
							}
						}
					}
				} else if (toolused == 8) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (!sceneScherm.spr_bal.b8rieml1.visible&&sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
							toolstackremove(8);
							sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal8.toolsmovie.gotoAndStop("riemr"); riemiserr = false;
							if (sceneScherm.spr_bal.b8rieml2.visible) {
								sceneScherm.spr_bal.b8rieml2.visible = false;
								sceneScherm.spr_bal.b8rieml1.visible = true;
							}
						} else if (!sceneScherm.spr_bal.b8rieml1boven.visible&&sceneScherm.spr_bal.b8riemrboven.visible){
							toolstackremove(8);
							sceneScherm.spr_bal.b8riemrboven.visible = false; sceneScherm.toolbal8.toolsmovie.gotoAndStop("riemr"); riemiserr = false;
							if (sceneScherm.spr_bal.b8rieml2boven.visible) {
								sceneScherm.spr_bal.b8rieml2boven.visible = false;
								sceneScherm.spr_bal.b8rieml1boven.visible = true;
							}
						} else if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8riemrboven.visible){
							if (!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
								toolstack.push(8);
								sceneScherm.spr_bal.b8riemr.visible = true; sceneScherm.toolbal8.toolsmovie.gotoAndStop("riemrweg"); riemiserr = true;
								if (sceneScherm.spr_bal.b8rieml1.visible) {
									sceneScherm.spr_bal.b8rieml1.visible = false;
									sceneScherm.spr_bal.b8rieml2.visible = true;
								}
							} else {
								toolstack.push(8);
								sceneScherm.spr_bal.b8riemrboven.visible = true; sceneScherm.toolbal8.toolsmovie.gotoAndStop("riemrweg"); riemiserr = true;
								if (sceneScherm.spr_bal.b8rieml1boven.visible) {
									sceneScherm.spr_bal.b8rieml1boven.visible = false;
									sceneScherm.spr_bal.b8rieml2boven.visible = true;
								}
							}
						}
					}
				} else if (toolused == 9) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8helm.visible) {
						toolstackremove(9);
						sceneScherm.spr_bal.b8helm.visible = false; sceneScherm.toolbal9.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b8helm.visible){
						toolstack.push(9);
						sceneScherm.spr_bal.b8helm.visible = true; sceneScherm.toolbal9.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible && !sceneScherm.spr_bal.b8mutsrechts.visible && sceneScherm.spr_bal.b8p1.currentFrame == 6 && sceneScherm.spr_bal.b8p2.currentFrame == 6 && sceneScherm.spr_bal.b8p3.currentFrame == 3 && sceneScherm.spr_bal.b8p4.currentFrame == 5 && sceneScherm.spr_bal.b8p5.currentFrame == 6 && sceneScherm.spr_bal.b8p6.currentFrame == 5 && sceneScherm.spr_bal.b8p7.currentFrame == 5 && sceneScherm.spr_bal.b8p8.currentFrame == 6 && sceneScherm.spr_bal.b8p9.currentFrame == 1 && sceneScherm.spr_bal.b8p10.currentFrame == 3 && sceneScherm.spr_bal.b8p11.currentFrame == 5 && sceneScherm.spr_bal.b8p12.currentFrame == 1 && sceneScherm.spr_bal.b8p13.currentFrame == 3 && sceneScherm.spr_bal.b8p14.currentFrame == 3 && sceneScherm.spr_bal.b8p15.currentFrame == 1 && sceneScherm.spr_bal.b8p16.currentFrame == 1) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==20) {
				if (toolused == 1||toolused == 2||toolused == 3||toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) kleur = "geel";
					else if (toolused == 2) kleur = "oranje";
					else if (toolused == 3) kleur = "blauw";
					else kleur = "zwart";
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible&&!sceneScherm.spr_bal.b9mutslinks.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible&&!sceneScherm.spr_bal.b9mutslinks.visible) {sceneScherm.spr_bal.b9p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible&&!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9skibrilklein.visible && !sceneScherm.spr_bal.b9mutsrechts.visible) { sceneScherm.spr_bal.b9p12.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9mutslinks.visible && !sceneScherm.spr_bal.b9helm.visible&&!riemiser) {sceneScherm.spr_bal.b9p6.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9mutslinks.visible && !sceneScherm.spr_bal.b9helm.visible) { sceneScherm.spr_bal.b9p5.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9mutslinks.visible&&!riemiser) {sceneScherm.spr_bal.b9p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9mutslinks.visible) { sceneScherm.spr_bal.b9p13.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9helm.visible&&!riemiser) {sceneScherm.spr_bal.b9p7.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p8.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9mutsrechts.visible&&!riemiser) {sceneScherm.spr_bal.b9p15.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9mutsrechts.visible) {sceneScherm.spr_bal.b9p16.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutslinks.visible&&!sceneScherm.spr_bal.b9helm.visible&&!riemiser) {sceneScherm.spr_bal.b9p2.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutslinks.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p1.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutslinks.visible&&!riemiser) {sceneScherm.spr_bal.b9p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutslinks.visible) {sceneScherm.spr_bal.b9p17.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9helm.visible&&!riemiser) {sceneScherm.spr_bal.b9p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9helm.visible) {sceneScherm.spr_bal.b9p4.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutsrechts.visible&&!riemiser) { sceneScherm.spr_bal.b9p19.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b9mutsrechts.visible) {sceneScherm.spr_bal.b9p20.gotoAndStop(kleur); }
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible&&!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {
						if (sceneScherm.spr_bal.b9mutslinks.visible) {
							if (!sceneScherm.spr_bal.b9riem4.visible) {
								toolstackremove(5);
								sceneScherm.spr_bal.b9mutslinks.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinks");
								linksvoor = false;
								if (riemiser) {
									sceneScherm.spr_bal.b9riem1.visible = false;
									sceneScherm.spr_bal.b9riem2.visible = false;
									sceneScherm.spr_bal.b9riem3.visible = false;
									if (!sceneScherm.spr_bal.b9mutsrechts.visible) sceneScherm.spr_bal.b9riem1.visible = true;
									else sceneScherm.spr_bal.b9riem2.visible = true;
								}
							}	
						} else {
							if (!sceneScherm.spr_bal.b9riem4.visible) {
								toolstack.push(5);
								sceneScherm.spr_bal.b9mutslinks.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinksweg");
								if (riemiser) {
									linksvoor = true;
									sceneScherm.spr_bal.b9riem1.visible = false;
									sceneScherm.spr_bal.b9riem2.visible = false;
									sceneScherm.spr_bal.b9riem3.visible = false;
									if (!sceneScherm.spr_bal.b9mutsrechts.visible) sceneScherm.spr_bal.b9riem3.visible = true;
								} else {
									linksvoor = false;
								}
							}
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible&&!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {
						if (sceneScherm.spr_bal.b9mutsrechts.visible) {
							if (!sceneScherm.spr_bal.b9riem4.visible) {
								toolstackremove(6);
								sceneScherm.spr_bal.b9mutsrechts.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechts");
								rechtsvoor = false;
								if (riemiser) {
									sceneScherm.spr_bal.b9riem1.visible = false;
									sceneScherm.spr_bal.b9riem2.visible = false;
									sceneScherm.spr_bal.b9riem3.visible = false;
									if (!sceneScherm.spr_bal.b9mutslinks.visible) sceneScherm.spr_bal.b9riem1.visible = true;
									else sceneScherm.spr_bal.b9riem3.visible = true;
								}
							}
						} else {
							if (!sceneScherm.spr_bal.b9riem4.visible) {
								toolstack.push(6);
								sceneScherm.spr_bal.b9mutsrechts.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechtsweg");
								if (riemiser) {
									rechtsvoor = true;
									sceneScherm.spr_bal.b9riem1.visible = false;
									sceneScherm.spr_bal.b9riem2.visible = false;
									sceneScherm.spr_bal.b9riem3.visible = false;
									if (!sceneScherm.spr_bal.b9mutslinks.visible) sceneScherm.spr_bal.b9riem2.visible = true;
								} else {
									rechtsvoor = false;
								}
							}
						}
					}
				} else if (toolused == 7) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible) {
						if (sceneScherm.spr_bal.b9skibril.visible) {
							toolstackremove(7);
							sceneScherm.spr_bal.b9skibril.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("skibril");
						} else {
							toolstack.push(7);
							sceneScherm.spr_bal.b9skibril.visible = true; sceneScherm.toolbal7.toolsmovie.gotoAndStop("skibrilweg");
						}
					}
				} else if (toolused == 8) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible) {
						if (!sceneScherm.spr_bal.b9skibril.visible) {
							if (sceneScherm.spr_bal.b9skibrilklein.visible) {
								toolstackremove(8);
								sceneScherm.spr_bal.b9skibrilklein.visible = false; sceneScherm.toolbal8.toolsmovie.gotoAndStop("skibrilklein");
							} else {
								toolstack.push(8);
								sceneScherm.spr_bal.b9skibrilklein.visible = true; sceneScherm.toolbal8.toolsmovie.gotoAndStop("skibrilkleinweg");
							}
						}
					}
				} else if (toolused == 9) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b9helm.visible) {
						if (riemiser) {
							if (sceneScherm.spr_bal.b9riem4.visible&&!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {
								toolstackremove(9);
								riemiser = false; sceneScherm.spr_bal.b9riem4.visible = false; sceneScherm.toolbal9.toolsmovie.gotoAndStop("riem13");
							} else if (!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9mutslinks.visible&&!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible) {
								toolstackremove(9);
								riemiser = false; sceneScherm.spr_bal.b9riem1.visible = false;sceneScherm.spr_bal.b9riem2.visible = false;sceneScherm.spr_bal.b9riem3.visible = false; sceneScherm.toolbal9.toolsmovie.gotoAndStop("riem13");
							}
						} else if (!sceneScherm.spr_bal.b9skibril.visible&&!sceneScherm.spr_bal.b9skibrilklein.visible){
							if (sceneScherm.spr_bal.b9mutsrechts.visible&&sceneScherm.spr_bal.b9mutslinks.visible) {
								toolstack.push(9);
								riemiser = true; sceneScherm.spr_bal.b9riem4.visible = true; sceneScherm.toolbal9.toolsmovie.gotoAndStop("riem13weg");
							} else if (!sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9mutslinks.visible) {
								toolstack.push(9);
								riemiser = true; sceneScherm.spr_bal.b9riem1.visible = true; sceneScherm.toolbal9.toolsmovie.gotoAndStop("riem13weg");
							} else if (!sceneScherm.spr_bal.b9mutsrechts.visible&&sceneScherm.spr_bal.b9mutslinks.visible) {
								toolstack.push(9);
								riemiser = true; sceneScherm.spr_bal.b9riem4.visible = true; sceneScherm.toolbal9.toolsmovie.gotoAndStop("riem13weg");
							} else if (sceneScherm.spr_bal.b9mutsrechts.visible&&!sceneScherm.spr_bal.b9mutslinks.visible) {
								toolstack.push(9);
								riemiser = true; sceneScherm.spr_bal.b9riem4.visible = true; sceneScherm.toolbal9.toolsmovie.gotoAndStop("riem13weg");
							}
						}
					}
				} else if (toolused == 10) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b9helm.visible) {
						toolstackremove(10);
						sceneScherm.spr_bal.b9helm.visible = false; sceneScherm.toolbal10.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b9helm.visible){
						toolstack.push(10);
						sceneScherm.spr_bal.b9helm.visible = true; sceneScherm.toolbal10.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!sceneScherm.spr_bal.b9mutslinks.visible && !sceneScherm.spr_bal.b9mutsrechts.visible && !sceneScherm.spr_bal.b9skibril.visible && !sceneScherm.spr_bal.b9skibrilklein.visible && !sceneScherm.spr_bal.b9helm.visible && !riemiser && sceneScherm.spr_bal.b9p1.currentFrame == 6 && sceneScherm.spr_bal.b9p2.currentFrame == 2 && sceneScherm.spr_bal.b9p3.currentFrame == 3 && sceneScherm.spr_bal.b9p4.currentFrame == 6 && sceneScherm.spr_bal.b9p5.currentFrame == 1 && sceneScherm.spr_bal.b9p6.currentFrame == 3 && sceneScherm.spr_bal.b9p7.currentFrame == 2 && sceneScherm.spr_bal.b9p8.currentFrame == 1 && sceneScherm.spr_bal.b9p9.currentFrame == 3 && sceneScherm.spr_bal.b9p10.currentFrame == 3 && sceneScherm.spr_bal.b9p11.currentFrame == 3 && sceneScherm.spr_bal.b9p12.currentFrame == 3 && sceneScherm.spr_bal.b9p13.currentFrame == 1 && sceneScherm.spr_bal.b9p14.currentFrame == 2 && sceneScherm.spr_bal.b9p15.currentFrame == 3 && sceneScherm.spr_bal.b9p16.currentFrame == 1 && sceneScherm.spr_bal.b9p17.currentFrame == 6 && sceneScherm.spr_bal.b9p18.currentFrame == 3 && sceneScherm.spr_bal.b9p19.currentFrame == 2 && sceneScherm.spr_bal.b9p20.currentFrame == 6) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==21) {
				if (toolused == 1||toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "blauw";} else if (toolused == 2) {kleur = "oranje";}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4riemv.visible  && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p14.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p11.gotoAndStop(kleur);sceneScherm.spr_bal.b4p7.gotoAndStop(kleur);sceneScherm.spr_bal.b4p8.gotoAndStop(kleur);sceneScherm.spr_bal.b4p10.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemvoor.visible) {sceneScherm.spr_bal.b4p12.gotoAndStop(kleur);sceneScherm.spr_bal.b4p16.gotoAndStop(kleur);sceneScherm.spr_bal.b4p13.gotoAndStop(kleur);sceneScherm.spr_bal.b4p15.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p17.gotoAndStop(kleur);sceneScherm.spr_bal.b4p19.gotoAndStop(kleur);sceneScherm.spr_bal.b4p4.gotoAndStop(kleur);sceneScherm.spr_bal.b4p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsonder.visible) {sceneScherm.spr_bal.b4p17.gotoAndStop(kleur);sceneScherm.spr_bal.b4p19.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4mutsboven.visible&&!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p1.gotoAndStop(kleur);sceneScherm.spr_bal.b4p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p2.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {sceneScherm.spr_bal.b4p5.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4mutsonder.visible) {sceneScherm.spr_bal.b4p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b4riemv.visible) {sceneScherm.spr_bal.b4p21.gotoAndStop(kleur);}
					sceneScherm.spr_bal.b4p20.gotoAndStop(kleur); sceneScherm.spr_bal.b4p22.gotoAndStop(kleur);
				} else if (toolused == 3) {
					if (sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstackremove(3);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riem.visible=false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riembreed");
					} else if (sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstackremove(3);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riemvoor.visible=false;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riembreed");
					} else if (!sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstack.push(3);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riem.visible=true;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riembreedweg");
					} else if (!sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4riem.visible && sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstack.push(3);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riemvoor.visible=true;sceneScherm.toolbal3.toolsmovie.gotoAndStop("riembreedweg");
					}
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b4riemv.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4mutsboven.visible  && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riemv.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("riemv");
					} else if (!sceneScherm.spr_bal.b4riemv.visible  && !sceneScherm.spr_bal.b4mutsboven.visible  && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4riemv.visible=true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("riemvweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsonder.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsonder");
					} else if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsonder.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsonderweg");
					}
				} else if (toolused == 6) {
					if (sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstackremove(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsboven.visible=false;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsboven");
					} else if (!sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4helm.visible) {
						toolstack.push(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b4mutsboven.visible=true;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsbovenweg");
					}
				}
				if (!sceneScherm.spr_bal.b4helm.visible && !sceneScherm.spr_bal.b4mutsonder.visible && !sceneScherm.spr_bal.b4mutsboven.visible && !sceneScherm.spr_bal.b4riem.visible && !sceneScherm.spr_bal.b4riemvoor.visible && !sceneScherm.spr_bal.b4riemv.visible && sceneScherm.spr_bal.b4p1.currentFrame == 2 && sceneScherm.spr_bal.b4p2.currentFrame == 2 && sceneScherm.spr_bal.b4p4.currentFrame == 2 && sceneScherm.spr_bal.b4p5.currentFrame == 1 && sceneScherm.spr_bal.b4p7.currentFrame == 2 && sceneScherm.spr_bal.b4p8.currentFrame == 2 && sceneScherm.spr_bal.b4p9.currentFrame == 2 && sceneScherm.spr_bal.b4p12.currentFrame == 2 && sceneScherm.spr_bal.b4p14.currentFrame == 2  && sceneScherm.spr_bal.b4p17.currentFrame == 2 && sceneScherm.spr_bal.b4p18.currentFrame == 1 && sceneScherm.spr_bal.b4p20.currentFrame == 2 && sceneScherm.spr_bal.b4p21.currentFrame == 2) {
					leveldone ();
				}
			}
		}
		
		function dologica3 (toolused) {
			if (sceneScherm.lvl==23) {
				if (toolused == 1) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6p1.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutslinks.visible) sceneScherm.spr_bal.b6gras01.visible = true;
					if (!sceneScherm.spr_bal.b6p2.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) sceneScherm.spr_bal.b6gras02.visible = true;
					if (!sceneScherm.spr_bal.b6p3.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) sceneScherm.spr_bal.b6gras03.visible = true;
					if (!sceneScherm.spr_bal.b6p4.visible && !sceneScherm.spr_bal.b6mutslinks.visible) sceneScherm.spr_bal.b6gras04.visible = true;
				} else if (toolused == 2) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndzaad");
					if (!sceneScherm.spr_bal.b6bloemwit1.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { sceneScherm.spr_bal.b6bloemwit1.visible = true; sceneScherm.spr_bal.b6bloemwit1.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit2.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { sceneScherm.spr_bal.b6bloemwit2.visible = true; sceneScherm.spr_bal.b6bloemwit2.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit3.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { sceneScherm.spr_bal.b6bloemwit3.visible = true; sceneScherm.spr_bal.b6bloemwit3.gotoAndStop(0);}
					if (!sceneScherm.spr_bal.b6bloemwit4.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { sceneScherm.spr_bal.b6bloemwit4.visible = true; sceneScherm.spr_bal.b6bloemwit4.gotoAndStop(0);}
				} else if (toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndwater");
					if (sceneScherm.spr_bal.b6p1.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { 
						if (sceneScherm.spr_bal.b6p1.currentFrame == 0) sceneScherm.spr_bal.b6p1.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p1.currentFrame == 1) sceneScherm.spr_bal.b6p1.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p2.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { 
						if (sceneScherm.spr_bal.b6p2.currentFrame == 0) sceneScherm.spr_bal.b6p2.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p2.currentFrame == 1) sceneScherm.spr_bal.b6p2.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p3.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { 
						if (sceneScherm.spr_bal.b6p3.currentFrame == 0) sceneScherm.spr_bal.b6p3.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p3.currentFrame == 1) sceneScherm.spr_bal.b6p3.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6p4.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { 
						if (sceneScherm.spr_bal.b6p4.currentFrame == 0) sceneScherm.spr_bal.b6p4.gotoAndStop("gras2");
						else if (sceneScherm.spr_bal.b6p4.currentFrame == 1) sceneScherm.spr_bal.b6p4.gotoAndStop("gras3");
					}
					if (sceneScherm.spr_bal.b6gras01.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6p1.visible = true; sceneScherm.spr_bal.b6p1.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras02.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6p2.visible = true; sceneScherm.spr_bal.b6p2.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras03.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6p3.visible = true; sceneScherm.spr_bal.b6p3.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6gras04.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { sceneScherm.spr_bal.b6gras04.visible = false; sceneScherm.spr_bal.b6p4.visible = true; sceneScherm.spr_bal.b6p4.gotoAndStop(0); }
					if (sceneScherm.spr_bal.b6bloemwit1.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit1.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit1.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit1.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit1.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit2.visible && !sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit2.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit2.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit2.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit2.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit3.visible && !sceneScherm.spr_bal.b6mutsrechts.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit3.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit3.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit3.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit3.visible=false;
					}
					if (sceneScherm.spr_bal.b6bloemwit4.visible && !sceneScherm.spr_bal.b6mutslinks.visible) { 
						if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 0) sceneScherm.spr_bal.b6bloemwit4.gotoAndStop("bloem2");
						else if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 1) sceneScherm.spr_bal.b6bloemwit4.gotoAndStop("bloem3");
						else if (sceneScherm.spr_bal.b6bloemwit4.currentFrame == 2) sceneScherm.spr_bal.b6bloemwit4.visible=false;
					}
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b6helm.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6helm.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b6helm.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6helm.visible=true;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helmweg");
					}
				} else if (toolused == 5) {
					if (sceneScherm.spr_bal.b6mutslinks.visible && !sceneScherm.spr_bal.b6helm.visible) {
						toolstackremove(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6mutslinks.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinks");
					} else if (!sceneScherm.spr_bal.b6mutslinks.visible && !sceneScherm.spr_bal.b6helm.visible) {
						toolstack.push(5);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6mutslinks.visible=true;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinksweg");
					}
				} else if (toolused == 6) {
					if (sceneScherm.spr_bal.b6mutsrechts.visible && !sceneScherm.spr_bal.b6helm.visible) {
						toolstackremove(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6mutsrechts.visible=false;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechts");
					} else if (!sceneScherm.spr_bal.b6mutsrechts.visible && !sceneScherm.spr_bal.b6helm.visible) {
						toolstack.push(6);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b6mutsrechts.visible=true;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechtsweg");
					}
				} else if (toolused == 7) {
					toolstack = new Array();
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b6helm.visible) {sceneScherm.spr_bal.b6helm.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helm");}
					if (sceneScherm.spr_bal.b6mutslinks.visible) {sceneScherm.spr_bal.b6mutslinks.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutslinks");}
					if (sceneScherm.spr_bal.b6mutsrechts.visible) {sceneScherm.spr_bal.b6mutsrechts.visible=false;sceneScherm.toolbal6.toolsmovie.gotoAndStop("mutsrechts");}
					sceneScherm.spr_bal.b6gras01.visible = false; sceneScherm.spr_bal.b6gras02.visible = false; sceneScherm.spr_bal.b6gras03.visible = false; sceneScherm.spr_bal.b6gras04.visible = false;
					sceneScherm.spr_bal.b6p1.visible = false;sceneScherm.spr_bal.b6p2.visible = false;sceneScherm.spr_bal.b6p3.visible = false;sceneScherm.spr_bal.b6p4.visible = false;
					sceneScherm.spr_bal.b6bloemwit1.visible = false; sceneScherm.spr_bal.b6bloemwit2.visible = false; sceneScherm.spr_bal.b6bloemwit3.visible = false; sceneScherm.spr_bal.b6bloemwit4.visible = false;
					sceneScherm.spr_bal.b6bloemblauw1.visible = false; sceneScherm.spr_bal.b6bloemblauw2.visible = false; sceneScherm.spr_bal.b6bloemblauw3.visible = false; sceneScherm.spr_bal.b6bloemblauw4.visible = false;
				}
				if (!sceneScherm.spr_bal.b6helm.visible && !sceneScherm.spr_bal.b6mutslinks.visible && !sceneScherm.spr_bal.b6mutsrechts.visible && sceneScherm.spr_bal.b6p1.visible && sceneScherm.spr_bal.b6p1.currentFrame==0 && sceneScherm.spr_bal.b6bloemwit1.visible && sceneScherm.spr_bal.b6bloemwit1.currentFrame == 2  && sceneScherm.spr_bal.b6p2.visible && sceneScherm.spr_bal.b6p2.currentFrame==1 && !sceneScherm.spr_bal.b6bloemwit2.visible && sceneScherm.spr_bal.b6p3.visible && sceneScherm.spr_bal.b6p3.currentFrame==2 && sceneScherm.spr_bal.b6bloemwit3.visible && sceneScherm.spr_bal.b6bloemwit3.currentFrame == 1  && sceneScherm.spr_bal.b6p4.visible && sceneScherm.spr_bal.b6p4.currentFrame==1 && !sceneScherm.spr_bal.b6bloemwit4.visible) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==24) {
				if (toolused == 1||toolused == 2||toolused == 3) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					if (toolused == 1) {kleur = "geel";} else if (toolused == 2) {kleur = "magenta";} else kleur = "zwart";
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p3.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible) {sceneScherm.spr_bal.b3p18.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p6.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible) {sceneScherm.spr_bal.b3p15.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible&& !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3riem.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p9.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible&& !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3riem.visible) {sceneScherm.spr_bal.b3p12.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p4.gotoAndStop(kleur);sceneScherm.spr_bal.b3p5.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible) {sceneScherm.spr_bal.b3p13.gotoAndStop(kleur);sceneScherm.spr_bal.b3p14.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3riem.visible && !sceneScherm.spr_bal.b3helm.visible) {sceneScherm.spr_bal.b3p7.gotoAndStop(kleur);sceneScherm.spr_bal.b3p8.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && !sceneScherm.spr_bal.b3riem.visible) {sceneScherm.spr_bal.b3p10.gotoAndStop(kleur);sceneScherm.spr_bal.b3p11.gotoAndStop(kleur);}
					if (!sceneScherm.spr_bal.b3helm.visible) { sceneScherm.spr_bal.b3p1.gotoAndStop(kleur); sceneScherm.spr_bal.b3p2.gotoAndStop(kleur); }
					sceneScherm.spr_bal.b3p16.gotoAndStop(kleur);sceneScherm.spr_bal.b3p17.gotoAndStop(kleur);
				} else if (toolused == 4) {
					if (sceneScherm.spr_bal.b3helm.visible) {
						toolstackremove(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3helm.visible=false;sceneScherm.toolbal4.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b3helm.visible) {
						toolstack.push(4);
						if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
						sceneScherm.spr_bal.b3helm.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("helmweg");
					}
				} else if (toolused == 5) {
					if ((laag1 == "riem" || laag2 == "riem" || laag3 == "riem")&& !sceneScherm.spr_bal.b3helm.visible) {
						if (laag3 == "riem") {
							toolstackremove(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag3 = ""; sceneScherm.spr_bal.b3riem.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem");
							if (laag2 == "v") {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; }
							else {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = true;sceneScherm.spr_bal.b3riembreed2.visible = false;}
						} else if (laag2 == "riem" && laag3=="") {
							toolstackremove(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag2 = ""; sceneScherm.spr_bal.b3riem.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem");							
							if (laag1 == "v") {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;}
							else {sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false;}
						} else if (laag1 == "riem" && laag2=="" && laag3=="") {
							toolstackremove(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = ""; sceneScherm.spr_bal.b3riem.visible=false;sceneScherm.toolbal5.toolsmovie.gotoAndStop("riem");							
						}
					} else if ((laag1 != "riem" && laag2 != "riem" && laag3 != "riem")&& !sceneScherm.spr_bal.b3helm.visible) {
						if (laag1 == "" && laag2 == "" && laag3 == "") {
							toolstack.push(5);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = "riem"; sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemweg");
						} else if (laag2 == "" && laag3 == "") {
							laag2 = "riem";
							if (laag1 == "breed") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemweg");
							} else if (laag1 == "v") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemweg");
							}
						} else if (laag3 == "") {
							laag3 = "riem";
							if (laag1 == "breed" && laag2 == "v") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemweg");
							} else if (laag1 == "v" && laag2 == "breed") {
								toolstack.push(5);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("riemweg");
							}
						}
					}
				} else if (toolused == 6) {
					if ((laag1 == "breed" || laag2 == "breed" || laag3 == "breed")&& !sceneScherm.spr_bal.b3helm.visible) {
						if (laag3 == "breed") {
							toolstackremove(6);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag3 = ""; sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreed");
							if (laag2 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false; }
							else {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = true; }
						} else if (laag2 == "breed" && laag3=="") {
							toolstackremove(6);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag2 = ""; sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreed");							
							if (laag1 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;}
							else {sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false; }
						} else if (laag1 == "breed" && laag2=="" && laag3=="") {
							toolstackremove(6);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = ""; sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreed");							
						}
					} else if ((laag1 != "breed" && laag2 != "breed" && laag3 != "breed")&& !sceneScherm.spr_bal.b3helm.visible) {
						if (laag1 == "" && laag2 == "" && laag3 == "") {
							toolstack.push(6);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = "breed"; sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreedweg");
						} else if (laag2 == "" && laag3 == "") {
							laag2 = "breed";
							if (laag1 == "riem") {
								toolstack.push(6);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = true; 
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = true;
								sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreedweg");
							} else if (laag1 == "v") {
								toolstack.push(6);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreedweg");
							}
						} else if (laag3 == "") {
							laag3 = "breed";
							if (laag1 == "riem" && laag2 == "v") {
								toolstack.push(6);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreedweg");
							} else if (laag1 == "v" && laag2 == "riem") {
								toolstack.push(6);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = false; sceneScherm.spr_bal.b3riembreed1.visible = true; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.toolbal6.toolsmovie.gotoAndStop("riembreedweg");
							}
						}
					}
				} else if (toolused == 7) {
					if ((laag1 == "v" || laag2 == "v" || laag3 == "v")&& !sceneScherm.spr_bal.b3helm.visible) {
						if (laag3 == "v") {
							toolstackremove(7);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag3 = ""; sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemv");
							if (laag2 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false; }
							else {sceneScherm.spr_bal.b3riem.visible = true;sceneScherm.spr_bal.b3riembreed0.visible = false;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = true;}
						} else if (laag2 == "v" && laag3=="") {
							toolstackremove(7);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag2 = ""; sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemv");						
							if (laag1 == "riem") {sceneScherm.spr_bal.b3riem.visible = true;}
							else {sceneScherm.spr_bal.b3riembreed0.visible = true;sceneScherm.spr_bal.b3riembreed1.visible = false;sceneScherm.spr_bal.b3riembreed2.visible = false;}
						} else if (laag1 == "v" && laag2=="" && laag3=="") {
							toolstackremove(7);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = ""; sceneScherm.spr_bal.b3riemv1.visible = false;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemv");							
						}
					} else if ((laag1 != "v" && laag2 != "v" && laag3 != "v")&& !sceneScherm.spr_bal.b3helm.visible) {
						if (laag1 == "" && laag2 == "" && laag3 == "") {
							toolstack.push(7);
							if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
							laag1 = "v"; sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemvweg");
						} else if (laag2 == "" && laag3 == "") {
							laag2 = "v";
							if (laag1 == "breed") {
								toolstack.push(7);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true;sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemvweg");
							} else if (laag1 == "riem") {
								toolstack.push(7);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = true; 
								sceneScherm.spr_bal.b3riemv1.visible = false; sceneScherm.spr_bal.b3riemv2.visible = true;sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemvweg");
							}
						} else if (laag3 == "") {
							laag3 = "v";
							if (laag1 == "breed" && laag2 == "riem") {
								toolstack.push(7);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riem.visible = true;
								sceneScherm.spr_bal.b3riemv1.visible = false; sceneScherm.spr_bal.b3riemv2.visible = true;sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemvweg");
							} else if (laag1 == "riem" && laag2 == "breed") {
								toolstack.push(7);
								if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
								sceneScherm.spr_bal.b3riem.visible = false;
								sceneScherm.spr_bal.b3riembreed0.visible = true; sceneScherm.spr_bal.b3riembreed1.visible = false; sceneScherm.spr_bal.b3riembreed2.visible = false;
								sceneScherm.spr_bal.b3riemv1.visible = true; sceneScherm.spr_bal.b3riemv2.visible = false;sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemvweg");
							}
						}
					}
				}
				if (!sceneScherm.spr_bal.b3helm.visible && !sceneScherm.spr_bal.b3riem.visible && !sceneScherm.spr_bal.b3riemv1.visible && !sceneScherm.spr_bal.b3riemv2.visible && !sceneScherm.spr_bal.b3riembreed0.visible && !sceneScherm.spr_bal.b3riembreed1.visible && !sceneScherm.spr_bal.b3riembreed2.visible && sceneScherm.spr_bal.b3p1.currentFrame == 4 && sceneScherm.spr_bal.b3p3.currentFrame == 2 && sceneScherm.spr_bal.b3p4.currentFrame == 3 && sceneScherm.spr_bal.b3p6.currentFrame == 4 && sceneScherm.spr_bal.b3p7.currentFrame == 4 && sceneScherm.spr_bal.b3p9.currentFrame == 4 && sceneScherm.spr_bal.b3p10.currentFrame == 4 && sceneScherm.spr_bal.b3p12.currentFrame == 2 && sceneScherm.spr_bal.b3p13.currentFrame == 2 && sceneScherm.spr_bal.b3p15.currentFrame == 3 && sceneScherm.spr_bal.b3p16.currentFrame == 4 && sceneScherm.spr_bal.b3p18.currentFrame == 2) {
					leveldone ();
				}
			} else if (sceneScherm.lvl==25) {
				if (toolused == 9||toolused == 1||toolused == 2||toolused == 3) {
					if (toolused == 9) {
						if (sceneScherm.soundon)createjs.Sound.play ("sndshovel");
					} else {
						if (sceneScherm.soundon)createjs.Sound.play ("sndpaint");
					}
					if (toolused == 1) kleur = "rood";
					else if (toolused == 2) kleur = "blauw";
					else if (toolused == 3) kleur = "zwart";
					else kleur = "wit";
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p6.gotoAndStop(kleur); }
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p7.gotoAndStop(kleur); }
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p10.gotoAndStop(kleur); }
					if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p11.gotoAndStop(kleur); }
					if (!riemiserr && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p4.gotoAndStop(kleur); }
					if (!riemiserr && !sceneScherm.spr_bal.b8mutslinks.visible) {sceneScherm.spr_bal.b8p13.gotoAndStop(kleur);}
					if (!riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p3.gotoAndStop(kleur); }
					if (!riemiserl && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p14.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p1.gotoAndStop(kleur); sceneScherm.spr_bal.b8p5.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p2.gotoAndStop(kleur); sceneScherm.spr_bal.b8p8.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8mutslinks.visible) { sceneScherm.spr_bal.b8p9.gotoAndStop(kleur); sceneScherm.spr_bal.b8p15.gotoAndStop(kleur); }
					if (!sceneScherm.spr_bal.b8mutsrechts.visible) { sceneScherm.spr_bal.b8p12.gotoAndStop(kleur); sceneScherm.spr_bal.b8p16.gotoAndStop(kleur); }
				} else if (toolused == 4) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8mutslinks.visible) {
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstackremove(4);
								sceneScherm.spr_bal.b8mutslinks.visible = false; sceneScherm.toolbal4.toolsmovie.gotoAndStop("mutslinks");
							}
						} else if (!sceneScherm.spr_bal.b8mutslinks.visible){
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstack.push(4);
								sceneScherm.spr_bal.b8mutslinks.visible = true; sceneScherm.toolbal4.toolsmovie.gotoAndStop("mutslinksweg");
							}
						}
					}
				} else if (toolused == 5) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8mutsrechts.visible) {
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstackremove(5);
								sceneScherm.spr_bal.b8mutsrechts.visible = false; sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsrechts");
							}
						} else if (!sceneScherm.spr_bal.b8mutsrechts.visible){
							if(!sceneScherm.spr_bal.b8riemrboven.visible&&!sceneScherm.spr_bal.b8rieml1boven.visible&&!sceneScherm.spr_bal.b8rieml2boven.visible) {
								toolstack.push(5);
								sceneScherm.spr_bal.b8mutsrechts.visible = true; sceneScherm.toolbal5.toolsmovie.gotoAndStop("mutsrechtsweg");
							}
						}
					}
				} else if (toolused == 6) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (sceneScherm.spr_bal.b8rieml1.visible&&!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
							toolstackremove(6);
							sceneScherm.spr_bal.b8rieml1.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("rieml"); riemiserl = false;
						} else if (sceneScherm.spr_bal.b8rieml1boven.visible){
							toolstackremove(6);
							sceneScherm.spr_bal.b8rieml1boven.visible = false; sceneScherm.toolbal6.toolsmovie.gotoAndStop("rieml"); riemiserl = false;
						} else if (!sceneScherm.spr_bal.b8rieml1.visible && !sceneScherm.spr_bal.b8rieml2.visible && !sceneScherm.spr_bal.b8rieml1boven.visible && !sceneScherm.spr_bal.b8rieml2boven.visible) {
							if (!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
								toolstack.push(6);
								sceneScherm.spr_bal.b8rieml1.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riemlweg"); riemiserl = true;
							} else {
								toolstack.push(6);
								sceneScherm.spr_bal.b8rieml1boven.visible = true; sceneScherm.toolbal6.toolsmovie.gotoAndStop("riemlweg"); riemiserl = true;
							}
						}
					}
				} else if (toolused == 7) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (!sceneScherm.spr_bal.b8helm.visible) {
						if (!sceneScherm.spr_bal.b8rieml1.visible&&sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
							toolstackremove(7);
							sceneScherm.spr_bal.b8riemr.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemr"); riemiserr = false;
							if (sceneScherm.spr_bal.b8rieml2.visible) {
								sceneScherm.spr_bal.b8rieml2.visible = false;
								sceneScherm.spr_bal.b8rieml1.visible = true;
							}
						} else if (!sceneScherm.spr_bal.b8rieml1boven.visible&&sceneScherm.spr_bal.b8riemrboven.visible){
							toolstackremove(7);
							sceneScherm.spr_bal.b8riemrboven.visible = false; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemr"); riemiserr = false;
							if (sceneScherm.spr_bal.b8rieml2boven.visible) {
								sceneScherm.spr_bal.b8rieml2boven.visible = false;
								sceneScherm.spr_bal.b8rieml1boven.visible = true;
							}
						} else if (!sceneScherm.spr_bal.b8riemr.visible&&!sceneScherm.spr_bal.b8riemrboven.visible){
							if (!sceneScherm.spr_bal.b8mutsrechts.visible&&!sceneScherm.spr_bal.b8mutslinks.visible) {
								toolstack.push(7);
								sceneScherm.spr_bal.b8riemr.visible = true; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemrweg"); riemiserr = true;
								if (sceneScherm.spr_bal.b8rieml1.visible) {
									sceneScherm.spr_bal.b8rieml1.visible = false;
									sceneScherm.spr_bal.b8rieml2.visible = true;
								}
							} else {
								toolstack.push(7);
								sceneScherm.spr_bal.b8riemrboven.visible = true; sceneScherm.toolbal7.toolsmovie.gotoAndStop("riemrweg"); riemiserr = true;
								if (sceneScherm.spr_bal.b8rieml1boven.visible) {
									sceneScherm.spr_bal.b8rieml1boven.visible = false;
									sceneScherm.spr_bal.b8rieml2boven.visible = true;
								}
							}
						}
					}
				} else if (toolused == 8) {
					if (sceneScherm.soundon)createjs.Sound.play ("sndswitch");
					if (sceneScherm.spr_bal.b8helm.visible) {
						toolstackremove(8);
						sceneScherm.spr_bal.b8helm.visible = false; sceneScherm.toolbal8.toolsmovie.gotoAndStop("helm");
					} else if (!sceneScherm.spr_bal.b8helm.visible){
						toolstack.push(8);
						sceneScherm.spr_bal.b8helm.visible = true; sceneScherm.toolbal8.toolsmovie.gotoAndStop("helmweg");
					}
				}
				if (!riemiserr && !riemiserl && !sceneScherm.spr_bal.b8helm.visible && !sceneScherm.spr_bal.b8mutslinks.visible && !sceneScherm.spr_bal.b8mutsrechts.visible && sceneScherm.spr_bal.b8p1.currentFrame == 2 && sceneScherm.spr_bal.b8p2.currentFrame == 3 && sceneScherm.spr_bal.b8p3.currentFrame == 3 && sceneScherm.spr_bal.b8p4.currentFrame == 0 && sceneScherm.spr_bal.b8p5.currentFrame == 2 && sceneScherm.spr_bal.b8p6.currentFrame == 0 && sceneScherm.spr_bal.b8p7.currentFrame == 4 && sceneScherm.spr_bal.b8p8.currentFrame == 3 && sceneScherm.spr_bal.b8p9.currentFrame == 4 && sceneScherm.spr_bal.b8p10.currentFrame == 3 && sceneScherm.spr_bal.b8p11.currentFrame == 2 && sceneScherm.spr_bal.b8p12.currentFrame == 0 && sceneScherm.spr_bal.b8p13.currentFrame == 2 && sceneScherm.spr_bal.b8p14.currentFrame == 4 && sceneScherm.spr_bal.b8p15.currentFrame == 4 && sceneScherm.spr_bal.b8p16.currentFrame == 0) {
					leveldone ();
				}
			}
		}
		
		
		
		
		function toolstackremove(tooltoremove) {
			if (toolstack!=null&&toolstack.length>0) {
				for (i = toolstack.length - 1; i >= 0; i--) {
					if (toolstack[i] == tooltoremove) toolstack.splice(i, 1);
				}
			}	
		}
		
		function onTool1ClickEvent(e) {if (stateLevelLoop) prelogica(1);}
		function onTool2ClickEvent(e) {if (stateLevelLoop) prelogica(2);}
		function onTool3ClickEvent(e) {if (stateLevelLoop) prelogica(3);}
		function onTool4ClickEvent(e) {if (stateLevelLoop) prelogica(4);}
		function onTool5ClickEvent(e) {if (stateLevelLoop) prelogica(5);}
		function onTool6ClickEvent(e) {if (stateLevelLoop) prelogica(6);}
		function onTool7ClickEvent(e) {if (stateLevelLoop) prelogica(7);}
		function onTool8ClickEvent(e) {if (stateLevelLoop) prelogica(8);}
		function onTool9ClickEvent(e) {if (stateLevelLoop) prelogica(9);}
		function onTool10ClickEvent(e) {if (stateLevelLoop) prelogica(10);}
		function onTool11ClickEvent(e) {if (stateLevelLoop) prelogica(11);}
		
		function leveldone()  {
			if (sceneScherm.soundon)createjs.Sound.play ("sndboo");
			createjs.Ticker.removeEventListener("tick",gameLoop);
			if (sceneScherm.lvl==sceneScherm.aantallevels) {
				pauzetel=0;
				createjs.Ticker.addEventListener("tick",totalEndLoop);
			} else {
				sceneScherm.lvl++;
				if (sceneScherm.lvl>sceneScherm.hoogste) {
					sceneScherm.hoogste = sceneScherm.lvl;
					try {localStorage['thefblevel']=sceneScherm.lvl} catch(err) {}			
				}
				pauzetel=0;
				createjs.Ticker.addEventListener("tick",levelEndLoop);
			}
		}
		
		function totalEndLoop(e) {
			if (pauzetel == 0) {
				sceneScherm.spr_bal.removeEventListener("click",ballPress);
				sceneScherm.toolbal1.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal1.toolbalmovie.gotoAndPlay(1);
				toolupdated = 1;
			}
			if ((nbrtools >= toolupdated) && (pauzetel == (toolupdated * 6))) {
				if (toolupdated==1) {sceneScherm.toolbal1.x=1026;sceneScherm.toolbal1.y=-240;}
				else if (toolupdated==2) {sceneScherm.toolbal2.x=1026;sceneScherm.toolbal2.y=-240;}
				else if (toolupdated==3) {sceneScherm.toolbal3.x=1026;sceneScherm.toolbal3.y=-240;}
				else if (toolupdated==4) {sceneScherm.toolbal4.x=1026;sceneScherm.toolbal4.y=-240;}
				else if (toolupdated==5) {sceneScherm.toolbal5.x=1026;sceneScherm.toolbal5.y=-240;}
				else if (toolupdated==6) {sceneScherm.toolbal6.x=1026;sceneScherm.toolbal6.y=-240;}
				else if (toolupdated==7) {sceneScherm.toolbal7.x=1026;sceneScherm.toolbal7.y=-240;}
				else if (toolupdated==8) {sceneScherm.toolbal8.x=1026;sceneScherm.toolbal8.y=-240;}
				else if (toolupdated==9) {sceneScherm.toolbal9.x=1026;sceneScherm.toolbal9.y=-240;}
				else if (toolupdated==10) {sceneScherm.toolbal10.x=1026;sceneScherm.toolbal10.y=-240;}
				else if (toolupdated==11) {sceneScherm.toolbal11.x=1026;sceneScherm.toolbal11.y=-240;}
			}
			if ((nbrtools > toolupdated) && (pauzetel == (toolupdated * 6))) {
				if (toolupdated==1) {sceneScherm.toolbal2.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal2.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==2) {sceneScherm.toolbal3.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal3.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==3) {sceneScherm.toolbal4.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal4.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==4) {sceneScherm.toolbal5.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal5.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==5) {sceneScherm.toolbal6.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal6.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==6) {sceneScherm.toolbal7.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal7.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==7) {sceneScherm.toolbal8.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal8.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==8) {sceneScherm.toolbal9.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal9.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==9) {sceneScherm.toolbal10.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal10.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==10) {sceneScherm.toolbal11.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal11.toolbalmovie.gotoAndPlay(1);}
				toolupdated++;
			}
			if (pauzetel > 50 && pauzetel < 61) {
				sceneScherm.spr_bal.y = tweenarray1[Math.abs(pauzetel-60)];
			} else if (pauzetel == 61) {
				tweenlen = 250+sceneScherm.spr_doos.x;
				for (i = 0; i < 15; i++) {
					tweenarray1[i] = sceneScherm.spr_doos.x-myEaseOut(i, 0, tweenlen, 14);
				}
				sceneScherm.spr_doosvoor.gotoAndPlay("toe");
				sceneScherm.spr_doos.gotoAndPlay("toe");
			} else if (pauzetel > 75 && pauzetel < 91) {
				sceneScherm.spr_doos.x = tweenarray1[pauzetel-76];
				sceneScherm.spr_doosvoor.x = sceneScherm.spr_doos.x; sceneScherm.spr_bal.x = sceneScherm.spr_doos.x;
				sceneScherm.balcentraal.y = tweenarray2[14-(pauzetel - 76)];
			}
			if (pauzetel == 91) {
				sceneScherm.balcentraal.visible = false;
				sceneScherm.spr_doos.visible = false;
				sceneScherm.spr_doosvoor.visible = false;
				sceneScherm.spr_bal.visible = false;
				createjs.Ticker.removeEventListener("tick",totalEndLoop);
				sceneScherm.gotoAndStop("einde");
			}
			pauzetel++;
		}
		
		
		function levelEndLoop(e) {
			if (sceneScherm.lvl == 2) instructieLogic();
			if (pauzetel == 0) {
				sceneScherm.spr_bal.removeEventListener("click",ballPress);
				sceneScherm.toolbal1.toolsmovie.gotoAndStop("leeg");
				sceneScherm.toolbal1.toolbalmovie.gotoAndPlay(1);
				toolupdated = 1;
			}
			if ((nbrtools >= toolupdated) && (pauzetel == (toolupdated * 6))) {
				if (toolupdated==1) {sceneScherm.toolbal1.x=1026;sceneScherm.toolbal1.y=-240;}
				else if (toolupdated==2) {sceneScherm.toolbal2.x=1026;sceneScherm.toolbal2.y=-240;}
				else if (toolupdated==3) {sceneScherm.toolbal3.x=1026;sceneScherm.toolbal3.y=-240;}
				else if (toolupdated==4) {sceneScherm.toolbal4.x=1026;sceneScherm.toolbal4.y=-240;}
				else if (toolupdated==5) {sceneScherm.toolbal5.x=1026;sceneScherm.toolbal5.y=-240;}
				else if (toolupdated==6) {sceneScherm.toolbal6.x=1026;sceneScherm.toolbal6.y=-240;}
				else if (toolupdated==7) {sceneScherm.toolbal7.x=1026;sceneScherm.toolbal7.y=-240;}
				else if (toolupdated==8) {sceneScherm.toolbal8.x=1026;sceneScherm.toolbal8.y=-240;}
				else if (toolupdated==9) {sceneScherm.toolbal9.x=1026;sceneScherm.toolbal9.y=-240;}
				else if (toolupdated==10) {sceneScherm.toolbal10.x=1026;sceneScherm.toolbal10.y=-240;}
				else if (toolupdated==11) {sceneScherm.toolbal11.x=1026;sceneScherm.toolbal11.y=-240;}
			}
			if ((nbrtools > toolupdated) && (pauzetel == (toolupdated * 6))) {
				if (toolupdated==1) {sceneScherm.toolbal2.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal2.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==2) {sceneScherm.toolbal3.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal3.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==3) {sceneScherm.toolbal4.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal4.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==4) {sceneScherm.toolbal5.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal5.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==5) {sceneScherm.toolbal6.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal6.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==6) {sceneScherm.toolbal7.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal7.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==7) {sceneScherm.toolbal8.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal8.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==8) {sceneScherm.toolbal9.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal9.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==9) {sceneScherm.toolbal10.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal10.toolbalmovie.gotoAndPlay(1);}
				else if (toolupdated==10) {sceneScherm.toolbal11.toolsmovie.gotoAndStop("leeg");sceneScherm.toolbal11.toolbalmovie.gotoAndPlay(1);}
				toolupdated++;
			}
			if (pauzetel > 50 && pauzetel < 61) {
				sceneScherm.spr_bal.y = tweenarray1[Math.abs(pauzetel-60)];
			} else if (pauzetel == 61) {
				tweenlen = 250+sceneScherm.spr_doos.x;
				for (i = 0; i < 15; i++) {
					tweenarray1[i] = sceneScherm.spr_doos.x-myEaseOut(i, 0, tweenlen, 14);
				}
				sceneScherm.spr_doosvoor.gotoAndPlay("toe");
				sceneScherm.spr_doos.gotoAndPlay("toe");
			} else if (pauzetel > 75 && pauzetel < 91) {
				sceneScherm.spr_doos.x = tweenarray1[pauzetel-76];
				sceneScherm.spr_doosvoor.x = sceneScherm.spr_doos.x; sceneScherm.spr_bal.x = sceneScherm.spr_doos.x;
				sceneScherm.balcentraal.y = tweenarray2[14-(pauzetel - 76)];
			}
			if (pauzetel == 91) {
				sceneScherm.balcentraal.visible = false;
				sceneScherm.spr_doos.visible = false;
				sceneScherm.spr_doosvoor.visible = false;
				sceneScherm.spr_bal.visible = false;
				createjs.Ticker.removeEventListener("tick",levelEndLoop);
				pauzetel=-2;
				createjs.Ticker.addEventListener("tick",gameLoop);
			}
			pauzetel++;
		}
		
		function onQuitgameClickEvent(e) {
			sceneScherm.spr_instructie.visible=false;
			if (sceneScherm.musicon) {
				sceneScherm.mysong.stop();
				sceneScherm.mysong=null;
			}
			createjs.Ticker.removeEventListener("tick",gameLoop);
			createjs.Ticker.removeEventListener("tick",balSchuif);
			createjs.Ticker.removeEventListener("tick",levelEndLoop);
			sceneScherm.spr_buttonquit.removeEventListener("click",onQuitgameClickEvent);
			sceneScherm.toolbal1.removeEventListener("click",onTool1ClickEvent);
			sceneScherm.toolbal2.removeEventListener("click",onTool2ClickEvent);
			sceneScherm.toolbal3.removeEventListener("click",onTool3ClickEvent);
			sceneScherm.toolbal4.removeEventListener("click",onTool4ClickEvent);
			sceneScherm.toolbal5.removeEventListener("click",onTool5ClickEvent);
			sceneScherm.toolbal6.removeEventListener("click",onTool6ClickEvent);
			sceneScherm.toolbal7.removeEventListener("click",onTool7ClickEvent);
			sceneScherm.toolbal8.removeEventListener("click",onTool8ClickEvent);
			sceneScherm.toolbal9.removeEventListener("click",onTool9ClickEvent);
			sceneScherm.toolbal10.removeEventListener("click",onTool10ClickEvent);
			sceneScherm.toolbal11.removeEventListener("click",onTool11ClickEvent);
			sceneScherm.spr_bal.x=1180;
			sceneScherm.spr_bal.y=536;
			sceneScherm.spr_doosvoor.x=1180;
			sceneScherm.spr_doosvoor.y=536;
			sceneScherm.spr_doos.x=1180;
			sceneScherm.spr_doos.y=536;
			sceneScherm.balcentraal.x=480;
			sceneScherm.balcentraal.y=1026;
			sceneScherm.toolbal1.x=1026;sceneScherm.toolbal1.y=-240;
			sceneScherm.toolbal2.x=1026;sceneScherm.toolbal2.y=-240;
			sceneScherm.toolbal3.x=1026;sceneScherm.toolbal3.y=-240;
			sceneScherm.toolbal4.x=1026;sceneScherm.toolbal4.y=-240;
			sceneScherm.toolbal5.x=1026;sceneScherm.toolbal5.y=-240;
			sceneScherm.toolbal6.x=1026;sceneScherm.toolbal6.y=-240;
			sceneScherm.toolbal7.x=1026;sceneScherm.toolbal7.y=-240;
			sceneScherm.toolbal8.x=1026;sceneScherm.toolbal8.y=-240;
			sceneScherm.toolbal9.x=1026;sceneScherm.toolbal9.y=-240;
			sceneScherm.toolbal10.x=1026;sceneScherm.toolbal10.y=-240;
			sceneScherm.toolbal11.x=1026;sceneScherm.toolbal11.y=-240;
			sceneScherm.gotoAndStop("menu");
		}
	}
	this.frame_4 = function() {
		var sceneScherm=this;
		var endtel=0;
		
		this.stop();
		createjs.Ticker.addEventListener("tick",enddChecker);
		
		function enddChecker(e) {
			endtel++;
			if (endtel==45) {
				sceneScherm.send1.visible=false;
			} else if (endtel==105) {
				sceneScherm.send2.visible=false;
			} else if (endtel==165) {
				sceneScherm.send3.visible=false;
			} else if (endtel==285) {
				createjs.Ticker.removeEventListener("tick",enddChecker);
				sceneScherm.gotoAndStop("veryend");
			}
		}
	}
	this.frame_5 = function() {
		var sceneScherm=this;
		
		this.stop();
		stage.enableMouseOver(20);
		this.endbuttonwww.cursor="pointer";
		this.endbuttonwww.addEventListener("click",onendWwwClickEvent);
		this.endbuttontwitter.cursor="pointer";
		this.endbuttontwitter.addEventListener("click",onendTwitterClickEvent);
		this.endbuttoninstagram.cursor="pointer";
		this.endbuttoninstagram.addEventListener("click",onendInstagramClickEvent);
		this.endbuttonfacebook.cursor="pointer";
		this.endbuttonfacebook.addEventListener("click",onendFacebookClickEvent);
		this.endbolsteam.cursor="pointer";
		this.endbolsteam.addEventListener("click",onendSteamClickEvent);
		this.endbolitchio.cursor="pointer";
		this.endbolitchio.addEventListener("click",onendItchioClickEvent);
		this.endbolkartridge.cursor="pointer";
		this.endbolkartridge.addEventListener("click",onendKartridgeClickEvent);
		this.endbolapple.cursor="pointer";
		this.endbolapple.addEventListener("click",onendAppleClickEvent);
		this.endbolgoogle.cursor="pointer";
		this.endbolgoogle.addEventListener("click",onendGoogleClickEvent);
		
		function onendWwwClickEvent(e) {
			window.open("https://bartbonte.com");
		}
		function onendTwitterClickEvent(e) {
			window.open("https://twitter.com/bartbonte");
		}
		function onendInstagramClickEvent(e) {
			window.open("https://instagram.com/bartbonte");
		}
		function onendFacebookClickEvent(e) {
			window.open("https://www.facebook.com/bontegames/");
		}
		function onendSteamClickEvent(e) {
			window.open("https://store.steampowered.com/app/1054660/Factory_Balls");
		}
		function onendItchioClickEvent(e) {
			window.open("https://bartbonte.itch.io/factory-balls");
		}
		function onendKartridgeClickEvent(e) {
			window.open("https://www.kartridge.com/games/bontegames/factory-balls");
		}
		function onendAppleClickEvent(e) {
			window.open("https://itunes.apple.com/us/app/factory-balls-official/id641519483");
		}
		function onendGoogleClickEvent(e) {
			window.open("https://play.google.com/store/apps/details?id=air.air.FactoryBalls");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1));

	// factoryv
	this.theplaybuttonsound = new lib.symbtheplaybutton();
	this.theplaybuttonsound.name = "theplaybuttonsound";
	this.theplaybuttonsound.setTransform(484.95,550,0.4999,0.5,0,0,0,80,0);
	this.theplaybuttonsound.alpha = 0.0117;

	this.bolgoogle = new lib.sgogle();
	this.bolgoogle.name = "bolgoogle";
	this.bolgoogle.setTransform(840,652);

	this.bolapple = new lib.sapple();
	this.bolapple.name = "bolapple";
	this.bolapple.setTransform(660,652);

	this.bolkartridge = new lib.skaert();
	this.bolkartridge.name = "bolkartridge";
	this.bolkartridge.setTransform(480,652);

	this.bolitchio = new lib.ditvh();
	this.bolitchio.name = "bolitchio";
	this.bolitchio.setTransform(300,652);

	this.bolsteam = new lib.ssetam2();
	this.bolsteam.name = "bolsteam";
	this.bolsteam.setTransform(120,652);

	this.spr_instructie = new lib.instructiemov1();
	this.spr_instructie.name = "spr_instructie";
	this.spr_instructie.setTransform(790,882,2.592,2.592);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.theplaybuttonsound}]}).to({state:[]},1).to({state:[{t:this.bolsteam},{t:this.bolitchio},{t:this.bolkartridge},{t:this.bolapple},{t:this.bolgoogle}]},1).to({state:[{t:this.spr_instructie}]},1).to({state:[]},1).wait(2));

	// factories
	this.makeyours = new lib.symbmake();
	this.makeyours.name = "makeyours";
	this.makeyours.setTransform(484.2,604);

	this.spr_buttonsound = new lib.buttonsound();
	this.spr_buttonsound.name = "spr_buttonsound";
	this.spr_buttonsound.setTransform(100.05,40.05,0.4,0.4,0,0,0,0.1,0.1);

	this.spr_buttonmusic = new lib.buttonmusic();
	this.spr_buttonmusic.name = "spr_buttonmusic";
	this.spr_buttonmusic.setTransform(40.1,40.1,0.4,0.4,0,0,0,0.3,0.3);

	this.buttonwww = new lib.buttonlang();
	this.buttonwww.name = "buttonwww";
	this.buttonwww.setTransform(747.05,338.1,0.4,0.4,0,0,0,0.1,0.3);

	this.buttonfacebook = new lib.buttonlinkfacebook();
	this.buttonfacebook.name = "buttonfacebook";
	this.buttonfacebook.setTransform(927.05,338.05,0.4,0.4,0,0,0,0.1,0.1);

	this.buttoninstagram = new lib.buttonlinkhome();
	this.buttoninstagram.name = "buttoninstagram";
	this.buttoninstagram.setTransform(867.1,338.1,0.4,0.4,0,0,0,0.3,0.3);

	this.buttontwitter = new lib.buttonlinktwitter();
	this.buttontwitter.name = "buttontwitter";
	this.buttontwitter.setTransform(807.05,338.1,0.4,0.4,0,0,0,0.1,0.3);

	this.spr_buttonquit = new lib.buttonquit();
	this.spr_buttonquit.name = "spr_buttonquit";
	this.spr_buttonquit.setTransform(40.05,40.05,0.4,0.4,0,0,0,0.1,0.1);

	this.spr_fblevel = new lib.fblevel();
	this.spr_fblevel.name = "spr_fblevel";
	this.spr_fblevel.setTransform(908.7,50.8,1.1628,1.1635,0,0,0,-1.1,9.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.buttontwitter},{t:this.buttoninstagram},{t:this.buttonfacebook},{t:this.buttonwww},{t:this.spr_buttonmusic},{t:this.spr_buttonsound},{t:this.makeyours}]},2).to({state:[{t:this.spr_fblevel},{t:this.spr_buttonquit}]},1).to({state:[]},1).wait(2));

	// balkh
	this.abbgam = new lib.symbab();
	this.abbgam.name = "abbgam";
	this.abbgam.setTransform(836.5,211.85);

	this.spr_doosvoor = new lib.swc_doos3();
	this.spr_doosvoor.name = "spr_doosvoor";
	this.spr_doosvoor.setTransform(1191.1,537.6,1.978,1.978,0,0,0,5.6,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.abbgam}]},2).to({state:[{t:this.spr_doosvoor}]},1).to({state:[]},1).wait(2));

	// balkv
	this.spr_buttonrechts = new lib.buttonrechts();
	this.spr_buttonrechts.name = "spr_buttonrechts";
	this.spr_buttonrechts.setTransform(620,430,0.72,0.72);

	this.spr_buttonlinks = new lib.buttonlinks();
	this.spr_buttonlinks.name = "spr_buttonlinks";
	this.spr_buttonlinks.setTransform(340,430,0.72,0.72);

	this.spr_bal = new lib.levelbal();
	this.spr_bal.name = "spr_bal";
	this.spr_bal.setTransform(1169.15,525.55,0.3438,0.3439,0,0,0,-31.4,-30.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.spr_buttonlinks},{t:this.spr_buttonrechts}]},2).to({state:[{t:this.spr_bal}]},1).to({state:[]},1).wait(2));

	// level
	this.playbutton = new lib.symbplaytitle();
	this.playbutton.name = "playbutton";
	this.playbutton.setTransform(488,549,1,1,0,0,0,25,0);

	this.spr_buttoncontinue = new lib.buttoncontinue();
	this.spr_buttoncontinue.name = "spr_buttoncontinue";
	this.spr_buttoncontinue.setTransform(480,430,1.28,1.28);

	this.spr_doos = new lib.swc_doos3achter();
	this.spr_doos.name = "spr_doos";
	this.spr_doos.setTransform(1191.1,537.6,1.978,1.978,0,0,0,5.6,0.8);

	this.send3 = new lib.sendbl();
	this.send3.name = "send3";
	this.send3.setTransform(743.5,483.5,1,1.9583);

	this.send1 = new lib.sendbl();
	this.send1.name = "send1";
	this.send1.setTransform(743.5,183.5);

	this.send2 = new lib.sendbl();
	this.send2.name = "send2";
	this.send2.setTransform(743.5,313.5);

	this.endbolgoogle = new lib.sgogle();
	this.endbolgoogle.name = "endbolgoogle";
	this.endbolgoogle.setTransform(840,530);

	this.endbolapple = new lib.sapple();
	this.endbolapple.name = "endbolapple";
	this.endbolapple.setTransform(660,530);

	this.endbolkartridge = new lib.skaert();
	this.endbolkartridge.name = "endbolkartridge";
	this.endbolkartridge.setTransform(480,530);

	this.endbolitchio = new lib.ditvh();
	this.endbolitchio.name = "endbolitchio";
	this.endbolitchio.setTransform(300,530);

	this.endbolsteam = new lib.ssetam2();
	this.endbolsteam.name = "endbolsteam";
	this.endbolsteam.setTransform(120,530);

	this.endbuttonwww = new lib.buttonlang();
	this.endbuttonwww.name = "endbuttonwww";
	this.endbuttonwww.setTransform(1033.05,669.1,0.4,0.4,0,0,0,0.1,0.3);

	this.endbuttonfacebook = new lib.buttonlinkfacebook();
	this.endbuttonfacebook.name = "endbuttonfacebook";
	this.endbuttonfacebook.setTransform(1213.05,669.05,0.4,0.4,0,0,0,0.1,0.1);

	this.endbuttoninstagram = new lib.buttonlinkhome();
	this.endbuttoninstagram.name = "endbuttoninstagram";
	this.endbuttoninstagram.setTransform(1153.1,669.1,0.4,0.4,0,0,0,0.3,0.3);

	this.endbuttontwitter = new lib.buttonlinktwitter();
	this.endbuttontwitter.name = "endbuttontwitter";
	this.endbuttontwitter.setTransform(1093.05,669.1,0.4,0.4,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.playbutton}]}).to({state:[]},1).to({state:[{t:this.spr_buttoncontinue}]},1).to({state:[{t:this.spr_doos}]},1).to({state:[{t:this.send2},{t:this.send1},{t:this.send3}]},1).to({state:[{t:this.endbuttontwitter},{t:this.endbuttoninstagram},{t:this.endbuttonfacebook},{t:this.endbuttonwww},{t:this.endbolsteam},{t:this.endbolitchio},{t:this.endbolkartridge},{t:this.endbolapple},{t:this.endbolgoogle}]},1).wait(1));

	// Layer_3
	this.spr_buttonnewplay = new lib.buttonnewplay();
	this.spr_buttonnewplay.name = "spr_buttonnewplay";
	this.spr_buttonnewplay.setTransform(480,430,1.28,1.28);

	this.toolbal11 = new lib.toolbal();
	this.toolbal11.name = "toolbal11";
	this.toolbal11.setTransform(1026,-240,1.048,1.048);

	this.toolbal10 = new lib.toolbal();
	this.toolbal10.name = "toolbal10";
	this.toolbal10.setTransform(1026,-240,1.048,1.048);

	this.toolbal9 = new lib.toolbal();
	this.toolbal9.name = "toolbal9";
	this.toolbal9.setTransform(1026,-240,1.048,1.048);

	this.toolbal8 = new lib.toolbal();
	this.toolbal8.name = "toolbal8";
	this.toolbal8.setTransform(1026,-240,1.048,1.048);

	this.toolbal7 = new lib.toolbal();
	this.toolbal7.name = "toolbal7";
	this.toolbal7.setTransform(1026,-240,1.048,1.048);

	this.toolbal6 = new lib.toolbal();
	this.toolbal6.name = "toolbal6";
	this.toolbal6.setTransform(1026,-240,1.048,1.048);

	this.toolbal5 = new lib.toolbal();
	this.toolbal5.name = "toolbal5";
	this.toolbal5.setTransform(1026,-240,1.048,1.048);

	this.toolbal4 = new lib.toolbal();
	this.toolbal4.name = "toolbal4";
	this.toolbal4.setTransform(1026,-240,1.048,1.048);

	this.toolbal3 = new lib.toolbal();
	this.toolbal3.name = "toolbal3";
	this.toolbal3.setTransform(1026,-240,1.048,1.048);

	this.toolbal2 = new lib.toolbal();
	this.toolbal2.name = "toolbal2";
	this.toolbal2.setTransform(1026,-240,1.048,1.048);

	this.toolbal1 = new lib.toolbal();
	this.toolbal1.name = "toolbal1";
	this.toolbal1.setTransform(1026,-240,1.048,1.048);

	this.instance = new lib.sbravo();
	this.instance.setTransform(743.45,372.8);

	this.instance_1 = new lib.sendtxt();
	this.instance_1.setTransform(480.2,535.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.spr_buttonnewplay}]},2).to({state:[{t:this.toolbal1},{t:this.toolbal2},{t:this.toolbal3},{t:this.toolbal4},{t:this.toolbal5},{t:this.toolbal6},{t:this.toolbal7},{t:this.toolbal8},{t:this.toolbal9},{t:this.toolbal10},{t:this.toolbal11}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(1));

	// Layer_7
	this.instance_2 = new lib.Sengie();
	this.instance_2.setTransform(480,310);

	this.instance_3 = new lib.fbtitelyellow();
	this.instance_3.setTransform(874,127,0.462,0.462,0,0,0,1500,0);

	this.balcentraal = new lib.bal_centraal();
	this.balcentraal.name = "balcentraal";
	this.balcentraal.setTransform(480,1026,4.896,4.896);

	this.instance_4 = new lib.partialendl();
	this.instance_4.setTransform(44,40);

	this.instance_5 = new lib.sendseethrough();
	this.instance_5.setTransform(480,360);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.balcentraal}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).wait(1));

	// Layer_6
	this.instance_6 = new lib.boxesvast();
	this.instance_6.setTransform(50,50,0.7135,0.7135);

	this.instance_7 = new lib.box19();
	this.instance_7.setTransform(330,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},2).to({state:[]},1).to({state:[{t:this.instance_7}]},2).wait(1));

	// Layer_2
	this.instance_8 = new lib.symbback2();
	this.instance_8.setTransform(480,360);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(6));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(480,54.5,931.2,1277.5);
// library properties:
lib.properties = {
	id: 'FD3559EF710E8E4AABB26802F91D9290',
	width: 960,
	height: 720,
	fps: 28,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/factoryballsforever_atlas_.png?1576758564158", id:"factoryballsforever_atlas_"},
		{src:"sounds/sndapprove.mp3?1576758564452", id:"sndapprove"},
		{src:"sounds/sndboo.mp3?1576758564452", id:"sndboo"},
		{src:"sounds/fbSong.mp3?1576758564452", id:"fbSong"},
		{src:"sounds/sndpaint.mp3?1576758564452", id:"sndpaint"},
		{src:"sounds/sndshovel.mp3?1576758564452", id:"sndshovel"},
		{src:"sounds/sndswitch.mp3?1576758564452", id:"sndswitch"},
		{src:"sounds/sndwater.mp3?1576758564452", id:"sndwater"},
		{src:"sounds/sndzaad.mp3?1576758564452", id:"sndzaad"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FD3559EF710E8E4AABB26802F91D9290'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;