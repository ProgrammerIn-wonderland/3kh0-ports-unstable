# To-Do

- [ ] eggs
- [ ] another power up
- [ ] obstacles?
- [ ] achievements??

# Credits

Fonts are from [Google Fonts](https://fonts.google.com/)  
KaboomJS is used  
All code outside of the library is mine  
What else do I put here?

# Changelog

- **1.0.2** - December 14, 2022
  - Can now be played with the spacebar
  - Counters all show shortened numbers
- **1.0.1** - December 13, 2022
  - Changed some star colors
  - Only works in a new tab
  - #1 on trending :)
- **Release** - December 10, 2022
  - released lol