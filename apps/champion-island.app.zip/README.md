# Google Doodle Champion Island Games

On 26 July 2021, Google released [the "Champion Island Games" Doodle](https://www.google.com/doodles/doodle-champion-island-games-july-26).

This repository contains all the (publicly available) code and assets for that doodle.

All content in this repo is owned and copyrighted by [Google LLC](https://google.com) and/or [STUDIO4°C](http://www.studio4c.co.jp/) (the creators of the game). Please respect their ownership.

The game can be played here: https://blog.pother.ca/Google-Doodle-Champion-Island/
